"use client";



import { useState, useTransition } from "react";

import { useRouter } from "next/navigation";

import Link from "next/link";

import { ArrowLeft, MailCheck, Shield, Sparkles, Zap, Loader2, UserRound } from "lucide-react";

import { toast } from "sonner";



import { Button } from "@/components/ui/button";

import { Input } from "@/components/ui/input";

import { Select } from "@/components/ui/select";

import { createSignupRequest } from "@/lib/api/auth";

import { ApiError } from "@/lib/api/client";

import { validateEmail } from "@/lib/validation/email";

import { validateName } from "@/lib/validation/name";

import { departmentOptions, departmentRoles, roleOptions, type UserDepartment } from "@/constants/user";

import type { UserRole } from "@/lib/auth/session-storage";



export function SignupPanel() {

  const router = useRouter();

  const [name, setName] = useState("");

  const [email, setEmail] = useState("");

  const [department, setDepartment] = useState<UserDepartment | "">("");

  const [isPending, startTransition] = useTransition();



  const nameError = name ? validateName(name) : null;

  const emailError = email ? validateEmail(email) : null;

  const departmentError = !department ? "College is required." : null;



  function handleSubmit() {

    if (nameError || emailError || departmentError || !name || !email) {

      toast.error(nameError ?? emailError ?? departmentError ?? "Fill in all fields correctly.");

      return;

    }



    startTransition(async () => {

      try {

        await createSignupRequest({

          name,

          email,

          role: "LECTURER",

          department: department,

        });



        toast.success("Request submitted. An admin will review your account.");

        router.push("/auth/login");

      } catch (error) {

        const message = error instanceof ApiError ? error.message : "Unable to submit signup request.";

        toast.error(message);

      }

    });

  }



  return (
    <div className="w-full">
      <div className="w-full max-w-3xl mx-auto px-4 py-4 relative z-10">
        <div className="relative overflow-hidden backdrop-blur-2xl">
          {/* Vibrant Gradient Border (static) */}
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] opacity-40 rounded-[var(--radius-xl)]" />
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-[var(--radius-xl)]" />

          <div className="relative z-10 bg-[var(--surface)]/90 border-2 border-[var(--border)] rounded-[var(--radius-2xl)] shadow-2xl p-10">

            <div className="relative mb-10 text-center">
              <div className="absolute top-4 left-4">
                <Link href="/auth/login">
                  <Button variant="ghost" size="sm" className="gap-2 text-[var(--foreground-secondary)] hover:text-[var(--color-blue)] transition-colors">
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </Button>
                </Link>
              </div>

              {/* Logo (static) */}
              <div className="relative mx-auto inline-flex items-center justify-center w-28 h-28">
                <div className="relative w-full h-full bg-gradient-to-br from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] rounded-3xl flex items-center justify-center shadow-lg">
                  <UserRound className="w-14 h-14 text-white" />
                </div>
              </div>

              <div className="mt-8 space-y-3">
                <h1 className="text-4xl font-bold bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] bg-clip-text text-transparent">
                  Request Access
                </h1>
                <p className="text-base text-[var(--foreground-secondary)] leading-relaxed">
                  Create a new lecturer account request. An administrator must approve your request before you can sign in.
                </p>
              </div>

              {/* Feature Pills */}
              <div className="flex justify-center gap-2 flex-wrap mt-6">
                <div className="flex items-center gap-1 px-4 py-2 bg-gradient-to-r from-[var(--color-blue)]/20 to-[var(--color-blue)]/10 text-[var(--color-blue)] rounded-full text-sm font-semibold border border-[var(--color-blue)]/30">
                  <Sparkles className="w-4 h-4" />
                  Lecturer Access
                </div>
                <div className="flex items-center gap-1 px-4 py-2 bg-gradient-to-r from-[var(--color-green)]/20 to-[var(--color-green)]/10 text-[var(--color-green)] rounded-full text-sm font-semibold border border-[var(--color-green)]/30">
                  <Shield className="w-4 h-4" />
                  Admin Approval
                </div>
                <div className="flex items-center gap-1 px-4 py-2 bg-gradient-to-r from-[var(--color-yellow)]/20 to-[var(--color-yellow)]/10 text-[var(--color-yellow)] rounded-full text-sm font-semibold border border-[var(--color-yellow)]/30">
                  <Zap className="w-4 h-4" />
                  Fast Review
                </div>
              </div>
            </div>

            <div className="grid gap-5">
              <Input
                label="Full name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                error={nameError}
                placeholder="Example Name"
              />

              <Input
                label="Email"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                error={emailError}
                placeholder="name@example.com"
              />

              <Select
                label="College"
                value={department}
                onChange={(event) => setDepartment(event.target.value as UserDepartment | "")}
                options={departmentOptions}
                error={departmentError}
              />

              <Button onClick={handleSubmit} busy={isPending} variant="primary" size="lg" className="gap-2 text-lg py-6 relative overflow-hidden group">
                <span className="relative z-10 flex items-center justify-center gap-2">
                  {isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : <MailCheck className="h-5 w-5" />}
                  {isPending ? 'Submitting...' : 'Submit Request'}
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-[var(--transition-slow)]" />
              </Button>
            </div>

            <div className="mt-10 rounded-2xl border-2 border-gradient-to-r from-[var(--color-blue)]/30 to-[var(--color-green)]/30 bg-gradient-to-br from-[var(--color-blue)]/5 to-[var(--color-green)]/5 p-6 text-sm">
              <div className="flex items-center gap-3 mb-4 text-[var(--color-primary)] font-bold text-lg">
                <div className="p-2 bg-gradient-to-br from-[var(--color-blue)] to-[var(--color-green)] rounded-lg">
                  <Shield className="w-5 h-5 text-white" />
                </div>
                Account Review
              </div>
              <p className="text-[var(--foreground-secondary)] leading-relaxed">
                Your request will be stored for administrator review. We will notify you once the account is activated and password setup is available.
              </p>
            </div>

          </div>
        </div>
      </div>

    </div>

  );

}

