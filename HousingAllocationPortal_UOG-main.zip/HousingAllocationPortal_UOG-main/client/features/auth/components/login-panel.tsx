"use client";

import { useState, useTransition, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  KeyRound,
  MailCheck,

  Zap,
  Shield,

  ChevronRight,

  CheckCircle2,
  Loader2
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { initiateLogin, passwordLogin } from "@/lib/api/auth";
import { ApiError } from "@/lib/api/client";
import { getDashboardPath } from "@/lib/auth/redirect-by-role";
import { validateEmail } from "@/lib/validation/email";
import { useAuth } from "@/hooks/use-auth";

const MAX_ATTEMPTS = 7;
const ATTEMPT_STORAGE_KEY = 'login_attempts';

export function LoginPanel() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { setSession } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState<string | null>(null);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [isOtpPending, startOtpTransition] = useTransition();
  const [isPasswordPending, startPasswordTransition] = useTransition();
  const [attemptsLeft, setAttemptsLeft] = useState(MAX_ATTEMPTS);

  // Load attempts from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(ATTEMPT_STORAGE_KEY);
    if (stored) {
      setAttemptsLeft(parseInt(stored, 10));
    }
  }, []);

  // Check for error in URL params
  useEffect(() => {
    const error = searchParams?.get('error');
    if (error) {
      setUrlError(error);
      toast.error(error);
    }
  }, [searchParams]);

  // Save attempts to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(ATTEMPT_STORAGE_KEY, attemptsLeft.toString());
  }, [attemptsLeft]);

  const emailError = validateEmail(email);
  const passwordError = password && password.length < 8 ? "Use at least 8 characters." : null;

  function handleInitiateLogin() {
    if (emailError) {
      toast.error(emailError);
      setAuthError(emailError);
      return;
    }

    startOtpTransition(async () => {
      try {
        const result = await initiateLogin(email);
        toast.success("Verification code sent to your email.");
        router.push(`/auth/verify/${result.userId}`);
      } catch (error) {
        const message =
          error instanceof ApiError ? error.message : "Unable to initiate login.";
        toast.error(message);
        setAuthError(message);
      }
    });
  }

  function handlePasswordLogin() {
    if (emailError) {
      toast.error(emailError);
      setAuthError(emailError);
      return;
    }

    if (!password) {
      toast.error("Password is required.");
      return;
    }

    startPasswordTransition(async () => {
      try {
        const result = await passwordLogin(email, password);

        // Reset attempts on successful login
        setAttemptsLeft(MAX_ATTEMPTS);
        localStorage.removeItem(ATTEMPT_STORAGE_KEY);

        if ("requiresSetup" in result) {
          toast.info("This account needs password setup. We sent a verification code.");
          const otpResult = await initiateLogin(email);
          router.push(`/auth/verify/${otpResult.userId}`);
          return;
        }

        setSession(result.user);
        toast.success("Login successful.");
        router.push(getDashboardPath(result.user.role));
      } catch (error) {
        if (error instanceof ApiError) {
          console.log('ApiError caught:', { status: error.status, message: error.message });
          // User not found - no attempt counter
          if (error.status === 404 || /not\s*found/i.test(error.message)) {
            toast.error("User not found.");
            setAuthError("User not found.");
            return;
          }

          // Wrong password / unauthorized - with attempt counter
          if (error.status === 401 || /wrong\s*password|invalid\s*credentials|incorrect/i.test(error.message)) {
            const newAttempts = attemptsLeft - 1;
            setAttemptsLeft(newAttempts);
            toast.error("Wrong password.");
            setAuthError(`Wrong password. ${newAttempts} attempt${newAttempts !== 1 ? 's' : ''} left.`);

            if (newAttempts <= 0) {
              setTimeout(() => {
                router.push('/auth/forgot-password');
              }, 2000);
            }
            return;
          }

          // Account deactivated / forbidden
          if (error.status === 403 || /deactivated|disabled|inactive/i.test(error.message)) {
            toast.error("Account deactivated.");
            setAuthError("Account deactivated.");
            return;
          }

          // For any other API error: do not show a generic "Unable to sign in." message
          console.log('Other API error (no handler):', error.message);
          return;
        }

        // Non-API errors: do nothing (remove generic fallback message per request)
        console.log('Non-API error:', error);
        return;
      }
    });
  }

  // Clear visible auth error when user edits inputs
  function handleEmailChange(e: React.ChangeEvent<HTMLInputElement>) {
    setEmail(e.target.value);
    if (authError) setAuthError(null);
    if (urlError) setUrlError(null);
    // Reset attempts when email changes
    setAttemptsLeft(MAX_ATTEMPTS);
    localStorage.removeItem(ATTEMPT_STORAGE_KEY);
  }

  function handlePasswordChange(e: React.ChangeEvent<HTMLInputElement>) {
    setPassword(e.target.value);
    if (authError) setAuthError(null);
  }

  return (
    <div className="w-full">
      <div className="w-full max-w-3xl mx-auto px-4 py-4">

        {/* Main Login Card (static visuals) */}
        <Card variant="glass" className="relative overflow-hidden backdrop-blur-xl">
          {/* Gradient Border Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] opacity-20 rounded-[var(--radius-xl)]" />

          <CardHeader className="relative z-10 text-center space-y-6 pb-8">
            <div className="absolute left-4 top-4">
              <Link href="/" className="inline-flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--foreground)] shadow-sm transition hover:border-[var(--color-blue)] hover:text-[var(--color-blue)]">
                ← Back
              </Link>
            </div>
            {/* Welcome Text */}
            <div className="space-y-2">
              <CardTitle size="lg" className="bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] bg-clip-text text-transparent">
                Welcome Back
              </CardTitle>
              <CardDescription className="text-[var(--foreground-secondary)]">
                Enter your credentials to access the portal
              </CardDescription>
            </div>

            {/* Feature Pills */}
            <div className="flex justify-center gap-2 flex-wrap">
              <div className="flex items-center gap-1 px-3 py-1 bg-[var(--color-blue)]/10 text-[var(--color-blue)] rounded-full text-xs font-medium">
                <Zap className="w-3 h-3" />
                Fast Login
              </div>
              <div className="flex items-center gap-1 px-3 py-1 bg-[var(--color-green)]/10 text-[var(--color-green)] rounded-full text-xs font-medium">
                <Shield className="w-3 h-3" />
                Secure
              </div>
            </div>
          </CardHeader>

          <CardContent className="relative z-10 space-y-6">
            {/* Email Input */}
            <div className="space-y-4">
              <Input
                label="Email Address"
                type="email"
                value={email}
                onChange={handleEmailChange}
                placeholder="name@gondar.edu.et"
                error={email ? emailError : null}
              />

              {/* Login Options */}
              <div className="grid gap-3">
                <Button
                  onClick={handleInitiateLogin}
                  onTouchEnd={handleInitiateLogin}
                  busy={isOtpPending}
                  variant="primary"
                  size="lg"
                  className="relative overflow-hidden group touch-manipulation"
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    {isOtpPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <MailCheck className="w-4 h-4" />
                    )}
                    {isOtpPending ? 'Sending Code...' : 'Send Verification Code'}
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-[var(--transition-slow)]" />
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePasswordLogin}
                  onTouchEnd={handlePasswordLogin}
                  busy={isPasswordPending}
                  size="lg"
                  className="relative overflow-hidden group touch-manipulation"
                >
                  <span className="relative z-10 flex items-center justify-center gap-2">
                    {isPasswordPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <KeyRound className="w-4 h-4" />
                    )}
                    {isPasswordPending ? 'Signing In...' : 'Sign In with Password'}
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[var(--color-blue)]/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-[var(--transition-slow)]" />
                </Button>
              </div>
            </div>



            <div className="space-y-4">
              {/* Password Input */}
              <Input
                label="Password"
                type="password"
                value={password}
                onChange={handlePasswordChange}
                placeholder="Enter your secure password"
                error={password ? passwordError : null}
                allowPasswordToggle
              />

              {/* Forgot Password Link */}
              <div className="flex items-center justify-between text-sm">
                <div className="text-center pt-4 border-t border-[var(--border)]">

                  <div className="flex flex-col items-center gap-2 text-sm">
                    <p> Register if have not account </p>
                    <Link
                      href="/auth/signup"
                      className="text-[var(--color-blue)] hover:text-[var(--color-blue-dark)] transition-colors duration-[var(--transition-fast)]"
                    >
                      signup </Link>
                  </div>
                </div>

                <Link
                  href="/auth/forgot-password"
                  className="text-[var(--color-blue)] hover:text-[var(--color-blue-dark)] transition-colors duration-[var(--transition-fast)] flex items-center gap-1"
                >
                  Forgot password?
                  <ChevronRight className="w-3 h-3" />
                </Link>
              </div>

              {authError || urlError ? (
                <div className="mt-2 p-4 bg-[var(--color-red)] text-white rounded-lg text-sm font-medium shadow-lg flex items-center gap-3 animate-in slide-in-from-top-2">
                  <div className="w-5 h-5 flex-shrink-0">
                    <svg fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>{authError || urlError}</span>
                </div>
              ) : null}

              {attemptsLeft < MAX_ATTEMPTS && attemptsLeft > 0 && (
                <div className="mt-2 p-3 bg-[var(--color-yellow)]/5 border border-[var(--color-yellow)]/20 rounded text-sm text-[var(--color-yellow)]">
                  {attemptsLeft} attempt{attemptsLeft !== 1 ? 's' : ''} remaining before redirect to password reset.
                </div>
              )}

              {/* Security Notice */}
              <div className="flex items-start gap-2 p-3 bg-[var(--color-green)]/5 border border-[var(--color-green)]/20 rounded-[var(--radius-lg)]">
                <CheckCircle2 className="w-4 h-4 text-[var(--color-green)] mt-0.5 flex-shrink-0" />
                <p className="text-xs text-[var(--foreground-tertiary)]">
                  Your login is secured with industry-standard encryption and multi-factor authentication.
                </p>
              </div>
            </div>


          </CardContent>
        </Card>

      </div>
    </div>
  );
}
