"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2, Download, FileText, Printer, FileJson, File } from "lucide-react";
import * as XLSX from "xlsx";

import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { ApiError } from "@/lib/api/client";
import {
  getOfficerAllocationResults,
  getOfficerManagedRounds,
  deleteOfficerRound,
  sendReportToAdmin,
} from "@/lib/api/officer";

export function OfficerReportsPanel() {
  const queryClient = useQueryClient();
  const [selectedRoundId, setSelectedRoundId] = useState("");

  const roundsQuery = useQuery({
    queryKey: ["officer-managed-rounds"],
    queryFn: getOfficerManagedRounds,
  });

  const allocationResultsQuery = useQuery({
    queryKey: ["officer-allocation-results", selectedRoundId],
    queryFn: () => getOfficerAllocationResults(selectedRoundId),
    enabled: selectedRoundId.length > 0,
  });

  const deleteRoundMutation = useMutation({
    mutationFn: deleteOfficerRound,
    onSuccess: () => {
      toast.success("Round and its allocation results deleted.");
      queryClient.invalidateQueries({ queryKey: ["officer-managed-rounds"] });
      queryClient.invalidateQueries({ queryKey: ["officer-allocation-results", selectedRoundId] });
      setSelectedRoundId("");
    },
    onError: (error) => {
      const message = error instanceof ApiError ? error.message : "Could not delete round.";
      toast.error(message);
    },
  });

  const sendToAdminMutation = useMutation({
    mutationFn: sendReportToAdmin,
    onSuccess: () => {
      toast.success("Report sent to admin support for review.");
    },
    onError: (error) => {
      const message = error instanceof ApiError ? error.message : "Could not send report to admin.";
      toast.error(message);
    },
  });

  const roundOptions = [
    { label: "-- Select round --", value: "" },
    ...(roundsQuery.data?.map((round) => ({
      label: `${round.name} (${round.status})`,
      value: round.id,
    })) ?? []),
  ];

  const selectedRound = roundsQuery.data?.find((r) => r.id === selectedRoundId);

  function handleDownloadExcel() {
    if (!selectedRound || !allocationResultsQuery.data) return;

    // Prepare data for Excel
    const data = allocationResultsQuery.data.map((row, index) => ({
      "No.": index + 1,
      "Lecturer Name": row.lecturerName ?? "-",
      "College": row.lecturerDepartment ?? "-",
      "Rank": row.rankPosition != null ? row.rankPosition : "-",
      "Building": row.housingBuildingName ?? "-",
      "Block": row.housingBlockNumber ?? "-",
      "Room": row.housingRoomNumber ?? "-",
      "Room Type": row.housingRoomType ?? "-",
      "Score": row.score != null ? row.score : "-",
      "Location": "University of Gondar",
      "Status": row.status,
      "Allocated At": new Date(row.allocatedAt).toLocaleString(),
    }));

    // Create workbook
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Allocations");

    // Add summary sheet
    const summaryData = [
      ["Housing Allocation Report"],
      [],
      ["Round Information"],
      ["Round Name", selectedRound.name],
      ["Status", selectedRound.status],
      ["Committee Ranking", selectedRound.committeeRankingStatus],
      ["Start Date", new Date(selectedRound.startsAt).toLocaleDateString()],
      ["End Date", new Date(selectedRound.endsAt).toLocaleDateString()],
      [],
      ["Summary"],
      ["Total Allocations", allocationResultsQuery.data.length],
      ["Generated At", new Date().toLocaleString()],
    ];

    const summarySh = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, summarySh, "Summary");

    // Download
    XLSX.writeFile(wb, `Housing-Allocation-Report-${selectedRound.name.replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.xlsx`);
    
    toast.success("Report downloaded as Excel.");
  }

  function handleDownloadJSON() {
    if (!selectedRound || !allocationResultsQuery.data) return;

    const reportData = {
      round: {
        id: selectedRound.id,
        name: selectedRound.name,
        status: selectedRound.status,
        committeeRankingStatus: selectedRound.committeeRankingStatus,
        startsAt: selectedRound.startsAt,
        endsAt: selectedRound.endsAt,
      },
      allocations: allocationResultsQuery.data,
      summary: {
        totalAllocations: allocationResultsQuery.data.length,
      },
      generatedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `allocation-report-${selectedRound.name.replace(/\s+/g, "-")}-${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success("Report downloaded as JSON.");
  }

  function handlePrintReport() {
    if (!selectedRound || !allocationResultsQuery.data) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      toast.error("Unable to open print window. Check your browser settings.");
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Housing Allocation Report - ${selectedRound.name}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #000; padding-bottom: 20px; }
            .header h1 { margin: 0; font-size: 24px; }
            .header p { margin: 5px 0; color: #666; }
            .section { margin: 30px 0; }
            .section-title { font-size: 18px; font-weight: bold; margin-bottom: 15px; background: #f0f0f0; padding: 10px; border-left: 4px solid #2563eb; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
            .info-item { padding: 10px; background: #f9f9f9; border-left: 3px solid #2563eb; }
            .info-label { font-weight: bold; color: #2563eb; }
            .info-value { margin-top: 5px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            thead { background: #f0f0f0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { font-weight: bold; background: #2563eb; color: white; }
            tr:nth-child(even) { background: #f9f9f9; }
            .footer { margin-top: 40px; text-align: center; border-top: 2px solid #000; padding-top: 20px; font-size: 12px; color: #666; }
            .summary { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin: 20px 0; }
            .summary-box { padding: 15px; background: #f0f0f0; text-align: center; border-radius: 5px; }
            .summary-number { font-size: 24px; font-weight: bold; color: #2563eb; }
            .summary-label { font-size: 12px; color: #666; margin-top: 5px; }
            @media print { body { margin: 0; } .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Housing Allocation Report</h1>
            <p>University of Gondar</p>
            <p>Generated: ${new Date().toLocaleString()}</p>
          </div>

          <div class="section">
            <div class="section-title">Round Information</div>
            <div class="info-grid">
              <div class="info-item">
                <div class="info-label">Round Name</div>
                <div class="info-value">${selectedRound.name}</div>
              </div>
              <div class="info-item">
                <div class="info-label">Status</div>
                <div class="info-value">${selectedRound.status}</div>
              </div>
              <div class="info-item">
                <div class="info-label">Committee Ranking Status</div>
                <div class="info-value">${selectedRound.committeeRankingStatus}</div>
              </div>
              <div class="info-item">
                <div class="info-label">Period</div>
                <div class="info-value">${new Date(selectedRound.startsAt).toLocaleDateString()} - ${new Date(selectedRound.endsAt).toLocaleDateString()}</div>
              </div>
            </div>
          </div>

          <div class="section">
            <div class="section-title">Allocation Summary</div>
            <div class="summary">
              <div class="summary-box">
                <div class="summary-number">${allocationResultsQuery.data.length}</div>
                <div class="summary-label">Total Allocations</div>
              </div>
              <div class="summary-box">
                <div class="summary-number">${allocationResultsQuery.data.filter(r => r.status === "PUBLISHED").length}</div>
                <div class="summary-label">Published</div>
              </div>
              <div class="summary-box">
                <div class="summary-number">${allocationResultsQuery.data.filter(r => r.status === "PRELIMINARY").length}</div>
                <div class="summary-label">Preliminary</div>
              </div>
            </div>
          </div>

          <div class="section">
            <div class="section-title">Allocation Details</div>
            <table>
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Lecturer Name</th>
                  <th>College</th>
                  <th>Rank</th>
                  <th>Building</th>
                  <th>Block</th>
                  <th>Room</th>
                  <th>Room Type</th>
                  <th>Score</th>
                  <th>Status</th>
                  <th>Allocated At</th>
                </tr>
              </thead>
              <tbody>
                ${allocationResultsQuery.data.map((row, index) => `
                  <tr>
                    <td>${index + 1}</td>
                    <td>${row.lecturerName ?? "-"}</td>
                    <td>${row.lecturerDepartment ?? "-"}</td>
                    <td>${row.rankPosition != null ? row.rankPosition : "-"}</td>
                    <td>${row.housingBuildingName ?? "-"}</td>
                    <td>${row.housingBlockNumber ?? "-"}</td>
                    <td>${row.housingRoomNumber ?? "-"}</td>
                    <td>${row.housingRoomType ?? "-"}</td>
                    <td>${row.score != null ? row.score.toFixed(2) : "-"}</td>
                    <td><strong>Allocated</strong></td>
                    <td>${new Date(row.allocatedAt).toLocaleString()}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>

          <div class="footer">
            <p>This report was automatically generated by the Housing Allocation System.</p>
            <p>For inquiries, contact the Housing Management Office.</p>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.print();
  }

  function handleSendToAdmin() {
    if (!selectedRound || !allocationResultsQuery.data) return;

    const reportData = {
      round: {
        id: selectedRound.id,
        name: selectedRound.name,
        status: selectedRound.status,
        committeeRankingStatus: selectedRound.committeeRankingStatus,
        startsAt: selectedRound.startsAt,
        endsAt: selectedRound.endsAt,
      },
      allocations: allocationResultsQuery.data,
      summary: {
        totalAllocations: allocationResultsQuery.data.length,
        published: allocationResultsQuery.data.filter(r => r.status === "PUBLISHED").length,
        preliminary: allocationResultsQuery.data.filter(r => r.status === "PRELIMINARY").length,
      },
      generatedAt: new Date().toISOString(),
    };

    sendToAdminMutation.mutate({
      roundId: selectedRound.id,
      roundName: selectedRound.name,
      allocationCount: allocationResultsQuery.data.length,
      reportData,
    });
  }


  return (
    <div className="space-y-6">
      <section className="bg-white border border-gray-200 shadow-sm rounded-3xl p-6 backdrop-blur-none">
        <div className="grid gap-4 md:grid-cols-[1fr_auto_auto_auto_auto_auto] md:items-end">
          <Select
            label="Select Round"
            options={roundOptions}
            value={selectedRoundId}
            onChange={(event) => setSelectedRoundId(event.target.value)}
          />
          <Button
            onClick={handleDownloadExcel}
            disabled={!selectedRoundId || !allocationResultsQuery.data || allocationResultsQuery.data.length === 0}
            className="gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Download report as Excel"
          >
            <File className="h-4 w-4" />
            Excel
          </Button>
          <Button
            onClick={handleDownloadJSON}
            disabled={!selectedRoundId || !allocationResultsQuery.data || allocationResultsQuery.data.length === 0}
            className="gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Download report as JSON"
          >
            <FileJson className="h-4 w-4" />
            JSON
          </Button>
          <Button
            onClick={handlePrintReport}
            disabled={!selectedRoundId || !allocationResultsQuery.data || allocationResultsQuery.data.length === 0}
            className="gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            title="Print report"
          >
            <Printer className="h-4 w-4" />
            Print
          </Button>
          <Button
            variant="success"
            onClick={handleSendToAdmin}
            busy={sendToAdminMutation.isPending}
            disabled={!selectedRoundId || !allocationResultsQuery.data || allocationResultsQuery.data.length === 0}
            className="gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <FileText className="h-4 w-4" />
            Send to Admin
          </Button>
          <Button
            variant="danger"
            onClick={() => deleteRoundMutation.mutate(selectedRoundId)}
            busy={deleteRoundMutation.isPending}
            disabled={!selectedRoundId}
            className="gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
        </div>
      </section>

      {selectedRound && (
        <section className="bg-white border border-gray-200 shadow-sm rounded-3xl overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-bold uppercase tracking-tight text-[var(--color-primary)]">
              Round Information
            </h3>
          </div>
          <div className="p-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <p className="text-xs text-muted uppercase tracking-wide">Round Name</p>
              <p className="text-sm font-semibold text-[var(--color-primary)]">{selectedRound.name}</p>
            </div>
            <div>
              <p className="text-xs text-muted uppercase tracking-wide">Status</p>
              <p className="text-sm font-semibold text-[var(--color-primary)]">{selectedRound.status}</p>
            </div>
            <div>
              <p className="text-xs text-muted uppercase tracking-wide">Committee Ranking</p>
              <p className="text-sm font-semibold text-[var(--color-primary)]">{selectedRound.committeeRankingStatus}</p>
            </div>
            <div>
              <p className="text-xs text-muted uppercase tracking-wide">Allocations</p>
              <p className="text-sm font-semibold text-[var(--color-primary)]">{allocationResultsQuery.data?.length ?? 0}</p>
            </div>
          </div>
        </section>
      )}

      {allocationResultsQuery.isLoading ? (
        <div className="bg-white border border-gray-200 shadow-sm rounded-3xl p-8">
          <p className="text-sm text-muted">Loading allocation results...</p>
        </div>
      ) : allocationResultsQuery.isError ? (
        <div className="bg-white border border-gray-200 shadow-sm rounded-3xl p-8">
          <p className="text-sm text-[var(--color-danger)]">Could not load allocation results.</p>
        </div>
      ) : !allocationResultsQuery.data || allocationResultsQuery.data.length === 0 ? (
        <div className="bg-white border border-gray-200 shadow-sm rounded-3xl p-8">
          <p className="text-sm text-muted">No allocation results for this round yet.</p>
        </div>
      ) : (
        <section className="bg-white border border-gray-200 shadow-sm rounded-3xl overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-bold uppercase tracking-tight text-[var(--color-primary)]">
              Allocation Results
            </h3>
            <p className="mt-2 text-sm text-muted">
              Total: {allocationResultsQuery.data.length} allocations
              {allocationResultsQuery.data.filter(r => r.status === "PUBLISHED").length > 0 && 
                ` • Published: ${allocationResultsQuery.data.filter(r => r.status === "PUBLISHED").length}`}
              {allocationResultsQuery.data.filter(r => r.status === "PRELIMINARY").length > 0 && 
                ` • Preliminary: ${allocationResultsQuery.data.filter(r => r.status === "PRELIMINARY").length}`}
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[var(--surface-muted)] border-b border-[var(--border)]">
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    No.
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Lecturer
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    College
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Rank
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Building
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Block
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Room
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Room Type
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Score
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Status
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Allocated At
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)]">
                {allocationResultsQuery.data.map((row, index) => (
                  <tr key={row.id}>
                    <td className="px-4 py-4 text-sm font-semibold text-muted">
                      {index + 1}
                    </td>
                    <td className="px-4 py-4 text-sm text-[var(--color-primary)]">
                      {row.lecturerName ?? row.applicationId}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.lecturerDepartment ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.rankPosition != null ? row.rankPosition : "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.housingBuildingName ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.housingBlockNumber ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.housingRoomNumber ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">{row.housingRoomType ?? "-"}</td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.score != null ? row.score.toFixed(2) : "-"}
                    </td>
                    <td className="px-4 py-4 text-xs font-bold uppercase tracking-wide">
                      <span className={`inline-block px-2 py-1 rounded bg-green-100 text-green-700`}>
                        Allocated
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {new Date(row.allocatedAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
