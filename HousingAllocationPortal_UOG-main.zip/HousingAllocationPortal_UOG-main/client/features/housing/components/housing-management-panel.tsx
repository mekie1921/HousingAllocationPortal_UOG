"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Download, Printer } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import * as XLSX from "xlsx";

import { Button } from "@/components/ui/button";
import { printTableData } from "@/lib/print-utils";
import type { HousingFilter } from "@/constants/housing";
import { AddHousingModal } from "@/features/housing/components/add-housing-modal";
import { DeleteHousingModal } from "@/features/housing/components/delete-housing-modal";
import { EditHousingModal } from "@/features/housing/components/edit-housing-modal";
import { HousingFilterBar } from "@/features/housing/components/housing-filter-bar";
import { HousingDetailsModal } from "@/features/housing/components/housing-details-modal";
import { HousingSummaryCards } from "@/features/housing/components/housing-summary-cards";
import { HousingTable } from "@/features/housing/components/housing-table";
import { ApiError } from "@/lib/api/client";
import {
  createHousingUnit,
  deleteHousingUnit,
  getHousingUnitById,
  getHousingUnits,
  type CreateHousingUnitPayload,
  type HousingUnit,
  type UpdateHousingUnitPayload,
  updateHousingUnit,
} from "@/lib/api/housing";
import { countUnitsByCondition, filterHousingUnits } from "@/utils/housing";

export function HousingManagementPanel() {
  const queryClient = useQueryClient();
  const [activeFilter, setActiveFilter] = useState<HousingFilter>("ALL");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [selectedUnitSnapshot, setSelectedUnitSnapshot] = useState<HousingUnit | undefined>();
  const [activeModal, setActiveModal] = useState<"details" | "edit" | "delete" | null>(null);

  const housingQuery = useQuery({
    queryKey: ["housing-units"],
    queryFn: () => getHousingUnits(),
  });

  const selectedHousingQuery = useQuery({
    queryKey: ["housing-unit", selectedUnitId],
    queryFn: () => getHousingUnitById(selectedUnitId!),
    enabled: selectedUnitId !== null && activeModal !== "delete",
  });

  const createHousingMutation = useMutation({
    mutationFn: (payload: CreateHousingUnitPayload) => createHousingUnit(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["housing-units"] });
      toast.success("Housing unit registered successfully.");
      setIsAddModalOpen(false);
    },
    onError: (error) => {
      const message =
        error instanceof ApiError ? error.message : "Unable to create housing unit.";
      toast.error(message);
    },
  });

  const updateHousingMutation = useMutation({
    mutationFn: (payload: UpdateHousingUnitPayload) =>
      updateHousingUnit(selectedUnitId!, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["housing-units"] });
      queryClient.invalidateQueries({ queryKey: ["housing-unit", selectedUnitId] });
      toast.success("Housing unit updated successfully.");
      handleCloseModal();
    },
    onError: (error) => {
      const message =
        error instanceof ApiError ? error.message : "Unable to update housing unit.";
      toast.error(message);
    },
  });

  const deleteHousingMutation = useMutation({
    mutationFn: () => deleteHousingUnit(selectedUnitId!),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["housing-units"] });
      toast.success("Housing unit deleted successfully.");
      handleCloseModal();
    },
    onError: (error) => {
      const message =
        error instanceof ApiError ? error.message : "Unable to delete housing unit.";
      toast.error(message);
    },
  });

  const allUnits = housingQuery.data ?? [];
  const units = filterHousingUnits(allUnits, activeFilter);
  const availableCount = allUnits.filter((unit) => unit.status === "Available").length;
  const maintenanceCount = countUnitsByCondition(allUnits, "Under Maintenance");

  function openModal(type: "details" | "edit" | "delete", unit: HousingUnit) {
    setSelectedUnitId(unit.id);
    setSelectedUnitSnapshot(unit);
    setActiveModal(type);
  }

  function handleCloseModal() {
    setActiveModal(null);
    setSelectedUnitId(null);
    setSelectedUnitSnapshot(undefined);
  }

  function handleExportHousingToExcel() {
    if (!allUnits || allUnits.length === 0) {
      toast.error("No housing units to export.");
      return;
    }

    try {
      // Prepare housing data
      const housingData = allUnits.map((unit, index) => ({
        "No.": index + 1,
        "Building": unit.buildingName || "-",
        "Block": unit.blockNumber || "-",
        "Room": unit.roomNumber || "-",
        "Room Type": unit.roomType || "-",
        "Status": unit.status || "-",
        "Condition": unit.condition || "-",
        "Location": unit.location || "-",
      }));

      // Create workbook
      const ws = XLSX.utils.json_to_sheet(housingData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Housing");

      // Add summary sheet
      const summaryData = [
        ["Manage Housing Units Report"],
        [],
        ["Housing Summary"],
        ["Total Units", allUnits.length],
        ["Available", availableCount],
        ["Under Maintenance", maintenanceCount],
        ["Generated At", new Date().toLocaleString()],
      ];

      const summarySh = XLSX.utils.aoa_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, summarySh, "Summary");

      // Download
      XLSX.writeFile(wb, `Housing-Units-${new Date().toISOString().split("T")[0]}.xlsx`);
      toast.success("Housing units exported to Excel successfully.");
    } catch (error) {
      toast.error("Failed to export housing units to Excel.");
      console.error(error);
    }
  }

  function handlePrintHousing() {
    if (!allUnits || allUnits.length === 0) {
      toast.error("No housing units to print.");
      return;
    }

    try {
      const data = allUnits.map((unit) => ({
        "Building": unit.buildingName || "-",
        "Block": unit.blockNumber || "-",
        "Room": unit.roomNumber || "-",
        "Room Type": unit.roomType || "-",
        "Status": unit.status || "-",
        "Condition": unit.condition || "-",
        "Location": unit.location || "-",
      }));

      printTableData(
        data,
        "Manage Housing Units",
        {
          "Total Units": allUnits.length.toString(),
          "Available": availableCount.toString(),
          "Under Maintenance": maintenanceCount.toString(),
          "Generated": new Date().toLocaleString(),
        }
      );
      toast.success("Printing housing units...");
    } catch (error) {
      toast.error("Failed to print housing units.");
    }
  }

  return (
    <div className="space-y-8">
      {/* Hero / Summary Section */}
      <section className="bg-gradient-to-br from-[var(--color-primary)]/5 to-[var(--color-accent)]/5 rounded-2xl p-8 border border-[var(--border)]">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between mb-8">
          <div className="space-y-2">
            <h2 className="font-[family-name:var(--font-space-grotesk)] text-3xl font-bold text-[var(--color-primary)]">
              Housing Overview
            </h2>
            <p className="text-sm text-muted">
              Monitor all university housing assets. Track availability and maintenance status in real-time.
            </p>
          </div>
          <Button 
            className="gap-2 rounded-xl h-12 px-6 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/90 text-white shadow-lg shadow-[var(--color-primary)]/20" 
            onClick={() => setIsAddModalOpen(true)}
          >
            <Plus className="h-4 w-4" /> Register New House
          </Button>
        </div>

        <HousingSummaryCards
          totalUnits={allUnits.length}
          availableUnits={availableCount}
          maintenanceUnits={maintenanceCount}
        />
      </section>

      {/* Main Table Section */}
      <section className="bg-white rounded-2xl border border-[var(--border)] shadow-sm overflow-hidden">
        <div className="p-6 border-b border-[var(--border)]">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-1">
              <h3 className="font-[family-name:var(--font-space-grotesk)] text-xl font-bold text-[var(--color-primary)]">
                Asset Inventory
              </h3>
              <p className="text-xs text-muted">
                {units.length} total units matching filter
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Button
                size="sm"
                variant="secondary"
                onClick={handleExportHousingToExcel}
                disabled={!allUnits || allUnits.length === 0}
                className="flex items-center gap-2 rounded-lg"
              >
                <Download className="w-4 h-4" />
                Excel
              </Button>
              <Button
                size="sm"
                variant="secondary"
                onClick={handlePrintHousing}
                disabled={!allUnits || allUnits.length === 0}
                className="flex items-center gap-2 rounded-lg"
              >
                <Printer className="w-4 h-4" />
                Print
              </Button>
              <HousingFilterBar
                activeFilter={activeFilter}
                onFilterChange={setActiveFilter}
              />
            </div>
          </div>
        </div>

        <div className="p-6">
          <HousingTable
            units={units}
            isLoading={housingQuery.isLoading}
            error={housingQuery.error}
            onView={(unit) => openModal("details", unit)}
            onEdit={(unit) => openModal("edit", unit)}
            onDelete={(unit) => openModal("delete", unit)}
          />
        </div>
      </section>

      <AddHousingModal
        isOpen={isAddModalOpen}
        isPending={createHousingMutation.isPending}
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={(values) => createHousingMutation.mutate(values)}
      />

      <HousingDetailsModal
        isOpen={activeModal === "details"}
        unit={selectedHousingQuery.data}
        isLoading={selectedHousingQuery.isLoading}
        error={selectedHousingQuery.error}
        onClose={handleCloseModal}
      />

      <EditHousingModal
        isOpen={activeModal === "edit"}
        unit={selectedHousingQuery.data}
        isLoading={selectedHousingQuery.isLoading}
        isPending={updateHousingMutation.isPending}
        error={selectedHousingQuery.error}
        onClose={handleCloseModal}
        onSubmit={(values) => updateHousingMutation.mutate(values)}
      />

      <DeleteHousingModal
        isOpen={activeModal === "delete"}
        unit={selectedUnitSnapshot}
        isPending={deleteHousingMutation.isPending}
        onClose={handleCloseModal}
        onConfirm={() => deleteHousingMutation.mutate()}
      />
    </div>
  );
}
