import { Filter } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  housingFilterOptions,
  type HousingFilter,
} from "@/constants/housing";

type HousingFilterBarProps = {
  activeFilter: HousingFilter;
  onFilterChange: (filter: HousingFilter) => void;
};

export function HousingFilterBar({
  activeFilter,
  onFilterChange,
}: HousingFilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wider text-muted bg-[var(--surface-muted)] rounded-lg border border-[var(--border)]">
        <Filter className="h-4 w-4" />
        Quick Filters
      </div>
      <div className="flex items-center gap-2">
        {housingFilterOptions.map((filter) => {
          const isActive = activeFilter === filter;
          return (
            <Button
              key={filter}
              variant={isActive ? "primary" : "ghost"}
              className={`px-4 h-10 rounded-lg text-sm font-medium transition-all ${
                isActive 
                  ? "bg-[var(--color-primary)] text-white shadow-md shadow-[var(--color-primary)]/20" 
                  : "hover:bg-[var(--surface-muted)]"
              }`}
              onClick={() => onFilterChange(filter)}
            >
              {filter === "ALL" ? "All units" : filter}
            </Button>
          );
        })}
      </div>
    </div>
  );
}
