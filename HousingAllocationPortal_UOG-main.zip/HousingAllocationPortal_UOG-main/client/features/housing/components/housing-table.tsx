import type { HousingUnit } from "@/lib/api/housing";
import { ApiError } from "@/lib/api/client";
import { HousingConditionBadge } from "@/features/housing/components/housing-condition-badge";
import { HousingRowActions } from "@/features/housing/components/housing-row-actions";
import { HousingStatusBadge } from "@/features/housing/components/housing-status-badge";
import { HEADINGS }  from "@/constants/housing";
type HousingTableProps = {
  units: HousingUnit[];
  isLoading: boolean;
  error: Error | null;
  onView: (unit: HousingUnit) => void;
  onEdit: (unit: HousingUnit) => void;
  onDelete: (unit: HousingUnit) => void;
};

export function HousingTable({
  units,
  isLoading,
  error,
  onView,
  onEdit,
  onDelete,
}: HousingTableProps) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-16 bg-[var(--surface-muted)]/30 rounded-xl border border-dashed border-[var(--border)]">
        <div className="h-8 w-8 border-4 border-[var(--surface-muted)] border-t-[var(--color-primary)] rounded-full animate-spin mb-4" />
        <span className="text-sm text-muted font-medium">Loading housing units...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 text-sm text-[var(--color-danger)] bg-[var(--color-danger)]/5 border border-[var(--color-danger)]/20 rounded-xl text-center">
        {error instanceof ApiError ? error.message : "Unable to load housing units."}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-[var(--border)] overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[var(--surface-muted)] border-b border-[var(--border)]">
              {HEADINGS.map((heading, index) => (
                <th
                  key={heading}
                  className={`px-5 py-4 text-xs font-semibold uppercase tracking-wider text-muted ${index === HEADINGS.length - 1 ? 'text-right' : ''}`}
                >
                  {heading}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--border)]">
            {units.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-6 py-16 text-center text-sm text-muted">
                  No housing assets found.
                </td>
              </tr>
            ) : (
              units.map((unit) => (
                <tr 
                  key={unit.id} 
                  className="hover:bg-[var(--surface-muted)]/50 transition-colors"
                >
                  <td className="px-5 py-4">
                    <span className="text-sm font-semibold text-[var(--color-primary)]">
                      {unit.buildingName}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-sm text-muted font-mono">{unit.blockNumber}</td>
                  <td className="px-5 py-4 text-sm text-muted font-mono">{unit.roomNumber}</td>
                  <td className="px-5 py-4 text-sm text-muted uppercase tracking-tight">{unit.roomType}</td>
                  <td className="px-5 py-4">
                    <HousingConditionBadge condition={unit.condition} />
                  </td>
                  <td className="px-5 py-4">
                    <HousingStatusBadge status={unit.status} />
                  </td>
                  <td className="px-5 py-4">
                    <span className="text-xs font-medium text-muted bg-[var(--surface-muted)] px-3 py-1.5 rounded-md border border-[var(--border)]">
                      {unit.location}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-right">
                    <HousingRowActions
                      onView={() => onView(unit)}
                      onEdit={() => onEdit(unit)}
                      onDelete={() => onDelete(unit)}
                    />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
