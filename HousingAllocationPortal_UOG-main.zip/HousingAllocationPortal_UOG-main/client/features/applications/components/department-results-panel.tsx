"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Download, Printer } from "lucide-react";
import * as XLSX from "xlsx";

import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { printTableData } from "@/lib/print-utils";
import { getApplicationFormOptions, getMyDepartmentResults } from "@/lib/api/applications";

export function DepartmentResultsPanel() {
  const [selectedRoundId, setSelectedRoundId] = useState("");

  const roundsQuery = useQuery({
    queryKey: ["lecturer-results-rounds"],
    queryFn: getApplicationFormOptions,
  });

  const resultsQuery = useQuery({
    queryKey: ["lecturer-college-results", selectedRoundId],
    queryFn: () => getMyDepartmentResults(selectedRoundId || undefined),
    enabled: selectedRoundId.length > 0,
    refetchInterval: 10000, // Auto-refresh every 10 seconds
    staleTime: 5000, // Data is considered stale after 5 seconds
  });

  const roundOptions = useMemo(
    () => [
      { label: "-- Select round --", value: "" },
      ...((roundsQuery.data?.rounds ?? []).map((round) => ({
        label: `${round.name} (${round.status})`,
        value: round.id,
      }))),
    ],
    [roundsQuery.data?.rounds],
  );

  if (roundsQuery.isLoading) {
    return <section className="panel p-8 text-sm text-muted">Loading rounds...</section>;
  }

  if (roundsQuery.isError) {
    return (
      <section className="panel p-8 text-sm text-[var(--color-danger)]">
        Could not load rounds.
      </section>
    );
  }

  if (!selectedRoundId) {
    return (
      <section className="panel overflow-hidden">
        <div className="p-6 border-b border-[var(--border)]">
          <h2 className="text-lg font-bold uppercase tracking-tight text-[var(--color-primary)]">
            Full Allocation Result
          </h2>
          <p className="mt-2 text-sm text-muted">
            Select a round to view your college results.
          </p>
        </div>
        <div className="p-6">
          <Select
            label="Application Round"
            options={roundOptions}
            value={selectedRoundId}
            onChange={(event) => setSelectedRoundId(event.target.value)}
          />
        </div>
      </section>
    );
  }

  if (resultsQuery.isLoading) {
    return <section className="panel p-8 text-sm text-muted">Loading college results...</section>;
  }

  if (resultsQuery.isError) {
    return (
      <section className="panel p-8 text-sm text-[var(--color-danger)]">
        Could not load college results.
      </section>
    );
  }

  const rows = resultsQuery.data ?? [];

  function handleExportResultsToExcel() {
    if (!rows || rows.length === 0) {
      toast.error("No results to export.");
      return;
    }

    try {
      // Prepare results data with complete allocation details
      const resultsData = rows.map((row, index) => ({
        "No.": index + 1,
        "Lecturer": row.lecturerName ?? row.lecturerUserId ?? "-",
        "College": row.lecturerDepartment ?? "-",
        "Round": row.roundName ?? "-",
        "Final Score": row.lecturerFinalScore ?? "-",
        "Rank": row.rankPosition ?? "-",
        "Building": row.housingBuildingName ?? "-",
        "Block": row.housingBlockNumber ?? "-",
        "Room": row.housingRoomNumber ?? "-",
        "Room Type": row.housingRoomType ?? "-",
        "Location": row.housingLocation ?? "-",
        "Allocation Status": "Allocated",
        "Allocated At": row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-",
      }));

      // Create workbook
      const ws = XLSX.utils.json_to_sheet(resultsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Results");

      // Add summary sheet
      const summaryData = [
        ["College Allocation Results"],
        [],
        ["Results Summary"],
        ["Total Records", rows.length],
        ["Generated At", new Date().toLocaleString()],
      ];

      const summarySh = XLSX.utils.aoa_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, summarySh, "Summary");

      // Download
      XLSX.writeFile(wb, `College-Allocation-Results-${new Date().toISOString().split("T")[0]}.xlsx`);
      toast.success("Results exported to Excel successfully.");
    } catch (error) {
      toast.error("Failed to export results to Excel.");
      console.error(error);
    }
  }

  function handlePrintResults() {
    if (!rows || rows.length === 0) {
      toast.error("No results to print.");
      return;
    }

    try {
      const data = rows.map((row) => ({
        "Lecturer": row.lecturerName ?? row.lecturerUserId ?? "-",
        "College": row.lecturerDepartment ?? "-",
        "Round": row.roundName ?? "-",
        "Final Score": row.lecturerFinalScore ?? "-",
        "Rank": row.rankPosition ?? "-",
        "Building": row.housingBuildingName ?? "-",
        "Block": row.housingBlockNumber ?? "-",
        "Room": row.housingRoomNumber ?? "-",
        "Room Type": row.housingRoomType ?? "-",
        "Location": row.housingLocation ?? "-",
        "Allocation Status": "Allocated",
        "Allocated At": row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-",
      }));

      printTableData(
        data,
        "College Allocation Results",
        {
          "Total Records": rows.length.toString(),
          "Generated": new Date().toLocaleString(),
        }
      );
      toast.success("Printing results...");
    } catch {
      toast.error("Failed to print results.");
    }
  }

  return (
    <section className="panel overflow-hidden">
      <div className="p-6 border-b border-[var(--border)]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold uppercase tracking-tight text-[var(--color-primary)]">
              Allocation Results
            </h2>
          </div>
          <div className="w-72">
            <Select
              label="Application Round"
              options={roundOptions}
              value={selectedRoundId}
              onChange={(event) => setSelectedRoundId(event.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handleExportResultsToExcel}
              disabled={!rows || rows.length === 0}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Excel
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={handlePrintResults}
              disabled={!rows || rows.length === 0}
              className="flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print
            </Button>
          </div>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="p-8 text-sm text-muted">
          No allocation results found for your college.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[var(--surface-muted)] border-b border-[var(--border)]">
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Lecturer
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  College
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Round
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Final Score
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Rank
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Building
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Block
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Room
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Room Type
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Location
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Status
                </th>
                <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                  Allocated At
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {rows.map((row) => (
                <tr key={row.allocationResultId}>
                  <td className="px-4 py-4 text-sm text-[var(--color-primary)]">
                    {row.lecturerName ?? row.lecturerUserId ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.lecturerDepartment ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm font-semibold text-[var(--color-primary)]">
                    {row.roundName ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm font-semibold text-[var(--color-primary)]">
                    {row.lecturerFinalScore ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm font-semibold text-[var(--color-primary)]">
                    {row.rankPosition ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.housingBuildingName ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.housingBlockNumber ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.housingRoomNumber ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.housingRoomType ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.housingLocation ?? "-"}
                  </td>
                  <td className="px-4 py-4 text-xs font-semibold uppercase tracking-wide text-[var(--color-primary)]">
                    Allocated
                  </td>
                  <td className="px-4 py-4 text-sm text-muted">
                    {row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
