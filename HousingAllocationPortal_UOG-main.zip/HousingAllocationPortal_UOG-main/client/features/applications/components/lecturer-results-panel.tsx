"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Download, Printer } from "lucide-react";
import * as XLSX from "xlsx";

import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { printTableData } from "@/lib/print-utils";
import { getApplicationFormOptions, getMyAllocationResults } from "@/lib/api/applications";

export function LecturerResultsPanel() {
  const [selectedRoundId, setSelectedRoundId] = useState("");

  const roundsQuery = useQuery({
    queryKey: ["lecturer-results-rounds"],
    queryFn: getApplicationFormOptions,
  });

  const allocationResultsQuery = useQuery({
    queryKey: ["lecturer-allocation-results", selectedRoundId],
    queryFn: () => getMyAllocationResults(selectedRoundId || undefined),
    enabled: selectedRoundId.length > 0,
    refetchInterval: 10000,
    staleTime: 5000,
  });

  const roundOptions = useMemo(
    () => [
      { label: "-- Select round --", value: "" },
      ...((roundsQuery.data?.rounds ?? []).map((round) => ({
        label: `${round.name} (${round.status})`,
        value: round.id,
      })) ?? []),
    ],
    [roundsQuery.data?.rounds],
  );

  const rows = allocationResultsQuery.data ?? [];

  function handleExportToExcel() {
    if (!rows || rows.length === 0) {
      toast.error("No results to export.");
      return;
    }

    try {
      const resultsData = rows.map((row, index) => ({
        "No.": index + 1,
        "Lecturer": row.lecturerName ?? row.lecturerUserId ?? "-",
        "College": row.lecturerDepartment ?? "-",
        "Rank": row.rankPosition ?? "-",
        "Status": row.allocationStatus ?? "-",
        "Allocation Date": row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-",
        "Score": row.lecturerFinalScore != null ? row.lecturerFinalScore.toFixed(2) : "-",
      }));

      const ws = XLSX.utils.json_to_sheet(resultsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "My Results");

      const summaryData = [
        ["My Allocation Results"],
        [],
        ["Results Summary"],
        ["Total Records", rows.length],
        ["Generated At", new Date().toLocaleString()],
      ];

      const summarySh = XLSX.utils.aoa_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, summarySh, "Summary");

      XLSX.writeFile(wb, `Lecturer-Allocation-Results-${new Date().toISOString().split("T")[0]}.xlsx`);
      toast.success("Results exported to Excel successfully.");
    } catch (error) {
      console.error(error);
      toast.error("Failed to export results to Excel.");
    }
  }

  function handlePrint() {
    if (!rows || rows.length === 0) {
      toast.error("No results to print.");
      return;
    }

    try {
      const data = rows.map((row) => ({
        "Lecturer": row.lecturerName ?? row.lecturerUserId ?? "-",
        "College": row.lecturerDepartment ?? "-",
        "Rank": row.rankPosition ?? "-",
        "Status": row.allocationStatus ?? "-",
        "Allocation Date": row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-",
        "Score": row.lecturerFinalScore != null ? row.lecturerFinalScore.toFixed(2) : "-",
      }));

      printTableData(
        data,
        "My Result",
        {
          "Total Records": rows.length.toString(),
          "Generated": new Date().toLocaleString(),
        }
      );
      toast.success("Printing results...");
    } catch (error) {
      console.error(error);
      toast.error("Failed to print results.");
    }
  }

  if (roundsQuery.isLoading) {
    return <section className="panel p-8 text-sm text-muted">Loading rounds...</section>;
  }

  if (roundsQuery.isError) {
    return (
      <section className="panel p-8 text-sm text-[var(--color-danger)]">
        Could not load rounds.
      </section>
    );
  }

  return (
    <section className="panel overflow-hidden">
      <div className="p-6 border-b border-[var(--border)]">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-lg font-bold uppercase tracking-tight text-[var(--color-primary)]">
              My Results
            </h2>
            <p className="mt-2 text-sm text-muted">
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handleExportToExcel}
              disabled={!rows || rows.length === 0}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Excel
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={handlePrint}
              disabled={!rows || rows.length === 0}
              className="flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Select
          label="Application Round"
          options={roundOptions}
          value={selectedRoundId}
          onChange={(event) => setSelectedRoundId(event.target.value)}
        />

        {!selectedRoundId ? (
          <p className="text-sm text-muted">Select a round to view your allocation results.</p>
        ) : allocationResultsQuery.isLoading ? (
          <p className="text-sm text-muted">Loading your allocation results...</p>
        ) : allocationResultsQuery.isError ? (
          <div className="space-y-2 text-sm text-[var(--color-danger)]">
            <p>Could not load your allocation results.</p>
            <p className="text-xs text-[var(--color-danger)] opacity-90">
              {allocationResultsQuery.error instanceof Error
                ? allocationResultsQuery.error.message
                : JSON.stringify(allocationResultsQuery.error)}
            </p>
          </div>
        ) : !rows || rows.length === 0 ? (
          <p className="text-sm text-muted">No allocation results found for the selected round.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[var(--surface-muted)] border-b border-[var(--border)]">
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Lecturer
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    College
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Rank
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Status
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Score
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)]">
                {rows.map((row) => (
                  <tr key={row.allocationResultId}>
                    <td className="px-4 py-4 text-sm text-[var(--color-primary)]">
                      {row.lecturerName ?? row.lecturerUserId ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.lecturerDepartment ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.rankPosition != null ? row.rankPosition : "-"}
                    </td>
                    <td className="px-4 py-4 text-xs font-semibold uppercase tracking-wide text-[var(--color-primary)]">
                      {row.allocationStatus ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.lecturerFinalScore != null ? row.lecturerFinalScore.toFixed(2) : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
