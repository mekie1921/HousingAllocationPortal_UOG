"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Download, Printer } from "lucide-react";
import * as XLSX from "xlsx";

import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { printTableData } from "@/lib/print-utils";
import {
  getOfficerAllocationResults,
  getOfficerManagedRounds,
  type OfficerAllocationResult,
  type OfficerManagedRound,
} from "@/lib/api/officer";

export function OfficerAllocationViewPanel() {
  const [selectedRoundId, setSelectedRoundId] = useState("");

  const roundsQuery = useQuery({
    queryKey: ["officer-managed-rounds"],
    queryFn: getOfficerManagedRounds,
  });

  const allocationResultsQuery = useQuery({
    queryKey: ["officer-allocation-results", selectedRoundId],
    queryFn: () => getOfficerAllocationResults(selectedRoundId),
    enabled: selectedRoundId.length > 0,
    refetchInterval: 10000, // Auto-refresh every 10 seconds for real-time updates
    staleTime: 5000,
  });

  const roundOptions = useMemo(
    () => [
      { label: "-- Select round --", value: "" },
      ...(roundsQuery.data?.map((round) => ({
        label: `${round.name} (${round.status} - ${round.committeeRankingStatus})`,
        value: round.id,
      })) ?? []),
    ],
    [roundsQuery.data],
  );

  const rows = allocationResultsQuery.data ?? [];

  function handleExportToExcel() {
    if (!rows || rows.length === 0) {
      toast.error("No results to export.");
      return;
    }

    try {
      const resultsData = rows.map((row, index) => ({
        "No.": index + 1,
        "Lecturer": row.lecturerName ?? row.applicationId ?? "-",
        "House": row.housingBuildingName
          ? `${row.housingBuildingName} / Block ${row.housingBlockNumber ?? "-"} / Room ${row.housingRoomNumber ?? "-"}`
          : "-",
        "College": row.lecturerDepartment ?? "-",
        "Rank": row.rankPosition ?? "-",
        "Status": "Allocated",
        "Allocation Date": row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-",
        "Score": row.score != null ? row.score.toFixed(2) : "-",
      }));

      const ws = XLSX.utils.json_to_sheet(resultsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Allocation Results");

      const summaryData = [
        ["Officer Allocation Results"],
        [],
        ["Results Summary"],
        ["Total Records", rows.length],
        ["Generated At", new Date().toLocaleString()],
      ];

      const summarySh = XLSX.utils.aoa_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, summarySh, "Summary");

      XLSX.writeFile(wb, `Officer-Allocation-Results-${new Date().toISOString().split("T")[0]}.xlsx`);
      toast.success("Results exported to Excel successfully.");
    } catch (error) {
      toast.error("Failed to export results to Excel.");
      console.error(error);
    }
  }

  function handlePrint() {
    if (!rows || rows.length === 0) {
      toast.error("No results to print.");
      return;
    }

    try {
      const data = rows.map((row) => ({
        "Lecturer": row.lecturerName ?? row.applicationId ?? "-",
        "House": row.housingBuildingName
          ? `${row.housingBuildingName} / Block ${row.housingBlockNumber ?? "-"} / Room ${row.housingRoomNumber ?? "-"}`
          : "-",
        "College": row.lecturerDepartment ?? "-",
        "Rank": row.rankPosition ?? "-",
        "Status": "Allocated",
        "Allocation Date": row.allocatedAt ? new Date(row.allocatedAt).toLocaleString() : "-",
        "Score": row.score != null ? row.score.toFixed(2) : "-",
      }));

      printTableData(
        data,
        "Officer Allocation Results",
        {
          "Total Records": rows.length.toString(),
          "Generated": new Date().toLocaleString(),
        }
      );
      toast.success("Printing results...");
    } catch (error) {
      toast.error("Failed to print results.");
    }
  }

  return (
    <section className="panel overflow-hidden">
      <div className="p-6 border-b border-[var(--border)]">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold uppercase tracking-tight text-[var(--color-primary)]">
              Officer Allocation Results
            </h2>
            <p className="mt-2 text-sm text-muted">
              Real-time allocation results from officer dashboard.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={handleExportToExcel}
              disabled={!rows || rows.length === 0}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Excel
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={handlePrint}
              disabled={!rows || rows.length === 0}
              className="flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <Select
          label="Allocation Round"
          options={roundOptions}
          value={selectedRoundId}
          onChange={(event) => setSelectedRoundId(event.target.value)}
        />

        {!selectedRoundId ? (
          <p className="text-sm text-muted">Select a round to view allocation results.</p>
        ) : allocationResultsQuery.isLoading ? (
          <p className="text-sm text-muted">Loading allocation results...</p>
        ) : allocationResultsQuery.isError ? (
          <p className="text-sm text-[var(--color-danger)]">
            Could not load allocation results.
          </p>
        ) : !allocationResultsQuery.data || allocationResultsQuery.data.length === 0 ? (
          <p className="text-sm text-muted">No allocation results for this round yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[var(--surface-muted)] border-b border-[var(--border)]">
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Lecturer
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    House
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    College
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Rank
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Status
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Allocation Date
                  </th>
                  <th className="px-4 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-muted">
                    Score
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--border)]">
                {rows.map((row) => (
                  <tr key={row.id}>
                    <td className="px-4 py-4 text-sm text-[var(--color-primary)]">
                      {row.lecturerName ?? row.applicationId}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.housingBuildingName} / Block {row.housingBlockNumber} / Room{" "}
                      {row.housingRoomNumber}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.lecturerDepartment ?? "-"}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.rankPosition != null ? row.rankPosition : "-"}
                    </td>
                    <td className="px-4 py-4 text-xs font-semibold uppercase tracking-wide text-[var(--color-primary)]">
                      Allocated
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {new Date(row.allocatedAt).toLocaleString()}
                    </td>
                    <td className="px-4 py-4 text-sm text-muted">
                      {row.score != null ? row.score.toFixed(2) : "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
