"use client";

import React, { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CheckCircle, Clock, FileText, Send, Calendar, AlertCircle, Eye, User, GraduationCap, Edit, Award, Download, FolderOpen, Printer } from "lucide-react";
import * as XLSX from "xlsx";

import { Button } from "@/components/ui/button";
import { ApiError } from "@/lib/api/client";
import { printTableData } from "@/lib/print-utils";
import {
  openMyDocument,
  downloadMyDocument,
} from "@/lib/api/documents";
import {
  type ApplicationFormDataSnapshot,
  getMyApplications,
  submitApplication,
  getMyApplicationDetails,
  type MyApplicationDetailsResponse,
  type MyApplicationRow,
} from "@/lib/api/applications";

type ScoreBreakdownRow = {
  criteria?: string;
  score?: number;
};

function formatDate(value: string | null) {
  if (!value) {
    return "-";
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return date.toLocaleString();
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function housingLabel(application: MyApplicationRow) {
  if (!application.preferredHousingBuildingName) {
    return "General request";
  }

  return `${application.preferredHousingBuildingName} / Block ${application.preferredHousingBlockNumber ?? "-"} / Room ${application.preferredHousingRoomNumber ?? "-"}`;
}

function getStatusColor(status: string) {
  switch (status) {
    case "DRAFT":
      return "bg-gray-100 text-gray-700 border-gray-200";
    case "SUBMITTED":
      return "bg-blue-100 text-blue-700 border-blue-200";
    case "UNDER_REVIEW":
      return "bg-yellow-100 text-yellow-700 border-yellow-200";
    case "RANKED":
      return "bg-purple-100 text-purple-700 border-purple-200";
    case "ALLOCATED":
      return "bg-green-100 text-green-700 border-green-200";
    case "REJECTED":
      return "bg-red-100 text-red-700 border-red-200";
    case "WITHDRAWN":
      return "bg-gray-100 text-gray-700 border-gray-200";
    default:
      return "bg-gray-100 text-gray-700 border-gray-200";
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case "DRAFT":
      return <FileText className="w-4 h-4" />;
    case "SUBMITTED":
      return <Send className="w-4 h-4" />;
    case "UNDER_REVIEW":
      return <Clock className="w-4 h-4" />;
    case "RANKED":
      return <Award className="w-4 h-4" />;
    case "ALLOCATED":
      return <CheckCircle className="w-4 h-4" />;
    case "REJECTED":
      return <AlertCircle className="w-4 h-4" />;
    case "WITHDRAWN":
      return <AlertCircle className="w-4 h-4" />;
    default:
      return <FileText className="w-4 h-4" />;
  }
}

function displayValue(value: string | number | boolean | null | undefined) {
  if (value === null || value === undefined) {
    return "-";
  }

  if (typeof value === "boolean") {
    return value ? "Yes" : "No";
  }

  const trimmed = String(value).trim();
  return trimmed.length > 0 ? trimmed : "-";
}

function formatEnumLabel(value: string | null | undefined) {
  if (!value) {
    return "-";
  }

  return value
    .toLowerCase()
    .split("_")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function parseApplicationFormDataFromNotes(notes: string | null): ApplicationFormDataSnapshot | null {
  if (!notes) {
    return null;
  }

  try {
    const parsed = JSON.parse(notes) as ApplicationFormDataSnapshot & {
      originalNotes?: string;
    };

    if (typeof parsed.originalNotes === "string") {
      return parseApplicationFormDataFromNotes(parsed.originalNotes);
    }

    return parsed;
  } catch {
    return null;
  }
}

function getCriterionScore(
  scoreBreakdown: unknown,
  labels: string[],
) {
  if (!Array.isArray(scoreBreakdown)) {
    return "-";
  }

  const rows = scoreBreakdown as ScoreBreakdownRow[];
  const match = rows.find((row) => {
    const criteria = row.criteria?.trim().toLowerCase();
    return criteria ? labels.some((label) => criteria === label.toLowerCase()) : false;
  });

  return typeof match?.score === "number" ? String(match.score) : "-";
}

// Component to display detailed application form data from database
function ApplicationDetails({ application }: { application: MyApplicationRow }) {
  const [showDetails, setShowDetails] = React.useState(false);

  const detailsQuery = useQuery<MyApplicationDetailsResponse>({
    queryKey: ["my-application-details", application.id],
    queryFn: () => getMyApplicationDetails(application.id),
    enabled: showDetails,
  });

  function handleExportDetailsToExcel() {
    if (!detailsQuery.data) {
      toast.error("Application details not loaded. Please click 'Show Complete Form Data' first.");
      return;
    }

    try {
      const formData = detailsQuery.data?.formData;
      const scoreBreakdown = detailsQuery.data?.scoreBreakdown;

      // Create workbook
      const wb = XLSX.utils.book_new();

      // Sheet 1: Personal Information
      const personalData = [
        ["PERSONAL INFORMATION"],
        [],
        ["Information Type", "Information", "Points"],
        ["Full Name", displayValue(formData?.fullName), "-"],
        ["Staff ID", displayValue(formData?.staffId ?? detailsQuery.data.userId), "-"],
        ["Email", displayValue(formData?.email), "-"],
        ["Phone Number", displayValue(formData?.phoneNumber), "-"],
      ];
      const personalSheet = XLSX.utils.aoa_to_sheet(personalData);
      personalSheet["!cols"] = [{ wch: 20 }, { wch: 30 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, personalSheet, "Personal Info");

      // Sheet 2: Academic Information
      const academicData = [
        ["ACADEMIC INFORMATION"],
        [],
        ["Information Type", "Information", "Points"],
        ["College", displayValue(formData?.college), "-"],
        ["College / Unit", displayValue(formData?.department), "-"],
        ["Educational Title", displayValue(formData?.educationalTitle), getCriterionScore(scoreBreakdown, ["Educational Title"])],
        ["Educational Level", displayValue(formData?.educationalLevel), getCriterionScore(scoreBreakdown, ["Educational Level"])],
        ["Start Date at UOG", displayValue(formData?.startDateAtUog ? formatDate(formData.startDateAtUog) : null), getCriterionScore(scoreBreakdown, ["Service Years"])],
        ["Responsibility", displayValue(formatEnumLabel(formData?.responsibility)), getCriterionScore(scoreBreakdown, ["Responsibility"])],
        ["Family Status", displayValue(formatEnumLabel(formData?.familyStatus)), getCriterionScore(scoreBreakdown, ["Family Status"])],
      ];
      const academicSheet = XLSX.utils.aoa_to_sheet(academicData);
      academicSheet["!cols"] = [{ wch: 20 }, { wch: 30 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, academicSheet, "Academic Info");

      // Sheet 3: Additional Information
      const additionalData = [
        ["ADDITIONAL INFORMATION"],
        [],
        ["Information Type", "Information", "Points"],
        ["Spouse Name", displayValue(formData?.spouseName), "-"],
        ["Spouse Staff ID", displayValue(formData?.spouseStaffId), "-"],
        ["Number of Dependents", displayValue(formData?.numberOfDependents), "-"],
        ["Female", displayValue(formData?.isFemale), getCriterionScore(scoreBreakdown, ["Female Bonus"])],
        ["Disabled", displayValue(formData?.isDisabled), getCriterionScore(scoreBreakdown, ["Disability Bonus"])],
        ["Has Chronic Illness", displayValue(formData?.hasChronicIllness), getCriterionScore(scoreBreakdown, ["Chronic Illness Bonus"])],
        ["Spouse at UOG", displayValue(formData?.hasSpouseAtUog), getCriterionScore(scoreBreakdown, ["Spouse Bonus"])],
      ];
      const additionalSheet = XLSX.utils.aoa_to_sheet(additionalData);
      additionalSheet["!cols"] = [{ wch: 20 }, { wch: 30 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, additionalSheet, "Additional Info");

      // Sheet 4: Score Breakdown
      const scoreData = [
        ["SCORE BREAKDOWN"],
        [],
        ["Score Type", "Points"],
        ["Base Score", detailsQuery.data.scoreBaseTotal ?? 0],
        ["Bonus Score", `+${detailsQuery.data.scoreBonusTotal ?? 0}`],
        ["Final Score", `${detailsQuery.data.scoreFinal ?? 0}/100`],
      ];
      const scoreSheet = XLSX.utils.aoa_to_sheet(scoreData);
      scoreSheet["!cols"] = [{ wch: 20 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, scoreSheet, "Score");

      // Sheet 5: Documents
      const documentsData = [
        ["UPLOADED DOCUMENTS"],
        [],
        ["File Name", "Purpose"],
        ...(detailsQuery.data?.documents && detailsQuery.data.documents.length > 0
          ? detailsQuery.data.documents.map((doc) => [displayValue(doc.originalFileName), displayValue(doc.purpose)])
          : [["No documents uploaded", "-"]]),
      ];
      const documentsSheet = XLSX.utils.aoa_to_sheet(documentsData);
      documentsSheet["!cols"] = [{ wch: 30 }, { wch: 25 }];
      XLSX.utils.book_append_sheet(wb, documentsSheet, "Documents");

      // Download
      const fileName = `Application-Details-${application.id}-${new Date().toISOString().split("T")[0]}.xlsx`;
      XLSX.writeFile(wb, fileName);
      toast.success("✅ All 5 sheets exported successfully!");
    } catch (error) {
      console.error("Export error:", error);
      toast.error("Failed to export application details to Excel. Please try again.");
    }
  }

  function handlePrintDetails() {
    if (!detailsQuery.data) {
      toast.error("Application details not loaded.");
      return;
    }

    try {
      const formData = detailsQuery.data?.formData;
      const scoreBreakdown = detailsQuery.data?.scoreBreakdown;

      // Build comprehensive data array for printing
      const printData = [
        // Personal Information
        { Section: "PERSONAL INFORMATION", Type: "Full Name", Value: displayValue(formData?.fullName), Points: "-" },
        { Section: "", Type: "Staff ID", Value: displayValue(formData?.staffId ?? detailsQuery.data.userId), Points: "-" },
        { Section: "", Type: "Email", Value: displayValue(formData?.email), Points: "-" },
        { Section: "", Type: "Phone Number", Value: displayValue(formData?.phoneNumber), Points: "-" },
        // Academic Information
        { Section: "ACADEMIC INFORMATION", Type: "College", Value: displayValue(formData?.college), Points: "-" },
        { Section: "", Type: "College / Unit", Value: displayValue(formData?.department), Points: "-" },
        { Section: "", Type: "Educational Title", Value: displayValue(formData?.educationalTitle), Points: getCriterionScore(scoreBreakdown, ["Educational Title"]) },
        { Section: "", Type: "Educational Level", Value: displayValue(formData?.educationalLevel), Points: getCriterionScore(scoreBreakdown, ["Educational Level"]) },
        { Section: "", Type: "Start Date at UOG", Value: displayValue(formData?.startDateAtUog ? formatDate(formData.startDateAtUog) : null), Points: getCriterionScore(scoreBreakdown, ["Service Years"]) },
        { Section: "", Type: "Responsibility", Value: displayValue(formatEnumLabel(formData?.responsibility)), Points: getCriterionScore(scoreBreakdown, ["Responsibility"]) },
        { Section: "", Type: "Family Status", Value: displayValue(formatEnumLabel(formData?.familyStatus)), Points: getCriterionScore(scoreBreakdown, ["Family Status"]) },
        // Additional Information
        { Section: "ADDITIONAL INFORMATION", Type: "Spouse Name", Value: displayValue(formData?.spouseName), Points: "-" },
        { Section: "", Type: "Spouse Staff ID", Value: displayValue(formData?.spouseStaffId), Points: "-" },
        { Section: "", Type: "Number of Dependents", Value: displayValue(formData?.numberOfDependents), Points: "-" },
        { Section: "", Type: "Female", Value: displayValue(formData?.isFemale), Points: getCriterionScore(scoreBreakdown, ["Female Bonus"]) },
        { Section: "", Type: "Disabled", Value: displayValue(formData?.isDisabled), Points: getCriterionScore(scoreBreakdown, ["Disability Bonus"]) },
        { Section: "", Type: "Has Chronic Illness", Value: displayValue(formData?.hasChronicIllness), Points: getCriterionScore(scoreBreakdown, ["Chronic Illness Bonus"]) },
        { Section: "", Type: "Spouse at UOG", Value: displayValue(formData?.hasSpouseAtUog), Points: getCriterionScore(scoreBreakdown, ["Spouse Bonus"]) },
        // Score Breakdown
        { Section: "SCORE BREAKDOWN", Type: "Base Score", Value: String(detailsQuery.data.scoreBaseTotal ?? 0), Points: "-" },
        { Section: "", Type: "Bonus Score", Value: `+${detailsQuery.data.scoreBonusTotal ?? 0}`, Points: "-" },
        { Section: "", Type: "Final Score", Value: `${detailsQuery.data.scoreFinal ?? 0}/100`, Points: "-" },
      ];

      printTableData(
        printData,
        "Complete Application Form Data",
        {
          "Application ID": application.id,
          "Round": application.roundName || "-",
          "Status": application.status || "-",
          "Generated": new Date().toLocaleString(),
        }
      );
      toast.success("Printing application details...");
    } catch (error) {
      toast.error("Failed to print application details.");
      console.error(error);
    }
  }

  const openMutation = useMutation({
    mutationFn: (documentId: string) => openMyDocument(documentId),
    onError: (error) => {
      const message = error instanceof ApiError ? error.message : "Could not open document.";
      toast.error(message);
    },
  });

  const downloadMutation = useMutation({
    mutationFn: ({ documentId, fileName }: { documentId: string; fileName: string }) =>
      downloadMyDocument(documentId, fileName),
    onError: (error) => {
      const message = error instanceof ApiError ? error.message : "Could not download document.";
      toast.error(message);
    },
  });

  const parsedNotesFormData = detailsQuery.data
    ? parseApplicationFormDataFromNotes(detailsQuery.data.notes)
    : null;
  const formData = detailsQuery.data?.formData ?? parsedNotesFormData;
  const scoreBreakdown = detailsQuery.data?.scoreBreakdown;

  return (
    <div className="mt-4 w-full">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="px-6 py-3 bg-[var(--color-primary)] hover:bg-[var(--color-primary-dark)] text-white font-semibold rounded-xl shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2"
        >
          <Eye className="w-5 h-5" />
          <span>{showDetails ? "Hide" : "Show"} Complete Form Data</span>
        </button>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={handleExportDetailsToExcel}
            disabled={!showDetails || !detailsQuery.data}
            className="flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Excel
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handlePrintDetails}
            disabled={!showDetails || !detailsQuery.data}
            className="flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            Print
          </Button>
        </div>
      </div>

      {showDetails && (
        <>
          {detailsQuery.isLoading ? (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden w-full">
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 w-full">
                <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-gray-600" />
                  Complete Application Form Data
                </h4>
              </div>
              <div className="p-6">
                <p className="text-sm text-gray-600">Loading details...</p>
              </div>
            </div>
          ) : detailsQuery.isError || !detailsQuery.data ? (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden w-full">
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 w-full">
                <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-gray-600" />
                  Complete Application Form Data
                </h4>
              </div>
              <div className="p-6">
                <p className="text-sm text-gray-600">Could not load application details</p>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden w-full">
              {/* HEADER */}
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 w-full">
                <h4 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-gray-600" />
                  Complete Application Form Data
                </h4>
              </div>

              {/* BODY - FULL FRAME TABLES */}
              <div className="p-2 space-y-3 w-full">

                {/* PERSONAL INFORMATION */}
                <div className="w-full">
                  <h5 className="text-md font-semibold text-gray-800 mb-2 flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-600" />
                    Personal Information
                  </h5>

                  <div className="bg-gray-50 rounded-lg overflow-hidden w-full">
                    <table className="w-full">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Information Type</th>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Information</th>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Points</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Full Name</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.fullName)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Staff ID</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.staffId ?? detailsQuery.data.userId)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Email</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.email)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Phone Number</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.phoneNumber)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* ACADEMIC INFORMATION */}
                <div className="w-full">
                  <h5 className="text-md font-semibold text-gray-800 mb-2 flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-gray-600" />
                    Academic Information
                  </h5>

                  <div className="bg-gray-50 rounded-lg overflow-hidden w-full">
                    <table className="w-full">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Information Type</th>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Information</th>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Points</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">College</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.college)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">College / Unit</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.department)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Educational Title</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.educationalTitle)}</td>
                          <td className="px-4 py-3 text-green-600 font-semibold">{getCriterionScore(scoreBreakdown, ["Educational Title"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Educational Level</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.educationalLevel)}</td>
                          <td className="px-4 py-3 text-green-600 font-semibold">{getCriterionScore(scoreBreakdown, ["Educational Level"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Start Date at UOG</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.startDateAtUog ? formatDate(formData.startDateAtUog) : null)}</td>
                          <td className="px-4 py-3 text-green-600 font-semibold">{getCriterionScore(scoreBreakdown, ["Service Years"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Responsibility</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formatEnumLabel(formData?.responsibility))}</td>
                          <td className="px-4 py-3 text-green-600 font-semibold">{getCriterionScore(scoreBreakdown, ["Responsibility"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Family Status</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formatEnumLabel(formData?.familyStatus))}</td>
                          <td className="px-4 py-3 text-green-600 font-semibold">{getCriterionScore(scoreBreakdown, ["Family Status"])}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* ADDITIONAL INFORMATION */}
                <div className="w-full">
                  <h5 className="text-md font-semibold text-gray-800 mb-2">Additional Information</h5>

                  <div className="bg-gray-50 rounded-lg overflow-hidden w-full">
                    <table className="w-full">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Information Type</th>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Information</th>
                          <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Points</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Spouse Name</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.spouseName)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Spouse Staff ID</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.spouseStaffId)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Number of Dependents</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.numberOfDependents)}</td>
                          <td className="px-4 py-3 text-gray-600">-</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Female</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.isFemale)}</td>
                          <td className="px-4 py-3 text-gray-600">{getCriterionScore(scoreBreakdown, ["Female Bonus"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Disabled</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.isDisabled)}</td>
                          <td className="px-4 py-3 text-gray-600">{getCriterionScore(scoreBreakdown, ["Disability Bonus"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Has Chronic Illness</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.hasChronicIllness)}</td>
                          <td className="px-4 py-3 text-gray-600">{getCriterionScore(scoreBreakdown, ["Chronic Illness Bonus"])}</td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 font-medium text-gray-700">Spouse at UOG</td>
                          <td className="px-4 py-3 text-gray-900">{displayValue(formData?.hasSpouseAtUog)}</td>
                          <td className="px-4 py-3 text-gray-600">{getCriterionScore(scoreBreakdown, ["Spouse Bonus"])}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* SCORE INFORMATION */}
                {detailsQuery.data?.scoreFinal !== null && (
                  <div className="w-full">
                    <h5 className="text-md font-semibold text-gray-800 mb-2 flex items-center gap-2">
                      <Award className="w-4 h-4 text-gray-600" />
                      Score Breakdown
                    </h5>

                    <div className="bg-blue-50 rounded-lg overflow-hidden w-full border border-blue-200">
                      <table className="w-full">
                        <thead className="bg-blue-100">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-semibold text-blue-700 w-1/2">Score Type</th>
                            <th className="px-4 py-2 text-left text-xs font-semibold text-blue-700 w-1/2">Points</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-blue-200">
                          <tr>
                            <td className="px-4 py-3 font-medium text-blue-900">Base Score</td>
                            <td className="px-4 py-3 text-xl font-bold text-blue-900">{detailsQuery.data.scoreBaseTotal ?? 0}</td>
                          </tr>
                          <tr>
                            <td className="px-4 py-3 font-medium text-blue-900">Bonus Score</td>
                            <td className="px-4 py-3 text-xl font-bold text-green-600">+{detailsQuery.data.scoreBonusTotal ?? 0}</td>
                          </tr>
                          <tr className="bg-blue-100">
                            <td className="px-4 py-3 font-bold text-blue-900">Final Score</td>
                            <td className="px-4 py-3 text-2xl font-bold text-blue-900">{detailsQuery.data.scoreFinal ?? 0}/100</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* DOCUMENTS */}
                <div className="w-full">
                  <h5 className="text-md font-semibold text-gray-800 mb-2 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-gray-600" />
                    Uploaded Documents
                  </h5>

                  {detailsQuery.data?.documents && detailsQuery.data.documents.length === 0 ? (
                    <p className="text-sm text-gray-600">No documents uploaded for this application.</p>
                  ) : (
                    <div className="bg-gray-50 rounded-lg overflow-hidden w-full border border-gray-200">
                      <table className="w-full">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">File Name</th>
                            <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Purpose</th>
                            <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 w-1/3">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {detailsQuery.data?.documents?.map((doc) => (
                            <tr key={doc.id}>
                              <td className="px-4 py-3 font-medium text-gray-700">{doc.originalFileName}</td>
                              <td className="px-4 py-3 text-gray-900">{doc.purpose}</td>
                              <td className="px-4 py-3">
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    onClick={() => openMutation.mutate(doc.id)}
                                    busy={openMutation.isPending && openMutation.variables === doc.id}
                                  >
                                    <FolderOpen className="w-4 h-4 mr-1" />
                                    Open
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="primary"
                                    onClick={() => downloadMutation.mutate({ documentId: doc.id, fileName: doc.originalFileName })}
                                    busy={downloadMutation.isPending && downloadMutation.variables?.documentId === doc.id}
                                  >
                                    <Download className="w-4 h-4 mr-1" />
                                    Download
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export function MyApplicationsPanel() {
  const queryClient = useQueryClient();
  
  const {
    data: applications,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery({
    queryKey: ["my-applications"],
    queryFn: async () => {
      console.log('Fetching applications...');
      try {
        const result = await getMyApplications();
        console.log('Applications fetched successfully:', result);
        console.log('Number of applications:', Array.isArray(result) ? result.length : 'Not an array');
        return result ?? [];
      } catch (err) {
        if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
          if (typeof window !== 'undefined') {
            window.location.replace('/auth/login');
          }
          return [];
        }
        console.error('Error in queryFn:', err);
        throw err;
      }
    },
    retry: (failureCount, error) => {
      // Don't retry on authentication errors
      if (error instanceof ApiError && (error.status === 401 || error.status === 403)) {
        return false;
      }
      return failureCount < 3;
    },
  });

  // Auto-refresh on mount
  useEffect(() => {
    refetch();
  }, [refetch]);

  const submitMutation = useMutation({
    mutationFn: submitApplication,
    onSuccess: () => {
      toast.success("Application submitted.");
      queryClient.invalidateQueries({ queryKey: ["my-applications"] });
    },
    onError: (error) => {
      const message =
        error instanceof ApiError ? error.message : "Failed to submit application.";
      toast.error(message);
    },
  });

  const firstApplication = applications?.[0];
  const isRoundOpen = firstApplication?.roundStatus === "OPEN";

  function handleExportApplicationsToExcel() {
    if (!applications || applications.length === 0) {
      toast.error("No applications to export.");
      return;
    }

    try {
      // Prepare applications data
      const applicationsData = applications.map((app, index) => ({
        "No.": index + 1,
        "Round": app.roundName || "-",
        "Status": app.status || "-",
        "Last Updated": app.updatedAt ? new Date(app.updatedAt).toLocaleString() : "-",
        "Submitted": app.submittedAt ? new Date(app.submittedAt).toLocaleString() : "-",
        "Housing Preference": app.preferredHousingBuildingName
          ? `${app.preferredHousingBuildingName} / Block ${app.preferredHousingBlockNumber || "-"} / Room ${app.preferredHousingRoomNumber || "-"}`
          : "General request",
      }));

      // Create workbook
      const ws = XLSX.utils.json_to_sheet(applicationsData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Applications");

      // Add summary sheet
      const summaryData = [
        ["My Housing Applications"],
        [],
        ["Application Summary"],
        ["Total Applications", applications.length],
        ["Generated At", new Date().toLocaleString()],
      ];

      const summarySh = XLSX.utils.aoa_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, summarySh, "Summary");

      // Download
      XLSX.writeFile(wb, `My-Applications-${new Date().toISOString().split("T")[0]}.xlsx`);
      toast.success("Applications exported to Excel successfully.");
    } catch (error) {
      toast.error("Failed to export applications to Excel.");
      console.error(error);
    }
  }

  function handlePrintApplications() {
    if (!applications || applications.length === 0) {
      toast.error("No applications to print.");
      return;
    }

    try {
      const data = applications.map((app) => ({
        "Round": app.roundName || "-",
        "Status": app.status || "-",
        "Last Updated": app.updatedAt ? new Date(app.updatedAt).toLocaleString() : "-",
        "Submitted": app.submittedAt ? new Date(app.submittedAt).toLocaleString() : "-",
        "Housing Preference": app.preferredHousingBuildingName
          ? `${app.preferredHousingBuildingName} / Block ${app.preferredHousingBlockNumber || "-"} / Room ${app.preferredHousingRoomNumber || "-"}`
          : "General request",
      }));

      printTableData(
        data,
        "My Housing Applications",
        {
          "Total Applications": applications.length.toString(),
          "Generated": new Date().toLocaleString(),
        }
      );
      toast.success("Printing applications...");
    } catch (error) {
      toast.error("Failed to print applications.");
    }
  }

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
      {/* Unified Header */}
      <div className="p-8 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
              <FileText className="w-8 h-8 text-[var(--color-primary)]" />
              My Applications
            </h2>
            <p className="mt-2 text-gray-600">
              Track your housing applications, review scores, and manage submissions
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="bg-gray-50 rounded-lg px-4 py-2 shadow-sm border border-gray-200">
              <p className="text-sm text-gray-500">Total Applications</p>
              <p className="text-2xl font-bold text-[var(--color-primary)]">{applications?.length || 0}</p>
            </div>
            {firstApplication && (
              <Button 
                onClick={() => window.location.href = '/dashboard/lecturer/application'}
                variant="outline"
                className="flex items-center gap-2"
                disabled={!isRoundOpen}
                title={!isRoundOpen ? "Application can only be edited when the round is open" : "Edit your application"}
              >
                <Edit className="w-4 h-4" />
                Edit
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Unified Content Area */}
      <div className="p-8">
        {/* Loading/Error/Empty States */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading your applications...</p>
          </div>
        ) : isError ? (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
            <p className="mt-4 text-red-700">
              {error instanceof ApiError && error.status === 401 
                ? "Please log in to view your applications." 
                : "Could not load applications. Please try again."
              }
            </p>
            {error instanceof ApiError && error.status === 401 && (
              <Button 
                className="mt-4" 
                onClick={() => window.location.href = '/auth/login'}
              >
                Go to Login
              </Button>
            )}
          </div>
        ) : !applications || applications.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-gray-400 mx-auto" />
            <p className="mt-4 text-gray-600">No applications yet.</p>
            <p className="text-sm text-gray-500 mt-2">Start by filling out a new housing application.</p>
          </div>
        ) : (
          /* Applications List - Full Frame */
          <div className="space-y-6">
          {applications.map((application) => (
            <div key={application.id} className="border-b border-gray-200 last:border-b-0">
              {/* Application Header - Integrated into main frame */}
              <div className="flex items-center justify-between py-4">
                <div className="flex items-center gap-4">
                  <div className="bg-[var(--color-primary)] text-white px-4 py-2 rounded-lg">
                    <h3 className="font-semibold">
                      {application.roundName || "Application Round"}
                    </h3>
                  </div>
                  <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(application.status)}`}>
                    {getStatusIcon(application.status)}
                    {application.status}
                  </div>
                </div>
              </div>

              {/* Application Content - Full width */}
              <div className="pb-6 space-y-4">
                {/* Date Information */}
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Last Updated</p>
                    <p className="text-sm text-gray-600">{formatDate(application.updatedAt)}</p>
                    {application.submittedAt && (
                      <p className="text-xs text-gray-500 mt-1">Submitted: {formatDate(application.submittedAt)}</p>
                    )}
                  </div>
                </div>

                {/* Action Button */}
                <div className="pt-4 border-t border-gray-100">
                  {application.status === "DRAFT" ? (
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      onClick={() => submitMutation.mutate(application.id)}
                      disabled={submitMutation.isPending && submitMutation.variables === application.id}
                    >
                      {submitMutation.isPending && submitMutation.variables === application.id ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Submit Application
                        </>
                      )}
                    </Button>
                  ) : (
                    <div className="bg-green-50 border border-green-200 rounded-lg px-4 py-3">
                      <div className="flex items-center gap-2 text-green-700">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-sm font-medium">Application Submitted</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Full Application Form Data */}
                <ApplicationDetails application={application} />
              </div>
            </div>
          ))}
          </div>
        )}
      </div>
    </div>
  );
}
