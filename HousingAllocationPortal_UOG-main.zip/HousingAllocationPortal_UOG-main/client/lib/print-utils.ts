/**
 * Print HTML content using browser's print dialog
 * @param content HTML string or element to print
 * @param title Optional title for the print document
 */
export function printContent(content: string | HTMLElement, title?: string) {
  try {
    const printWindow = window.open("", "", "width=800,height=600");
    if (!printWindow) {
      throw new Error("Print window could not be opened");
    }

    const htmlContent = typeof content === "string" ? content : content.innerHTML;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <title>${title || "Print Document"}</title>
          <style>
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
                'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
                sans-serif;
              padding: 20px;
              color: #333;
              background: #fff;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th {
              background-color: #f3f4f6;
              border: 1px solid #d1d5db;
              padding: 12px;
              text-align: left;
              font-weight: 600;
              font-size: 12px;
              text-transform: uppercase;
              letter-spacing: 0.05em;
            }
            td {
              border: 1px solid #d1d5db;
              padding: 10px 12px;
              font-size: 13px;
            }
            tr:nth-child(even) {
              background-color: #f9fafb;
            }
            h1, h2, h3 {
              margin-top: 20px;
              margin-bottom: 10px;
            }
            h1 {
              font-size: 24px;
              font-weight: 700;
            }
            h2 {
              font-size: 18px;
              font-weight: 600;
            }
            h3 {
              font-size: 14px;
              font-weight: 600;
            }
            .section {
              margin-bottom: 30px;
              page-break-inside: avoid;
            }
            .header-info {
              display: flex;
              justify-content: space-between;
              margin-bottom: 20px;
              padding-bottom: 10px;
              border-bottom: 2px solid #e5e7eb;
            }
            .header-info div {
              flex: 1;
            }
            .header-info .label {
              font-weight: 600;
              color: #666;
              font-size: 12px;
            }
            .header-info .value {
              font-weight: 500;
              font-size: 13px;
            }
            @media print {
              body {
                padding: 0;
              }
              table {
                font-size: 11px;
              }
              th {
                font-size: 10px;
              }
            }
          </style>
        </head>
        <body>
          ${htmlContent}
          <script>
            window.onload = function() {
              window.print();
              window.close();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  } catch (error) {
    console.error("Error printing content:", error);
    throw new Error("Failed to print content");
  }
}

/**
 * Generate printable HTML table from data
 * @param data Array of objects
 * @param title Optional table title
 * @param headers Optional custom headers
 */
export function generatePrintableTable(
  data: Record<string, any>[],
  title?: string,
  headers?: Record<string, string>
): string {
  if (!data || data.length === 0) {
    return "<p>No data to print</p>";
  }

  const tableHeaders = headers || data[0];
  const headerKeys = Object.keys(tableHeaders);

  let html = `
    <div class="section">
      ${title ? `<h2>${title}</h2>` : ""}
      <table>
        <thead>
          <tr>
            ${headerKeys.map((key) => `<th>${headers ? tableHeaders[key] : key}</th>`).join("")}
          </tr>
        </thead>
        <tbody>
          ${data
            .map(
              (row) =>
                `<tr>
                ${headerKeys.map((key) => `<td>${row[key] ?? "-"}</td>`).join("")}
              </tr>`
            )
            .join("")}
        </tbody>
      </table>
    </div>
  `;

  return html;
}

/**
 * Print table data using enhanced formatting
 * @param data Array of objects
 * @param title Title for the print document
 * @param metadata Optional metadata to display at top
 */
export function printTableData(
  data: Record<string, any>[],
  title: string,
  metadata?: Record<string, string>
) {
  try {
    const printWindow = window.open("", "", "width=900,height=700");
    if (!printWindow) {
      throw new Error("Print window could not be opened");
    }

    if (!data || data.length === 0) {
      printWindow.document.write("<p>No data to print</p>");
      printWindow.document.close();
      return;
    }

    const tableHeaders = data[0];
    const headerKeys = Object.keys(tableHeaders);

    let metadataHtml = "";
    if (metadata) {
      metadataHtml = `
        <div class="header-info">
          ${Object.entries(metadata)
            .map(
              ([key, value]) =>
                `<div>
              <div class="label">${key}</div>
              <div class="value">${value}</div>
            </div>`
            )
            .join("")}
        </div>
      `;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8">
          <title>${title}</title>
          <style>
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
                'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
                sans-serif;
              padding: 20px;
              color: #333;
              background: #fff;
            }
            h1 {
              font-size: 24px;
              font-weight: 700;
              margin-bottom: 10px;
              text-align: center;
              text-transform: uppercase;
            }
            .subtitle {
              text-align: center;
              font-size: 12px;
              color: #666;
              margin-bottom: 20px;
            }
            .header-info {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
              gap: 15px;
              margin-bottom: 20px;
              padding-bottom: 10px;
              border-bottom: 2px solid #e5e7eb;
            }
            .header-info .label {
              font-weight: 600;
              color: #666;
              font-size: 11px;
              text-transform: uppercase;
            }
            .header-info .value {
              font-weight: 500;
              font-size: 12px;
              word-break: break-word;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th {
              background-color: #f3f4f6;
              border: 1px solid #d1d5db;
              padding: 12px;
              text-align: left;
              font-weight: 600;
              font-size: 11px;
              text-transform: uppercase;
              letter-spacing: 0.05em;
            }
            td {
              border: 1px solid #d1d5db;
              padding: 10px 12px;
              font-size: 12px;
              word-wrap: break-word;
            }
            tr:nth-child(even) {
              background-color: #f9fafb;
            }
            .footer {
              margin-top: 30px;
              text-align: center;
              font-size: 10px;
              color: #999;
              border-top: 1px solid #e5e7eb;
              padding-top: 10px;
            }
            @media print {
              body {
                padding: 0;
              }
              table {
                font-size: 10px;
              }
              th {
                font-size: 9px;
              }
              td {
                padding: 8px;
              }
              .page-break {
                page-break-before: always;
              }
            }
          </style>
        </head>
        <body>
          <h1>${title}</h1>
          <div class="subtitle">Generated on ${new Date().toLocaleString()}</div>
          ${metadataHtml}
          <table>
            <thead>
              <tr>
                ${headerKeys.map((key) => `<th>${key}</th>`).join("")}
              </tr>
            </thead>
            <tbody>
              ${data
                .map(
                  (row) =>
                    `<tr>
                  ${headerKeys.map((key) => `<td>${row[key] ?? "-"}</td>`).join("")}
                </tr>`
                )
                .join("")}
            </tbody>
          </table>
          <div class="footer">
            Page 1 | Total Records: ${data.length}
          </div>
          <script>
            window.onload = function() {
              window.print();
              window.close();
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  } catch (error) {
    console.error("Error printing table data:", error);
    throw new Error("Failed to print table data");
  }
}
