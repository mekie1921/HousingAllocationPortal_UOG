export const API_BASE_URL = (() => {
  const envBaseUrl =
    process.env.NEXT_PUBLIC_API_BASE_URL ??
    (process.env.NEXT_PUBLIC_API_URL
      ? `${process.env.NEXT_PUBLIC_API_URL.replace(/\/$/, "")}/api`
      : undefined);

  if (typeof window === 'undefined') {
    return envBaseUrl ?? "http://localhost:4000/api";
  }

  if (!envBaseUrl) {
    return `${window.location.origin}/api`;
  }

  try {
    const envUrl = new URL(envBaseUrl);
    const isLocalHostEnv = envUrl.hostname === 'localhost' || envUrl.hostname === '127.0.0.1';
    const currentHost = window.location.hostname;

    if (isLocalHostEnv && currentHost !== 'localhost' && currentHost !== '127.0.0.1') {
      return `${window.location.protocol}//${currentHost}${envUrl.port ? `:${envUrl.port}` : ''}${envUrl.pathname}`;
    }
  } catch {
    // If URL parsing fails, fall back to env value.
  }

  return envBaseUrl;
})();

type ApiRequestOptions = {
  method?: "GET" | "POST" | "PATCH" | "DELETE";
  body?: unknown;
};

export class ApiError extends Error {
  readonly status: number;
  readonly code?: string;

  constructor(message: string, status: number, code?: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

export async function apiRequest<T>(
  path: string,
  options: ApiRequestOptions = {},
): Promise<T> {
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      method: options.method ?? "GET",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
    });

    const contentType = response.headers.get("content-type");
    const responseText = await response.text().catch(() => "");

    let payload: { message?: string; code?: string } | T | string | null = null;
    if (responseText) {
      try {
        payload = JSON.parse(responseText);
      } catch {
        payload = responseText;
      }
    }

    if (!response.ok) {
      const errorPayload =
        typeof payload === "object" && payload !== null && "message" in payload
          ? payload as { message?: string; code?: string }
          : null;
      const errorMessage =
        errorPayload?.message ??
        (typeof payload === "string" ? payload : response.statusText ?? "Request failed");

      // For login page, always throw the error so component can display it
      // For other pages, redirect on 401/403
      if ((response.status === 401 || response.status === 403) && typeof window !== 'undefined') {
        const currentPath = window.location.pathname;
        
        // If NOT on login page, redirect to login
        if (!currentPath.startsWith('/auth/login') && !currentPath.startsWith('/auth/verify')) {
          window.location.href = `/auth/login`;
          return (null as unknown) as T;
        }
      }

      throw new ApiError(errorMessage, response.status, errorPayload?.code);
    }

    return payload as T;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }

    // Handle network errors or server not running
    if (error instanceof TypeError && error.message.includes("fetch")) {
      throw new ApiError(
        "Network error",
        0,
        "NETWORK_ERROR"
      );
    }

    throw new ApiError(
      "Request failed",
      0,
      "UNKNOWN_ERROR"
    );
  }
}
