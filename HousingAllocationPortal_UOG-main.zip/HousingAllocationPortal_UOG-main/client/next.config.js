/** @type {import('next').NextConfig} */
const nextConfig = {
  turbopack: {
    root: __dirname,
  },
  outputFileTracingRoot: __dirname,
  allowedDevOrigins: ['10.139.27.195', 'http://10.139.27.195', 'http://localhost:3000'],
};

module.exports = nextConfig;
