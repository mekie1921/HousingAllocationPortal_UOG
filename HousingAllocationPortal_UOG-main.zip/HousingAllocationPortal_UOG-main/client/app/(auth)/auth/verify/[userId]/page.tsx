import React, { Suspense } from "react";
import { VerifyPanel } from "@/features/auth/components/verify-panel";

type VerifyPageProps = {
  params: Promise<{
    userId: string;
  }>;
};

export default async function VerifyPage({ params }: VerifyPageProps) {
  const { userId } = await params;

  return (
    <Suspense fallback={<div className="p-8 text-center">Loading verification...</div>}>
      <VerifyPanel userId={userId} />
    </Suspense>
  );
}
