import React, { Suspense } from "react";
import { LoginPanel } from "@/features/auth/components/login-panel";

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center">Loading login...</div>}>
      <LoginPanel />
    </Suspense>
  );
}
