import { BrandLockup } from "@/components/brand/brand-lockup";

export default function AuthLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div className="page-shell min-h-screen bg-[radial-gradient(circle_at_top,_rgba(59,130,246,0.18),_transparent_40%),radial-gradient(circle_at_bottom_right,_rgba(16,185,129,0.12),_transparent_30%)]">
      <main className="mx-auto flex min-h-screen w-full max-w-5xl flex-col items-center justify-center px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-4 w-full px-4 sm:px-0">
          <div className="mx-auto flex w-full max-w-3xl items-center justify-center rounded-[3rem] border border-white/15 bg-white/10 px-8 py-8 shadow-2xl shadow-slate-900/10 backdrop-blur-2xl">
            <BrandLockup
              href="/"
              stacked
              logoSize={96}
              className="justify-center"
              titleClassName="text-[var(--color-primary)] text-3xl sm:text-5xl font-black"
              subtitleClassName="text-[var(--foreground-secondary)] text-base sm:text-xl"
            />
          </div>
        </div>
        <div className="w-full px-4 sm:px-0">{children}</div>
        <footer className="mt-10 w-full text-center text-xs text-[var(--foreground-tertiary)]">
          © 2026 Gondar University - Empowering academic housing solutions.
        </footer>
      </main>
    </div>
  );
}
