"use client";

import { Database, LifeBuoy, Settings, ShieldCheck, UserPlus, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

import { DashboardOverview } from "@/components/dashboard/dashboard-overview";
import { DashboardGate } from "@/components/dashboard/dashboard-gate";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { getAdminUsersSummary, type AdminUsersSummary } from "@/lib/api/auth";

function renderRoleBreakdown(summary?: AdminUsersSummary) {
  if (!summary) {
    return "Loading role counts...";
  }

  return [
    `Active ${summary.activeUsers} · Inactive ${summary.inactiveUsers}`,
    `Admin ${summary.countsByRole.ADMIN.active}/${summary.countsByRole.ADMIN.inactive}`,
    `Lecturer ${summary.countsByRole.LECTURER.active}/${summary.countsByRole.LECTURER.inactive}`,
    `Officer ${summary.countsByRole.OFFICER.active}/${summary.countsByRole.OFFICER.inactive}`,
    `Committee ${summary.countsByRole.COMMITTEE.active}/${summary.countsByRole.COMMITTEE.inactive}`,
  ].join(" · ");
}

export default function AdminDashboardPage() {
  const summaryQuery = useQuery({
    queryKey: ["admin-users-summary"],
    queryFn: getAdminUsersSummary,
  });

  const summary = summaryQuery.data;

  return (
    <DashboardGate role="ADMIN">
      <DashboardShell
        title="Admin Dashboard"
        description="Complete control over system administration, security, monitoring, and user management."
        authStyleMainBackdrop
      >
        <DashboardOverview
          eyebrow="Administration Overview"
          intro="Track total users and active/inactive role counts in real time."
          metrics={[
            {
              label: "Users in System",
              value: summary ? String(summary.totalUsers) : "—",
              hint: "Total users across all roles. Updates when accounts are created or removed.",
            },
            {
              label: "Core Focus",
              value: "Security",
              hint: summary
                ? renderRoleBreakdown(summary)
                : "Loading active and inactive user counts by role...",
            },
            {
              label: "Access Areas",
              value: "5 Sections",
              hint: "Administration tasks are grouped into dedicated pages.",
            },
          ]}
          actions={[
            {
              title: "Create User",
              description: "Create lecturer, officer, committee, or admin accounts.",
              href: "/dashboard/admin/create-user",
              icon: UserPlus,
            },
            {
              title: "Manage Users",
              description: "Review and manage existing accounts and their roles.",
              href: "/dashboard/admin/manage-users",
              icon: Users,
            },
            {
              title: "Backups",
              description: "Create and manage system backups for recovery and auditing.",
              href: "/dashboard/admin/backup",
              icon: Database,
            },
            {
              title: "Settings",
              description: "Configure system-wide settings and account behavior.",
              href: "/dashboard/admin/settings",
              icon: Settings,
            },
            {
              title: "Support",
              description: "Open the support area when operational help is required.",
              href: "/dashboard/admin/support",
              icon: LifeBuoy,
            },
            {
              title: "Security Posture",
              description: "Use the dashboard sections to keep permissions and data handling aligned.",
              href: "/dashboard/admin",
              icon: ShieldCheck,
            },
          ]}
        />
      </DashboardShell>
    </DashboardGate>
  );
}
