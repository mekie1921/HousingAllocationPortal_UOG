﻿﻿"use client";



import Image from "next/image";

import Link from "next/link";

import { useState, useEffect, useRef } from "react";

import { Menu, X, KeyRound, Shield, Users, Sparkles, Mail, Phone, Award, Building2, Home, FileText, CheckCircle, ChevronDown, ArrowRight, MapPin, Zap, Heart, TrendingUp, MessageSquare, UserCheck, HelpCircle } from "lucide-react";



export default function HomePage() {

  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const [scrolled, setScrolled] = useState(false);

  const [currentSection, setCurrentSection] = useState('home');

  const [showDeveloperCredit, setShowDeveloperCredit] = useState(false);

  const [headerHeight, setHeaderHeight] = useState(72);

  const headerRef = useRef<HTMLDivElement>(null);

  // Calculate copyright year: increments in September
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth();
  const copyrightYear = currentMonth >= 8 ? currentYear + 1 : currentYear;



  useEffect(() => {

    const handleScroll = () => {

      setScrolled(window.scrollY > 50);

      // Update active section based on scroll position

      const sections = ['home', 'about', 'services', 'contact'];

      for (const section of sections) {

        const element = document.getElementById(section);

        if (element) {

          const rect = element.getBoundingClientRect();

          if (rect.top <= 100 && rect.bottom >= 100) {

            setCurrentSection(section);

            break;

          }

        }

      }

    };



    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);

  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
      document.body.style.position = 'fixed';
      document.body.style.width = '100%';
    } else {
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.width = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.width = '';
    };
  }, [isMenuOpen]);

  // Track header height for mobile menu positioning
  useEffect(() => {
    if (headerRef.current) {
      setHeaderHeight(headerRef.current.offsetHeight);
    }
  }, [scrolled]);



  return (

    <div className="min-h-screen bg-[var(--background-secondary)] text-[var(--foreground)] scroll-smooth">

      <header ref={headerRef} className="sticky top-0 z-[9999] border-b border-[var(--border)] bg-[var(--surface)]/95 backdrop-blur-lg shadow-lg transition-all duration-300">

        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">

          <Link href="#home" className="flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.18em] text-[var(--foreground)] group">

            <div className="relative h-12 w-16 overflow-hidden rounded-2xl transition-transform duration-300 group-hover:scale-110">

              <Image src="/ashuman.png" alt="University of Gondar logo" loading="eager" fill sizes="64px" className="object-contain" />

            </div>

            <div className="hidden sm:block">

              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[var(--color-blue)]">University of Gondar</p>

              <p className="text-base font-semibold">Housing Portal</p>

            </div>

          </Link>



          <nav className="hidden items-center gap-1 md:flex">

            <button

              onClick={() => document.getElementById('home')?.scrollIntoView({ behavior: 'smooth' })}

              className={`relative px-4 py-2 text-sm font-medium transition-all duration-300 after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-[var(--color-blue)] after:transition-all after:duration-300 ${currentSection === 'home' ? 'text-[var(--color-blue)] after:w-full' : 'hover:text-[var(--color-blue)] hover:after:w-full'}`}

            >

              <Home className="inline h-4 w-4 mr-1" />

              Home

            </button>

            <button

              onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}

              className={`relative px-4 py-2 text-sm font-medium transition-all duration-300 after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-[var(--color-blue)] after:transition-all after:duration-300 ${currentSection === 'about' ? 'text-[var(--color-blue)] after:w-full' : 'hover:text-[var(--color-blue)] hover:after:w-full'}`}

            >

              <Users className="inline h-4 w-4 mr-1" />

              About Us

            </button>

            <button

              onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}

              className={`relative px-4 py-2 text-sm font-medium transition-all duration-300 after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-[var(--color-blue)] after:transition-all after:duration-300 ${currentSection === 'services' ? 'text-[var(--color-blue)] after:w-full' : 'hover:text-[var(--color-blue)] hover:after:w-full'}`}

            >

              <Building2 className="inline h-4 w-4 mr-1" />

              Services

            </button>

            <button

              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}

              className={`relative px-4 py-2 text-sm font-medium transition-all duration-300 after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-[var(--color-blue)] after:transition-all after:duration-300 ${currentSection === 'contact' ? 'text-[var(--color-blue)] after:w-full' : 'hover:text-[var(--color-blue)] hover:after:w-full'}`}

            >

              <Mail className="inline h-4 w-4 mr-1" />

              Contact Us

            </button>

            <Link

              href="/auth/login"

              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-[rgba(var(--color-blue-rgb),0.25)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl hover:scale-105"

            >

              <KeyRound className="h-4 w-4" />

              Open Portal

              <ArrowRight className="h-4 w-4" />

            </Link>

          </nav>



          <button
            type="button"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="inline-flex h-16 w-16 items-center justify-center rounded-xl border-2 border-[var(--border)] bg-gradient-to-br from-[var(--surface)] to-[var(--background)] text-[var(--foreground)] shadow-md transition-all duration-300 hover:border-[var(--color-blue)] hover:text-[var(--color-blue)] hover:shadow-lg hover:-translate-y-0.5 md:hidden focus:outline-none focus:ring-4 focus:ring-[var(--color-blue)]/50 active:scale-95 cursor-pointer"
            aria-label="Toggle mobile menu"
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
            style={{ minHeight: '64px', minWidth: '64px' }}
          >
            {isMenuOpen ? <X className="h-8 w-8" /> : <Menu className="h-8 w-8" />}
          </button>

        </div>

      </header>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/80 z-[99999] md:hidden"
            onClick={() => setIsMenuOpen(false)}
            aria-hidden="true"
            style={{ backdropFilter: 'blur(8px)' }}
          />

          {/* Mobile Menu */}
          <div id="mobile-menu" className="fixed left-0 right-0 z-[100000] border-t border-[var(--border)] bg-gradient-to-br from-[var(--surface)] to-[var(--background)] px-4 py-6 shadow-2xl md:hidden animate-slide-in-down max-h-[calc(100vh-72px)] overflow-y-auto" role="navigation" aria-label="Mobile navigation" style={{ top: `${headerHeight}px` }}>
            <div className="space-y-2">

              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  setTimeout(() => document.getElementById('home')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
                }}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-4 text-base font-medium text-[var(--foreground)] text-left transition-all duration-300 hover:bg-gradient-to-r hover:from-[var(--color-blue)]/10 hover:to-[var(--color-green)]/10 hover:text-[var(--color-blue)] hover:shadow-sm hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[var(--color-blue)]/50 cursor-pointer"
                style={{ minHeight: '56px' }}
              >
                <Home className="h-6 w-6" />
                Home
              </button>

              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  setTimeout(() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
                }}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-4 text-base font-medium text-[var(--foreground)] text-left transition-all duration-300 hover:bg-gradient-to-r hover:from-[var(--color-blue)]/10 hover:to-[var(--color-green)]/10 hover:text-[var(--color-blue)] hover:shadow-sm hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[var(--color-blue)]/50 cursor-pointer"
                style={{ minHeight: '56px' }}
              >
                <Users className="h-6 w-6" />
                About Us
              </button>

              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  setTimeout(() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
                }}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-4 text-base font-medium text-[var(--foreground)] text-left transition-all duration-300 hover:bg-gradient-to-r hover:from-[var(--color-green)]/10 hover:to-[var(--color-yellow)]/10 hover:text-[var(--color-green)] hover:shadow-sm hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[var(--color-green)]/50 cursor-pointer"
                style={{ minHeight: '56px' }}
              >
                <Building2 className="h-6 w-6" />
                Services
              </button>

              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
                }}
                className="flex w-full items-center gap-3 rounded-xl px-4 py-4 text-base font-medium text-[var(--foreground)] text-left transition-all duration-300 hover:bg-gradient-to-r hover:from-[var(--color-blue)]/10 hover:to-[var(--color-green)]/10 hover:text-[var(--color-blue)] hover:shadow-sm hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[var(--color-blue)]/50 cursor-pointer"
                style={{ minHeight: '56px' }}
              >
                <Mail className="h-6 w-6" />
                Contact Us
              </button>



              <div className="pt-4 border-t border-[var(--border)]">

                <Link

                  href="/auth/login"

                  onClick={() => setIsMenuOpen(false)}

                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] px-4 py-4 text-base font-semibold text-white shadow-md transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-[var(--color-blue)]/50 touch-manipulation"

                  style={{ minHeight: '52px' }}

                >

                  <KeyRound className="h-5 w-5" />

                  Open Portal

                  <ArrowRight className="h-5 w-5" />

                </Link>

              </div>

            </div>

          </div>

        </>
      )}

      <main>

        <section id="home" className="relative overflow-hidden min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">

          {/* Background Image with Overlay */}

          <div className="absolute inset-0 z-0">

            <div
              className="absolute inset-0 bg-cover bg-center bg-no-repeat"
              style={{
                backgroundImage: 'url("/ashu.png")',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            />

            {/* Same gradient style as Office Hours section */}
            <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-blue)]/90 via-[var(--color-green)]/80 to-[var(--color-yellow)]/70" />

          </div>



          <div className="relative z-10 mx-auto max-w-7xl">

            <div className="mx-auto flex max-w-5xl flex-col items-center justify-center gap-12 text-center py-20">

              <div className="space-y-10 animate-fade-in">

                <div className="inline-flex items-center gap-3 rounded-full bg-white/25 px-6 py-3 text-sm font-semibold uppercase tracking-[0.2em] text-white shadow-xl border border-white/40">

                  <Sparkles className="h-5 w-5 text-yellow-300" />

                  <span>Secure Access Portal</span>

                  <Zap className="h-5 w-5 text-yellow-300" />

                </div>



                <div className="space-y-8">

                  <h1 className="font-black tracking-tight leading-tight" style={{ fontSize: 'clamp(3rem, 10vw, 8rem)' }}>

                    <span style={{ background: 'linear-gradient(90deg, #60a5fa, #34d399, #fbbf24, #f87171, #a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>University of Gondar</span>

                    <span className="block mt-10" style={{ background: 'linear-gradient(90deg, #fbbf24, #34d399, #60a5fa, #a78bfa, #f87171)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text', fontSize: 'clamp(2.5rem, 8vw, 6rem)' }}>
                      Housing Allocation Portal
                    </span>

                  </h1>

                  <p className="max-w-3xl mx-auto text-xl leading-relaxed text-white sm:text-2xl font-light">

                    Empowering academic excellence through modern, transparent, and efficient housing solutions for our distinguished staff and faculty members.

                  </p>

                </div>



                <div className="flex flex-col items-center justify-center gap-6 sm:flex-row sm:gap-8">

                  <a

                    href="#about"

                    className="group inline-flex items-center justify-center gap-3 rounded-full bg-white px-10 py-5 text-lg font-semibold text-[var(--color-blue)] shadow-2xl transition-all duration-300 hover:scale-105 hover:shadow-3xl hover:bg-yellow-50"

                  >

                    <span>Explore Portal</span>

                    <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />

                  </a>



                  <Link

                    href="/auth/login"

                    className="group inline-flex items-center justify-center gap-3 rounded-full border-2 border-white px-10 py-5 text-lg font-semibold text-white shadow-xl transition-all duration-300 hover:scale-105 hover:bg-white/15 hover:border-white"

                  >

                    <KeyRound className="h-5 w-5" />

                    <span>Access Portal</span>

                  </Link>

                </div>

              </div>

            </div>

          </div>



          {/* Scroll Indicator */}

          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">

            <a

              href="#about"

              className="flex flex-col items-center gap-2 text-white hover:text-white/80 transition-colors"

            >

              <span className="text-xs font-medium uppercase tracking-wider">Scroll Down</span>

              <ChevronDown className="h-6 w-6" />

            </a>

          </div>

        </section>



        <section id="about" className="relative overflow-hidden bg-gradient-to-b from-white to-[var(--background-secondary)] px-4 py-24 sm:px-6 lg:px-8">

          {/* Background Pattern */}

          <div

            className="absolute inset-0 z-0 opacity-30"

            style={{

              backgroundImage: `

                radial-gradient(circle at 25% 25%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),

                radial-gradient(circle at 75% 75%, rgba(16, 185, 129, 0.1) 0%, transparent 50%)

              `,

            }}

          />



          <div className="relative z-10 mx-auto max-w-7xl">

            <div className="text-center mb-16">

              <div className="inline-flex items-center gap-2 rounded-full bg-[var(--color-blue)]/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-[var(--color-blue)] mb-6">

                <Heart className="h-4 w-4" />

                About the Portal

              </div>

              <h2 className="text-4xl font-bold text-[var(--foreground)] sm:text-5xl lg:text-6xl mb-6">

                Transforming Housing Management

                <span className="block bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] bg-clip-text text-transparent">

                  For Academic Excellence

                </span>

              </h2>

              <p className="mx-auto max-w-3xl text-lg leading-8 text-[var(--foreground-secondary)] sm:text-xl">

                Our comprehensive housing portal is designed to streamline the allocation process, ensuring fair and transparent distribution of housing units to University of Gondar staff members.

              </p>

            </div>



            {/* Feature Cards with Images */}

            <div className="grid gap-8 lg:grid-cols-3 mb-20">

              <div className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">

                <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-blue)]/5 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative h-48 overflow-hidden">

                  <div

                    className="h-full w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-110"

                    style={{

                      backgroundImage: 'url("/Screenshot%202026-05-25%20184245.png")',

                    }}

                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] to-transparent" />

                </div>

                <div className="relative p-8">

                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--color-blue)] text-white shadow-lg shadow-[rgba(var(--color-blue-rgb),0.3)] mb-6">

                    <Award className="h-7 w-7" />

                  </div>

                  <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">User-Friendly Interface</h3>

                  <p className="text-[var(--foreground-secondary)] leading-relaxed">

                    Intuitive design crafted for users of all technical backgrounds. Navigate seamlessly through applications, allocations, and support services.

                  </p>

                </div>

              </div>



              <div className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">

                <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-green)]/5 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative h-48 overflow-hidden">

                  <div

                    className="h-full w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-110"

                    style={{

                      backgroundImage: 'url("/Screenshot%202026-05-25%20183248.png")',

                    }}

                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] to-transparent" />

                </div>

                <div className="relative p-8">

                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--color-green)] text-white shadow-lg shadow-[rgba(var(--color-green-rgb),0.3)] mb-6">

                    <Users className="h-7 w-7" />

                  </div>

                  <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">Fair Allocation System</h3>

                  <p className="text-[var(--foreground-secondary)] leading-relaxed">

                    Transparent scoring system ensuring equitable housing distribution based on clear criteria and professional guidelines.

                  </p>

                </div>

              </div>



              <div className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">

                <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-yellow)]/5 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative h-48 overflow-hidden">

                  <div

                    className="h-full w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-110"

                    style={{

                      backgroundImage: 'url("/Screenshot%202026-05-25%20183712.png")',

                    }}

                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] to-transparent" />

                </div>

                <div className="relative p-8">

                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--color-yellow)] text-white shadow-lg shadow-[rgba(var(--color-yellow-rgb),0.3)] mb-6">

                    <Shield className="h-7 w-7" />

                  </div>

                  <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">Secure & Reliable</h3>

                  <p className="text-[var(--foreground-secondary)] leading-relaxed">

                    Enterprise-grade security with encrypted data storage, verified authentication, and reliable 24/7 system availability.

                  </p>

                </div>

              </div>

            </div>



            {/* Mission and Vision Section */}

            <div id="about-mission" className="grid gap-12 lg:grid-cols-2 items-center">

              <div className="space-y-8">

                <div>

                  <div className="flex items-center gap-3 mb-4">

                    <Heart className="h-6 w-6 text-[var(--color-blue)]" />

                    <h3 className="text-2xl font-bold text-[var(--foreground)]">Our Mission</h3>

                  </div>

                  <p className="text-lg leading-relaxed text-[var(--foreground-secondary)]">

                    To provide University of Gondar staff with a modern, efficient, and transparent housing allocation system that promotes fairness, accessibility, and academic excellence.

                  </p>

                </div>

                <div>

                  <div className="flex items-center gap-3 mb-4">

                    <TrendingUp className="h-6 w-6 text-[var(--color-green)]" />

                    <h3 className="text-2xl font-bold text-[var(--foreground)]">Our Vision</h3>

                  </div>

                  <p className="text-lg leading-relaxed text-[var(--foreground-secondary)]">

                    To become the leading model for institutional housing management in Ethiopia, setting standards for innovation, transparency, and user satisfaction.

                  </p>

                </div>

                <div className="flex flex-wrap gap-4">

                  <div className="flex items-center gap-2 rounded-full bg-[var(--color-blue)]/10 px-4 py-2 text-sm font-medium text-[var(--color-blue)]">

                    <CheckCircle className="h-4 w-4" />

                    Transparent Process

                  </div>

                  <div className="flex items-center gap-2 rounded-full bg-[var(--color-green)]/10 px-4 py-2 text-sm font-medium text-[var(--color-green)]">

                    <CheckCircle className="h-4 w-4" />

                    Fair Distribution

                  </div>

                  <div className="flex items-center gap-2 rounded-full bg-[var(--color-yellow)]/10 px-4 py-2 text-sm font-medium text-[var(--color-yellow)]">

                    <CheckCircle className="h-4 w-4" />

                    Modern Technology

                  </div>

                </div>

              </div>

              <div className="relative">

                <div

                  className="relative h-96 rounded-3xl overflow-hidden shadow-2xl"

                  style={{

                    backgroundImage: 'url("/image.png")',

                    backgroundSize: 'cover',

                    backgroundPosition: 'center',

                  }}

                >

                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-blue)]/50 to-transparent" />

                  <div className="absolute bottom-0 left-0 right-0 p-8">

                    <div className="text-white">

                      <div className="text-sm font-semibold uppercase tracking-wider mb-2">University of Gondar</div>

                      <div className="text-3xl font-bold mb-2">Excellence in Education</div>

                      <div className="text-white">Since 1954</div>

                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </section>



        <section id="services" className="relative overflow-hidden bg-gradient-to-b from-[var(--background-secondary)] to-white px-4 py-24 sm:px-6 lg:px-8">

          {/* Background Pattern */}

          <div

            className="absolute inset-0 z-0 opacity-20"

            style={{

              backgroundImage: `

                radial-gradient(circle at 50% 0%, rgba(16, 185, 129, 0.15) 0%, transparent 50%),

                radial-gradient(circle at 0% 100%, rgba(59, 130, 246, 0.15) 0%, transparent 50%),

                radial-gradient(circle at 100% 100%, rgba(245, 158, 11, 0.15) 0%, transparent 50%)

              `,

            }}

          />



          <div className="relative z-10 mx-auto max-w-7xl">

            <div className="text-center mb-16">

              <div className="inline-flex items-center gap-2 rounded-full bg-[var(--color-green)]/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-[var(--color-green)] mb-6">

                <Building2 className="h-4 w-4" />

                Core Services

              </div>

              <h2 className="text-4xl font-bold text-[var(--foreground)] sm:text-5xl lg:text-6xl mb-6">

                Comprehensive Housing Solutions

                <span className="block bg-gradient-to-r from-[var(--color-green)] via-[var(--color-yellow)] to-[var(--color-blue)] bg-clip-text text-transparent">

                  For Every Need

                </span>

              </h2>

              <p className="mx-auto max-w-3xl text-lg leading-8 text-[var(--foreground-secondary)] sm:text-xl">

                Our portal offers a complete suite of services designed to streamline housing management, from application to allocation and ongoing support.

              </p>

            </div>



            {/* Service Cards with Images */}

            <div id="services-application" className="grid gap-8 lg:grid-cols-2 mb-12">

              <div className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">

                <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-blue)]/5 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative h-56 overflow-hidden">

                  <div

                    className="h-full w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-110"

                    style={{

                      backgroundImage: 'url("https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80")',

                    }}

                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] to-transparent" />

                </div>

                <div className="relative p-8">

                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--color-blue)] text-white shadow-lg shadow-[rgba(var(--color-blue-rgb),0.3)] mb-6">

                    <FileText className="h-7 w-7" />

                  </div>

                  <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">Housing Application</h3>

                  <p className="text-[var(--foreground-secondary)] leading-relaxed mb-4">

                    Streamlined online application process with document upload, real-time status tracking, and automated eligibility verification.

                  </p>

                  <ul className="space-y-2">



                    <li className="flex items-center gap-2 text-sm text-[var(--foreground-secondary)]">

                      <CheckCircle className="h-4 w-4 text-[var(--color-green)]" />

                      Real-time application tracking

                    </li>

                    <li className="flex items-center gap-2 text-sm text-[var(--foreground-secondary)]">

                      <CheckCircle className="h-4 w-4 text-[var(--color-green)]" />

                      Automated eligibility checks

                    </li>

                  </ul>

                </div>

              </div>



              <div id="services-allocation" className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] shadow-xl transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl">

                <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-green)]/5 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

                <div className="relative h-56 overflow-hidden">

                  <div

                    className="h-full w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-110"

                    style={{

                      backgroundImage: 'url("/Screenshot%202026-05-25%20184116.png")',

                    }}

                  />

                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] to-transparent" />

                </div>

                <div className="relative p-8">

                  <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--color-green)] text-white shadow-lg shadow-[rgba(var(--color-green-rgb),0.3)] mb-6">

                    <Building2 className="h-7 w-7" />

                  </div>

                  <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">Allocation System</h3>

                  <p className="text-[var(--foreground-secondary)] leading-relaxed mb-4">

                    Transparent scoring-based allocation system with clear criteria, fair distribution algorithms, and comprehensive reporting.

                  </p>

                  <ul className="space-y-2">

                    <li className="flex items-center gap-2 text-sm text-[var(--foreground-secondary)]">

                      <CheckCircle className="h-4 w-4 text-[var(--color-green)]" />

                      Transparent scoring criteria

                    </li>

                    <li className="flex items-center gap-2 text-sm text-[var(--foreground-secondary)]">

                      <CheckCircle className="h-4 w-4 text-[var(--color-green)]" />

                      Fair distribution algorithms

                    </li>

                    <li className="flex items-center gap-2 text-sm text-[var(--foreground-secondary)]">

                      <CheckCircle className="h-4 w-4 text-[var(--color-green)]" />

                      Comprehensive allocation reports

                    </li>

                  </ul>

                </div>

              </div>

            </div>



            {/* Additional Services Grid */}

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">

              <div id="services-support" className="group rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-[var(--color-blue)]/30">

                <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--color-blue)] text-white shadow-md mb-4">

                  <HelpCircle className="h-6 w-6" />

                </div>

                <h3 className="text-lg font-bold text-[var(--foreground)] mb-2">Support Services</h3>

                <p className="text-sm text-[var(--foreground-secondary)]">24/7 dedicated support team for all housing-related inquiries and assistance.</p>

              </div>



              <div className="group rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-[var(--color-green)]/30">

                <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--color-green)] text-white shadow-md mb-4">

                  <Shield className="h-6 w-6" />

                </div>

                <h3 className="text-lg font-bold text-[var(--foreground)] mb-2">Verified Onboarding</h3>

                <p className="text-sm text-[var(--foreground-secondary)]">Secure email verification and OTP authentication for all new users.</p>

              </div>



              <div className="group rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-[var(--color-yellow)]/30">

                <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--color-yellow)] text-white shadow-md mb-4">

                  <UserCheck className="h-6 w-6" />

                </div>

                <h3 className="text-lg font-bold text-[var(--foreground)] mb-2">Role-Based Access</h3>

                <p className="text-sm text-[var(--foreground-secondary)]">Customized dashboards for lecturers, officers, committee members, and administrators.</p>

              </div>



              <div id="services-complaints" className="group rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:border-[var(--color-red)]/30">

                <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--color-red)] text-white shadow-md mb-4">

                  <MessageSquare className="h-6 w-6" />

                </div>

                <h3 className="text-lg font-bold text-[var(--foreground)] mb-2">Complaint Resolution</h3>

                <p className="text-sm text-[var(--foreground-secondary)]">Structured complaint submission and tracking system with timely resolution.</p>

              </div>

            </div>



            {/* Process Timeline */}

            <div className="mt-20">

              <div className="text-center mb-12">

                <h3 className="text-3xl font-bold text-[var(--foreground)] mb-4">How It Works</h3>

                <p className="text-[var(--foreground-secondary)]">Simple 4-step process to secure your housing</p>

              </div>



              <div className="grid gap-8 md:grid-cols-4">

                <div className="relative text-center">

                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[var(--color-blue)] to-[var(--color-blue)]/80 text-white text-2xl font-bold shadow-lg mb-4">

                    1

                  </div>

                  <h4 className="text-lg font-bold text-[var(--foreground)] mb-2">Register</h4>

                  <p className="text-sm text-[var(--foreground-secondary)]">Create your account with email verification</p>

                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-[var(--color-blue)] to-[var(--color-green)] -translate-x-1/2" />

                </div>



                <div className="relative text-center">

                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[var(--color-green)] to-[var(--color-green)]/80 text-white text-2xl font-bold shadow-lg mb-4">

                    2

                  </div>

                  <h4 className="text-lg font-bold text-[var(--foreground)] mb-2">Apply</h4>

                  <p className="text-sm text-[var(--foreground-secondary)]">Submit housing application with documents</p>

                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-[var(--color-green)] to-[var(--color-yellow)] -translate-x-1/2" />

                </div>



                <div className="relative text-center">

                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[var(--color-yellow)] to-[var(--color-yellow)]/80 text-white text-2xl font-bold shadow-lg mb-4">

                    3

                  </div>

                  <h4 className="text-lg font-bold text-[var(--foreground)] mb-2">Evaluation</h4>

                  <p className="text-sm text-[var(--foreground-secondary)]">Transparent scoring and allocation process</p>

                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-[var(--color-yellow)] to-[var(--color-blue)] -translate-x-1/2" />

                </div>



                <div className="text-center">

                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[var(--color-blue)] to-[var(--color-blue)]/80 text-white text-2xl font-bold shadow-lg mb-4">

                    4

                  </div>

                  <h4 className="text-lg font-bold text-[var(--foreground)] mb-2">Allocation</h4>

                  <p className="text-sm text-[var(--foreground-secondary)]">Receive housing assignment and move in</p>

                </div>

              </div>

            </div>

          </div>

        </section>



        <section id="contact" className="relative overflow-hidden bg-gradient-to-b from-white to-[var(--background-secondary)] px-4 py-24 sm:px-6 lg:px-8">

          {/* Background Pattern */}

          <div

            className="absolute inset-0 z-0 opacity-20"

            style={{

              backgroundImage: `

                radial-gradient(circle at 75% 25%, rgba(59, 130, 246, 0.15) 0%, transparent 50%),

                radial-gradient(circle at 25% 75%, rgba(16, 185, 129, 0.15) 0%, transparent 50%)

              `,

            }}

          />



          <div className="relative z-10 mx-auto max-w-7xl">

            <div className="text-center mb-16">

              <div className="inline-flex items-center gap-2 rounded-full bg-[var(--color-blue)]/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-[var(--color-blue)] mb-6">

                <Mail className="h-4 w-4" />

                Contact Us

              </div>

              <h2 className="text-4xl font-bold text-[var(--foreground)] sm:text-5xl lg:text-6xl mb-6">

                Get In Touch

                <span className="block bg-gradient-to-r from-[var(--color-blue)] via-[var(--color-green)] to-[var(--color-yellow)] bg-clip-text text-transparent">

                  We&apos;re Here To Help

                </span>

              </h2>

              <p className="mx-auto max-w-3xl text-lg leading-8 text-[var(--foreground-secondary)] sm:text-xl">

                Have questions about the housing portal? Our dedicated support team is available 24/7 to assist you with any inquiries.

              </p>

            </div>



            <div className="grid gap-12 lg:grid-cols-2">

              {/* Contact Information */}

              <div className="space-y-8">

                <div className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-8 shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:border-[var(--color-blue)]/30">

                  <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-blue)]/5 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                  <div className="relative">

                    <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--color-blue)] text-white shadow-lg shadow-[rgba(var(--color-blue-rgb),0.3)] mb-6">

                      <Mail className="h-8 w-8" />

                    </div>

                    <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">Email Support</h3>

                    <p className="text-[var(--foreground-secondary)] leading-relaxed mb-4">

                      Send us an email for general inquiries, technical support, or housing-related questions.

                    </p>

                    <a
                      href="mailto:ashenafi.hab1@uog.edu.et"
                      className="inline-flex items-center gap-2 text-[var(--color-blue)] font-semibold hover:text-[var(--color-blue)]/80 transition-colors"
                    >
                      ashenafi.hab1@uog.edu.et

                      <ArrowRight className="h-4 w-4" />

                    </a>

                  </div>

                </div>



                <div className="group relative overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-8 shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:border-[var(--color-yellow)]/30">

                  <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-yellow)]/5 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                  <div className="relative">

                    <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--color-yellow)] text-white shadow-lg shadow-[rgba(var(--color-yellow-rgb),0.3)] mb-6">

                      <MapPin className="h-8 w-8" />

                    </div>

                    <h3 className="text-2xl font-bold text-[var(--foreground)] mb-3">Office Location</h3>

                    <p className="text-[var(--foreground-secondary)] leading-relaxed mb-4">

                      Visit our housing office on campus for in-person assistance and document submission.

                    </p>

                    <div className="space-y-3">
                      <p className="text-[var(--foreground)] font-semibold">
                        <a
                          href="https://uog.edu.et"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-[var(--color-blue)] hover:text-[var(--color-blue)]/80 transition-colors"
                        >
                          UOG
                          <ArrowRight className="h-4 w-4" />
                        </a>
                      </p>
                      <div className="space-y-2 text-sm">
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">University:</span> <a href="https://uog.edu.et" target="_blank" rel="noopener noreferrer" className="text-[var(--color-blue)] hover:text-[var(--color-blue)]/80 transition-colors">University of Gondar</a></p>
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">Main Email:</span> <a href="mailto:info@uog.edu.et" className="text-[var(--color-blue)] hover:text-[var(--color-blue)]/80 transition-colors">info@uog.edu.et</a></p>
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">Registrar Email:</span> <a href="mailto:registrar@uog.edu.et" className="text-[var(--color-blue)] hover:text-[var(--color-blue)]/80 transition-colors">registrar@uog.edu.et</a></p>
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">Main Phone:</span> +251 58 114 1232</p>
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">Additional Phone:</span> +251 58 114 1234</p>
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">P.O.Box:</span> 196</p>
                        <p className="text-[var(--foreground-secondary)]"><span className="font-semibold text-[var(--foreground)]">Location:</span> Gondar, Amhara, Ethiopia</p>
                      </div>
                    </div>

                  </div>

                </div>

              </div>



              {/* Contact Form / Image */}

              <div className="relative">

                <div

                  className="relative h-full min-h-[500px] rounded-3xl overflow-hidden shadow-2xl"

                  style={{

                    backgroundImage: 'url("https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80")',

                    backgroundSize: 'cover',

                    backgroundPosition: 'center',

                  }}

                >

                  <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-blue)]/90 via-[var(--color-green)]/80 to-[var(--color-yellow)]/70" />

                  <div className="relative h-full flex flex-col justify-center p-8 sm:p-12">

                    <div className="text-white space-y-6">

                      <div>

                        <h3 className="text-3xl font-bold mb-4">Office Hours</h3>

                        <div className="space-y-3">

                          <div className="flex items-center justify-between border-b border-white/20 pb-2">

                            <span className="text-white">Monday - Friday</span>

                            <span className="font-semibold">8:00 AM - 5:00 PM</span>

                          </div>

                          <div className="flex items-center justify-between border-b border-white/20 pb-2">

                            <span className="text-white">Saturday</span>

                            <span className="font-semibold">9:00 AM - 1:00 PM</span>

                          </div>

                          <div className="flex items-center justify-between">

                            <span className="text-white">Sunday</span>

                            <span className="font-semibold">Closed</span>

                          </div>

                        </div>

                      </div>



                      <div className="pt-6 border-t border-white/20">

                        <h4 className="text-xl font-bold mb-4">Emergency Contact</h4>

                        <p className="text-white leading-relaxed mb-4">

                          For urgent housing matters outside office hours, please use our emergency contact line.

                        </p>

                        <a

                          href="https://uog.edu.et"

                          className="inline-flex items-center gap-2 bg-white/30 px-6 py-3 rounded-full font-semibold hover:bg-white/40 transition-colors"

                        >

                          <Phone className="h-5 w-5" />

                          Emergency Line

                        </a>

                      </div>

                    </div>

                  </div>

                </div>

              </div>

            </div>




          </div>

        </section>

      </main>



      <footer className="border-t border-[var(--border)] bg-[var(--surface)] px-4 py-10 text-[var(--foreground-secondary)] sm:px-6 lg:px-8 relative">

        <div className="mx-auto flex max-w-7xl flex-col items-center gap-6 text-center sm:flex-row sm:items-center sm:justify-center">

          <div>

            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-[var(--color-blue)]">University of Gondar</p>

            <p className="mt-3 max-w-xl text-sm leading-6 text-[var(--foreground-tertiary)]">

              © {copyrightYear} Gondar University - Empowering academic housing solutions.

            </p>

          </div>



        </div>

        {/* Animated Developer Circle */}
        <div className="fixed bottom-4 left-4 z-50">
          <button
            onClick={() => setShowDeveloperCredit(!showDeveloperCredit)}
            className="relative w-12 h-12 rounded-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"

          >
            <span className="absolute inset-0 flex items-center justify-center text-white font-bold text-xs">
              Dev
            </span>
          </button>
          {showDeveloperCredit && (
            <div className="absolute bottom-14 left-0 bg-[var(--surface)] border border-[var(--border)] rounded-lg p-3 shadow-xl whitespace-nowrap animate-fade-in">
              <p className="text-xs font-semibold text-[var(--foreground)]">
                Developed by Ashenafi habte & project members of UOG cs student
              </p>
            </div>
          )}
        </div>

      </footer>

    </div>

  );

}