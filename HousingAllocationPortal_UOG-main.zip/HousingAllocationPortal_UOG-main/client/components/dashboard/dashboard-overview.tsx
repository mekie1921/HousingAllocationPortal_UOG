"use client";

import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import { ArrowRight } from "lucide-react";

type OverviewMetric = {
  label: string;
  value: string;
  hint: string;
};

type OverviewAction = {
  title: string;
  description: string;
  href: string;
  icon: LucideIcon;
};

type DashboardOverviewProps = {
  eyebrow: string;
  intro: string;
  metrics: OverviewMetric[];
  actions: OverviewAction[];
};

export function DashboardOverview({
  eyebrow,
  intro,
  metrics,
  actions,
}: DashboardOverviewProps) {
  return (
    <div className="space-y-8 text-slate-900">
      <section className="rounded-[28px] border border-slate-200/70 bg-white/95 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)]">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-500">{eyebrow}</p>
        <p className="mt-4 max-w-3xl text-base leading-7 text-slate-900">{intro}</p>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {metrics.map((metric) => (
            <div
              key={metric.label}
              className="rounded-2xl border border-slate-200/70 bg-slate-50 p-5 shadow-sm"
            >
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
                {metric.label}
              </p>
              <p className="mt-3 text-3xl font-bold text-slate-950">{metric.value}</p>
              <p className="mt-2 text-sm text-slate-600">{metric.hint}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {actions.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="group rounded-[26px] border border-slate-200/70 bg-white p-6 text-slate-950 shadow-[0_16px_50px_rgba(15,23,42,0.08)] transition-all duration-300 hover:-translate-y-1 hover:border-slate-300 hover:bg-slate-50"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-900">
              <action.icon className="h-6 w-6" />
            </div>
            <h3 className="mt-5 text-xl font-semibold text-slate-950">{action.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-600">{action.description}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
