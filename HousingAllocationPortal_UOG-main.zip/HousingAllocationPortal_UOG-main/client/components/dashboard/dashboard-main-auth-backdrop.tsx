/**
 * Full-viewport backdrop matching the landing page hero section:
 * house image + the same blue→green→yellow gradient overlay.
 * Used by all four dashboard pages (admin, officer, committee, lecturer).
 */
export function DashboardMainAuthBackdrop() {
  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden"
      aria-hidden
    >
      {/* House background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url("/ashu.png")' }}
      />

      {/* Same gradient overlay as the landing page hero */}
      <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-blue)]/90 via-[var(--color-green)]/80 to-[var(--color-yellow)]/70" />
    </div>
  );
}
