ALTER TABLE "users" ADD COLUMN "department" varchar(255);
