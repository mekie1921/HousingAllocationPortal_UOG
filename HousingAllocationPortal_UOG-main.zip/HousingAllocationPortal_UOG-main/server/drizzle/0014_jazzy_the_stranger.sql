DROP INDEX "allocation_results_round_application_unique";--> statement-breakpoint
DROP INDEX "allocation_results_round_housing_unit_unique";--> statement-breakpoint
CREATE UNIQUE INDEX "allocation_results_round_application_unique" ON "allocation_results" USING btree ("round_id","application_id","status");--> statement-breakpoint
CREATE UNIQUE INDEX "allocation_results_round_housing_unit_unique" ON "allocation_results" USING btree ("round_id","housing_unit_id","status");