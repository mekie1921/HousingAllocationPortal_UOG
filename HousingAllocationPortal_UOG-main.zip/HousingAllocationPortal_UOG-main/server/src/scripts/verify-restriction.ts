import 'dotenv/config';
import { and, eq, inArray } from 'drizzle-orm';

import { db, pool } from '../lib/db/index.js';
import { users } from '../lib/db/schema/auth.js';
import { applications, applicationRounds } from '../lib/db/schema/application.js';
import { listCommitteeApplications, getCommitteeApplicationDetails } from '../services/committee.service.js';

async function main(): Promise<void> {
  console.log('--------------------------------------------------');
  console.log('🚀 STARTING COMMITTEE RESTRICTION TESTING');
  console.log('--------------------------------------------------');

  // 1. Get or Create an Admin user to associate with the round creation
  let adminUser = await db.query.users.findFirst({
    where: eq(users.role, 'ADMIN'),
  });

  if (!adminUser) {
    console.log('Creating temp admin user for testing...');
    const [newAdmin] = await db
      .insert(users)
      .values({
        name: 'Test Admin',
        email: 'testadmin@uog.edu.et',
        role: 'ADMIN',
        isVerified: true,
      })
      .returning();
    adminUser = newAdmin;
  }

  // 2. Create a Test Application Round
  console.log('Creating test application round...');
  const [testRound] = await db
    .insert(applicationRounds)
    .values({
      name: 'Test Round - Committee Restriction Test',
      description: 'Testing department bounds',
      status: 'OPEN',
      startsAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // started yesterday
      endsAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7), // ends next week
      createdByUserId: adminUser.id,
    })
    .returning();

  // 3. Create Test Committee Reviewers
  console.log('Creating test committee reviewers...');
  const [informaticsReviewer] = await db
    .insert(users)
    .values({
      name: 'Informatics Reviewer',
      email: 'informatics_rev@uog.edu.et',
      role: 'COMMITTEE',
      department: 'College of Informatics',
      isVerified: true,
    })
    .returning();

  const [medicineReviewer] = await db
    .insert(users)
    .values({
      name: 'Medicine Reviewer',
      email: 'medicine_rev@uog.edu.et',
      role: 'COMMITTEE',
      department: 'College of Medicine and Health Sciences',
      isVerified: true,
    })
    .returning();

  // 4. Create Test Lecturers
  console.log('Creating test lecturers...');
  const [informaticsLecturer] = await db
    .insert(users)
    .values({
      name: 'Informatics Lecturer',
      email: 'informatics_lec@uog.edu.et',
      role: 'LECTURER',
      department: 'College of Informatics',
      isVerified: true,
    })
    .returning();

  const [medicineLecturer] = await db
    .insert(users)
    .values({
      name: 'Medicine Lecturer',
      email: 'medicine_lec@uog.edu.et',
      role: 'LECTURER',
      department: 'College of Medicine and Health Sciences',
      isVerified: true,
    })
    .returning();

  // 5. Create Test Applications
  console.log('Creating test applications...');
  const [informaticsApplication] = await db
    .insert(applications)
    .values({
      userId: informaticsLecturer.id,
      roundId: testRound.id,
      status: 'SUBMITTED',
      submittedAt: new Date(),
    })
    .returning();

  const [medicineApplication] = await db
    .insert(applications)
    .values({
      userId: medicineLecturer.id,
      roundId: testRound.id,
      status: 'SUBMITTED',
      submittedAt: new Date(),
    })
    .returning();

  console.log('\n--- Running Test Assertions ---');

  // ASSERTION 1: Informatics Reviewer lists applications
  // Should ONLY see the Informatics application, NOT the Medicine one.
  const infoAppsList = await listCommitteeApplications(informaticsReviewer.id, {
    roundId: testRound.id,
  });

  const hasInformaticsAppInInfoList = infoAppsList.some(app => app.id === informaticsApplication.id);
  const hasMedicineAppInInfoList = infoAppsList.some(app => app.id === medicineApplication.id);

  console.log(`Assertion 1 (List Informatics Apps):`);
  console.log(`  - Informatics app found: ${hasInformaticsAppInInfoList ? '✅ YES' : '❌ NO'}`);
  console.log(`  - Medicine app filtered out: ${!hasMedicineAppInInfoList ? '✅ YES' : '❌ NO'}`);
  
  if (!hasInformaticsAppInInfoList || hasMedicineAppInInfoList) {
    throw new Error('Assertion 1 failed: Informatics reviewer got access to unauthorized applications!');
  }

  // ASSERTION 2: Medicine Reviewer lists applications
  // Should ONLY see the Medicine application, NOT the Informatics one.
  const medAppsList = await listCommitteeApplications(medicineReviewer.id, {
    roundId: testRound.id,
  });

  const hasInformaticsAppInMedList = medAppsList.some(app => app.id === informaticsApplication.id);
  const hasMedicineAppInMedList = medAppsList.some(app => app.id === medicineApplication.id);

  console.log(`Assertion 2 (List Medicine Apps):`);
  console.log(`  - Medicine app found: ${hasMedicineAppInMedList ? '✅ YES' : '❌ NO'}`);
  console.log(`  - Informatics app filtered out: ${!hasInformaticsAppInMedList ? '✅ YES' : '❌ NO'}`);

  if (!hasMedicineAppInMedList || hasInformaticsAppInMedList) {
    throw new Error('Assertion 2 failed: Medicine reviewer got access to unauthorized applications!');
  }

  // ASSERTION 3: Informatics Reviewer tries to access details of Medicine application (Direct Access Bypass test)
  // Should throw APPLICATION_NOT_FOUND or AppError.
  console.log(`Assertion 3 (Direct Access Bypass Verification):`);
  let directAccessBypassed = false;
  try {
    await getCommitteeApplicationDetails(informaticsReviewer.id, medicineApplication.id);
    directAccessBypassed = true; // if this succeeds, bypass occurred
  } catch (error: any) {
    console.log(`  - Successfully blocked Informatics reviewer from fetching Medicine app details!`);
    console.log(`    Caught Expected Error: ${error.message} (${error.errorCode})`);
  }

  if (directAccessBypassed) {
    throw new Error('Assertion 3 failed: Informatics reviewer successfully bypassed details endpoint to view Medicine application!');
  }

  // ASSERTION 4: Informatics Reviewer fetches details of Informatics application
  // Should succeed.
  console.log(`Assertion 4 (Authorized Detail Access):`);
  try {
    const details = await getCommitteeApplicationDetails(informaticsReviewer.id, informaticsApplication.id);
    console.log(`  - Successfully retrieved details for own department application! (Lecturer: ${details.lecturerName})`);
  } catch (error: any) {
    throw new Error(`Assertion 4 failed: Authorized access was blocked with error: ${error.message}`);
  }

  console.log('\n--------------------------------------------------');
  console.log('🎉 ALL RESTRICTION TESTS PASSED PERFECTLY!');
  console.log('--------------------------------------------------');

  // CLEANUP
  console.log('Cleaning up test data...');
  await db.delete(applications).where(inArray(applications.id, [informaticsApplication.id, medicineApplication.id]));
  await db.delete(users).where(inArray(users.id, [
    informaticsReviewer.id,
    medicineReviewer.id,
    informaticsLecturer.id,
    medicineLecturer.id,
  ]));
  await db.delete(applicationRounds).where(eq(applicationRounds.id, testRound.id));
  
  if (adminUser.email === 'testadmin@uog.edu.et') {
    await db.delete(users).where(eq(users.id, adminUser.id));
  }
  console.log('Cleanup completed successfully.');
}

main()
  .catch((error) => {
    console.error('❌ TESTING FAILED:');
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (pool) {
      await pool.end();
    }
  });
