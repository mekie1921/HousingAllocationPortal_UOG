import {
  findAnnouncements,
  findActiveAnnouncements,
  createAnnouncement,
  updateAnnouncement,
  deleteAnnouncement,
  findAnnouncementById,
} from '../repository/announcement.repository.js';
import { notifyUsersAboutAnnouncement } from './notification.service.js';
import type { UserRole } from '../lib/db/schema/auth.js';

export async function listAnnouncements(filters?: {
  targetRoles?: string[];
  isActive?: boolean;
  createdBy?: string;
}) {
  return findAnnouncements(filters);
}

export async function getActiveAnnouncements(targetRoles?: string[]) {
  return findActiveAnnouncements(targetRoles);
}

export async function createAnnouncementService(input: {
  title: string;
  content: string;
  type: string;
  targetRoles?: string[];
  startsAt?: Date;
  endsAt?: Date;
  createdBy: string;
}) {
  const created = await createAnnouncement(input);

  // Dispatch notifications (emails) to target users asynchronously
  try {
    if (created) {
      const payload = {
        id: created.id,
        title: created.title,
        content: created.content,
        type: created.type,
        targetRoles: Array.isArray(created.targetRoles)
          ? (created.targetRoles as UserRole[])
          : undefined,
      };

      void notifyUsersAboutAnnouncement(payload);
    }
  } catch (err) {
    // do not fail the request if notifications fail
    console.error('Error dispatching announcement notifications', err);
  }

  return created;
}

export async function updateAnnouncementService(
  id: string,
  input: {
    title?: string;
    content?: string;
    type?: string;
    targetRoles?: string[];
    isActive?: boolean;
    startsAt?: Date;
    endsAt?: Date;
  }
) {
  return updateAnnouncement(id, input);
}

export async function deleteAnnouncementService(id: string) {
  return deleteAnnouncement(id);
}

export async function getAnnouncementById(id: string) {
  return findAnnouncementById(id);
}
