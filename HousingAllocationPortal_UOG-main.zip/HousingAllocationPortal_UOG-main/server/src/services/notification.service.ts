import { findUsersByRoles } from '../repository/user.repository.js';
import { sendBrevoEmail } from '../utils/send-brevo-email.js';
import type { UserRole } from '../lib/db/schema/auth.js';

export async function notifyUsersAboutAnnouncement(announcement: {
  id: string;
  title: string;
  content: string;
  type: string;
  targetRoles?: UserRole[] | null;
}) {
  try {
    const rolesToNotify: UserRole[] = announcement.targetRoles && announcement.targetRoles.length > 0
      ? announcement.targetRoles
      : ['LECTURER', 'ADMIN', 'OFFICER', 'COMMITTEE'];

    const users = await findUsersByRoles(rolesToNotify);
    if (!users || users.length === 0) return;

    const sendPromises = users.map((u) =>
      sendBrevoEmail({
        to: { email: u.email, name: u.name ?? '' },
        subject: `[Announcement] ${announcement.title}`,
        htmlContent: `<p>${announcement.content}</p>`,
      }).catch((err) => {
        // swallow errors per-recipient to avoid failing all
        console.error('Failed to send announcement email to', u.email, err?.message ?? err);
      })
    );

    await Promise.allSettled(sendPromises);
  } catch (err) {
    console.error('Failed to notify users about announcement', err);
  }
}
