import { and, asc, eq, inArray, isNull, sql } from 'drizzle-orm';

import { db } from '../lib/db/index.js';
import { allocationReports } from '../lib/db/schema/report.js';
import { allocationResults } from '../lib/db/schema/allocation.js';
import { applications, applicationRounds } from '../lib/db/schema/application.js';
import { users } from '../lib/db/schema/auth.js';
import { committeeRankEntries } from '../lib/db/schema/committee-ranking.js';
import { housingUnits } from '../lib/db/schema/housing.js';
import { scoreSnapshots } from '../lib/db/schema/scoring.js';

export async function findRoundsReadyForAllocation() {
  return db
    .select({
      id: applicationRounds.id,
      name: applicationRounds.name,
      status: applicationRounds.status,
      committeeRankingStatus: applicationRounds.committeeRankingStatus,
      startsAt: applicationRounds.startsAt,
      endsAt: applicationRounds.endsAt,
    })
    .from(applicationRounds)
    .where(eq(applicationRounds.status, 'OPEN'))
    .orderBy(asc(applicationRounds.startsAt));
}

export async function createApplicationRound(input: {
  name: string;
  description: string | null;
  status: 'DRAFT' | 'OPEN' | 'CLOSED' | 'ARCHIVED';
  startsAt: Date;
  endsAt: Date;
  createdByUserId: string;
}) {
  const [row] = await db
    .insert(applicationRounds)
    .values({
      name: input.name,
      description: input.description,
      status: input.status,
      committeeRankingStatus: 'DRAFT',
      startsAt: input.startsAt,
      endsAt: input.endsAt,
      createdByUserId: input.createdByUserId,
    })
    .returning({
      id: applicationRounds.id,
      name: applicationRounds.name,
      description: applicationRounds.description,
      status: applicationRounds.status,
      committeeRankingStatus: applicationRounds.committeeRankingStatus,
      committeePreliminarySubmittedAt: applicationRounds.committeePreliminarySubmittedAt,
      committeeFinalSubmittedAt: applicationRounds.committeeFinalSubmittedAt,
      startsAt: applicationRounds.startsAt,
      endsAt: applicationRounds.endsAt,
      createdByUserId: applicationRounds.createdByUserId,
      createdAt: applicationRounds.createdAt,
      updatedAt: applicationRounds.updatedAt,
    });

  return row ?? null;
}

export async function findAllApplicationRounds() {
  return db
    .select({
      id: applicationRounds.id,
      name: applicationRounds.name,
      description: applicationRounds.description,
      status: applicationRounds.status,
      committeeRankingStatus: applicationRounds.committeeRankingStatus,
      committeePreliminarySubmittedAt: applicationRounds.committeePreliminarySubmittedAt,
      committeeFinalSubmittedAt: applicationRounds.committeeFinalSubmittedAt,
      startsAt: applicationRounds.startsAt,
      endsAt: applicationRounds.endsAt,
      createdByUserId: applicationRounds.createdByUserId,
      createdAt: applicationRounds.createdAt,
      updatedAt: applicationRounds.updatedAt,
    })
    .from(applicationRounds)
    .orderBy(asc(applicationRounds.startsAt));
}

export async function findRoundById(roundId: string) {
  const [row] = await db
    .select({
      id: applicationRounds.id,
      name: applicationRounds.name,
      status: applicationRounds.status,
      committeeRankingStatus: applicationRounds.committeeRankingStatus,
      startsAt: applicationRounds.startsAt,
      endsAt: applicationRounds.endsAt,
    })
    .from(applicationRounds)
    .where(eq(applicationRounds.id, roundId))
    .limit(1);

  return row ?? null;
}

export async function updateApplicationRoundStatus(
  roundId: string,
  status: 'DRAFT' | 'OPEN' | 'CLOSED' | 'ARCHIVED',
) {
  const [row] = await db
    .update(applicationRounds)
    .set({
      status,
      updatedAt: new Date(),
    })
    .where(eq(applicationRounds.id, roundId))
    .returning({
      id: applicationRounds.id,
      name: applicationRounds.name,
      description: applicationRounds.description,
      status: applicationRounds.status,
      committeeRankingStatus: applicationRounds.committeeRankingStatus,
      committeePreliminarySubmittedAt: applicationRounds.committeePreliminarySubmittedAt,
      committeeFinalSubmittedAt: applicationRounds.committeeFinalSubmittedAt,
      startsAt: applicationRounds.startsAt,
      endsAt: applicationRounds.endsAt,
      createdByUserId: applicationRounds.createdByUserId,
      createdAt: applicationRounds.createdAt,
      updatedAt: applicationRounds.updatedAt,
    });

  return row ?? null;
}

export async function deleteApplicationRound(roundId: string) {
  await db.delete(applicationRounds).where(eq(applicationRounds.id, roundId));
}

export async function saveAllocationReport(input: {
  roundId: string;
  roundName: string;
  roundStatus: string;
  committeeRankingStatus: string;
  allocationCount: number;
  reportData: any;
  sentByUserId: string;
}) {
  const [row] = await db
    .insert(allocationReports)
    .values({
      roundId: input.roundId,
      roundName: input.roundName,
      roundStatus: input.roundStatus,
      committeeRankingStatus: input.committeeRankingStatus,
      allocationCount: String(input.allocationCount),
      reportData: input.reportData,
      sentByUserId: input.sentByUserId,
      status: 'PENDING',
    })
    .returning({
      id: allocationReports.id,
      roundId: allocationReports.roundId,
      roundName: allocationReports.roundName,
      roundStatus: allocationReports.roundStatus,
      committeeRankingStatus: allocationReports.committeeRankingStatus,
      allocationCount: allocationReports.allocationCount,
      reportData: allocationReports.reportData,
      sentByUserId: allocationReports.sentByUserId,
      sentAt: allocationReports.sentAt,
      status: allocationReports.status,
    });
  return row;
}

export async function findAllAllocationReports() {
  return db
    .select()
    .from(allocationReports)
    .where(isNull(allocationReports.deletedAt))
    .orderBy(allocationReports.sentAt);
}

export async function findAllocationReportById(id: string) {
  const [row] = await db
    .select()
    .from(allocationReports)
    .where(eq(allocationReports.id, id));
  return row;
}

export async function updateAllocationReportStatus(id: string, status: string, adminNotes?: string, reviewedByUserId?: string) {
  const [row] = await db
    .update(allocationReports)
    .set({
      status,
      adminNotes,
      reviewedAt: new Date(),
      reviewedByUserId,
    })
    .where(eq(allocationReports.id, id))
    .returning();
  return row;
}

export async function deleteAllocationReport(id: string) {
  await db
    .update(allocationReports)
    .set({ deletedAt: new Date() })
    .where(eq(allocationReports.id, id));
}

export async function findAvailableHousingUnits() {
  return db
    .select({
      id: housingUnits.id,
      buildingName: housingUnits.buildingName,
      blockNumber: housingUnits.blockNumber,
      roomNumber: housingUnits.roomNumber,
      roomType: housingUnits.roomType,
      status: housingUnits.status,
      location: housingUnits.location,
    })
    .from(housingUnits)
    .where(eq(housingUnits.status, 'Available'))
    .orderBy(
      asc(housingUnits.buildingName),
      asc(housingUnits.blockNumber),
      asc(housingUnits.roomNumber),
    );
}

export async function findRoundRankedApplications(roundId: string) {
  return db
    .select({
      applicationId: applications.id,
      userId: applications.userId,
      preferredHousingUnitId: applications.preferredHousingUnitId,
      rankPosition: committeeRankEntries.rankPosition,
    })
    .from(committeeRankEntries)
    .innerJoin(applications, eq(committeeRankEntries.applicationId, applications.id))
    .where(
      and(
        eq(committeeRankEntries.roundId, roundId),
        eq(applications.roundId, roundId),
        eq(applications.status, 'RANKED'),
      ),
    )
    .orderBy(asc(committeeRankEntries.rankPosition));
}

// PRELIMINARY allocation should reflect the committee rank entries even before
// applications are marked as RANKED (that only happens on FINAL submission).
export async function findRoundPreliminaryRankedApplications(roundId: string) {
  return db
    .select({
      applicationId: applications.id,
      userId: applications.userId,
      preferredHousingUnitId: applications.preferredHousingUnitId,
      rankPosition: committeeRankEntries.rankPosition,
    })
    .from(committeeRankEntries)
    .innerJoin(applications, eq(committeeRankEntries.applicationId, applications.id))
    .where(
      and(
        eq(committeeRankEntries.roundId, roundId),
        eq(applications.roundId, roundId),
      ),
    )
    .orderBy(asc(committeeRankEntries.rankPosition));
}

export async function findRoundAllocationResults(roundId: string) {
  const results = await db
    .select({
      id: allocationResults.id,
      roundId: allocationResults.roundId,
      applicationId: allocationResults.applicationId,
      housingUnitId: allocationResults.housingUnitId,
      status: allocationResults.status,
      allocatedAt: allocationResults.allocatedAt,
      lecturerName: users.name,
      lecturerDepartment: sql<string>`COALESCE(${users.department}, 'Not Assigned')`,
      housingBuildingName: housingUnits.buildingName,
      housingBlockNumber: housingUnits.blockNumber,
      housingRoomNumber: housingUnits.roomNumber,
      housingRoomType: housingUnits.roomType,
      score: sql<number>`COALESCE(${scoreSnapshots.finalScore}, 0)`,
      rankPosition: sql<number>`COALESCE(${committeeRankEntries.rankPosition}, 0)`,
      applicationNotes: applications.notes,
    })
    .from(allocationResults)
    .leftJoin(applications, eq(allocationResults.applicationId, applications.id))
    .leftJoin(users, eq(applications.userId, users.id))
    .leftJoin(housingUnits, eq(allocationResults.housingUnitId, housingUnits.id))
    .leftJoin(scoreSnapshots, eq(applications.scoreSnapshotId, scoreSnapshots.id))
    .leftJoin(committeeRankEntries, 
      and(
        eq(committeeRankEntries.applicationId, allocationResults.applicationId),
        eq(committeeRankEntries.roundId, roundId)
      )
    )
    .where(eq(allocationResults.roundId, roundId))
    .orderBy(asc(allocationResults.allocatedAt));

  // Fallback: Extract score from notes if score snapshot is not available
  return results.map((result) => {
    let finalScore = result.score;
    
    if (result.applicationNotes && result.score === 0) {
      try {
        const parsedNotes = JSON.parse(result.applicationNotes);
        if (parsedNotes.score && parsedNotes.score.final !== undefined) {
          finalScore = parsedNotes.score.final;
        }
      } catch (e) {
        // If notes can't be parsed, use the snapshot score (which is 0)
        console.log('Could not parse application notes for score:', e);
      }
    }
    
    return {
      ...result,
      score: finalScore,
    };
  });
}

export async function findExistingRoundAllocationHousingUnitIds(roundId: string) {
  const rows = await db
    .select({
      housingUnitId: allocationResults.housingUnitId,
    })
    .from(allocationResults)
    .where(eq(allocationResults.roundId, roundId));

  return rows.map((row) => row.housingUnitId);
}

export async function findExistingRoundAllocationHousingUnitIdsByStatus(
  roundId: string,
  status: 'PRELIMINARY' | 'PUBLISHED',
) {
  const rows = await db
    .select({
      housingUnitId: allocationResults.housingUnitId,
    })
    .from(allocationResults)
    .where(and(eq(allocationResults.roundId, roundId), eq(allocationResults.status, status)));

  return rows.map((row) => row.housingUnitId);
}

export async function clearRoundAllocationResults(roundId: string, status?: 'PRELIMINARY' | 'PUBLISHED') {
  if (status) {
    await db
      .delete(allocationResults)
      .where(and(eq(allocationResults.roundId, roundId), eq(allocationResults.status, status)));
    return;
  }

  await db.delete(allocationResults).where(eq(allocationResults.roundId, roundId));
}

export async function markHousingUnitsStatus(
  housingUnitIds: string[],
  status: 'Available' | 'Reserved' | 'Occupied',
) {
  if (housingUnitIds.length === 0) {
    return [];
  }

  return db
    .update(housingUnits)
    .set({
      status,
      updatedAt: new Date(),
    })
    .where(inArray(housingUnits.id, housingUnitIds))
    .returning({
      id: housingUnits.id,
      status: housingUnits.status,
    });
}

export async function insertAllocationResults(
  rows: Array<{
    roundId: string;
    applicationId: string;
    housingUnitId: string;
    allocatedByUserId: string;
  }>,
  status: 'PRELIMINARY' | 'PUBLISHED' = 'PRELIMINARY',
) {
  if (rows.length === 0) {
    return [];
  }

  return db
    .insert(allocationResults)
    .values(
      rows.map((row) => ({
        roundId: row.roundId,
        applicationId: row.applicationId,
        housingUnitId: row.housingUnitId,
        allocatedByUserId: row.allocatedByUserId,
        status,
      })),
    )
    .returning({
      id: allocationResults.id,
      roundId: allocationResults.roundId,
      applicationId: allocationResults.applicationId,
      housingUnitId: allocationResults.housingUnitId,
      status: allocationResults.status,
      allocatedAt: allocationResults.allocatedAt,
    });
}

export async function markApplicationsAllocated(applicationIds: string[]) {
  if (applicationIds.length === 0) {
    return [];
  }

  return db
    .update(applications)
    .set({
      status: 'ALLOCATED',
      updatedAt: new Date(),
    })
    .where(inArray(applications.id, applicationIds))
    .returning({
      id: applications.id,
      status: applications.status,
    });
}
