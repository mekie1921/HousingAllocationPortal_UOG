import type { NextFunction, Request, Response } from 'express';

import type { SaveApplicationDraftDto } from '../dtos/application.dto.js';
import { AppError } from '../errorHandler/app-error.js';
import {
  getApplicationFormOptions,
  getMyAllocationResults,
  getMyDepartmentAllocationResults,
  getMyApplications,
  getMyApplicationDetails,
  saveMyApplicationDraft,
  submitMyApplication,
  deleteMyApplication,
} from '../services/application.service.js';

export async function saveApplicationDraftController(
  req: Request<unknown, unknown, Partial<SaveApplicationDraftDto>>,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const { roundId, preferredHousingUnitId, notes } = req.body;

    if (
      typeof roundId !== 'string' ||
      (preferredHousingUnitId !== undefined &&
        preferredHousingUnitId !== null &&
        typeof preferredHousingUnitId !== 'string') ||
      (notes !== undefined && notes !== null && typeof notes !== 'string')
    ) {
      throw new AppError(
        'roundId, preferredHousingUnitId, and notes are invalid',
        400,
        'VALIDATION_ERROR',
      );
    }

    const draft = await saveMyApplicationDraft(req.user.userId, {
      roundId,
      preferredHousingUnitId: preferredHousingUnitId ?? null,
      notes: notes ?? null,
    });

    res.status(200).json(draft);
  } catch (error) {
    next(error);
  }
}

export async function submitApplicationController(
  req: Request<{ id: string }>,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const submitted = await submitMyApplication(req.user.userId, req.params.id);
    res.status(200).json(submitted);
  } catch (error) {
    next(error);
  }
}

export async function getMyApplicationsController(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const applications = await getMyApplications(req.user.userId);
    res.status(200).json(applications);
  } catch (error) {
    next(error);
  }
}

export async function deleteApplicationController(
  req: Request<{ id: string }>,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const deleted = await deleteMyApplication(req.user.userId, req.params.id);
    res.status(200).json(deleted);
  } catch (error) {
    next(error);
  }
}

export async function getApplicationOptionsController(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    // Remove authentication requirement for options endpoint
    const options = await getApplicationFormOptions();
    res.status(200).json(options);
  } catch (error) {
    next(error);
  }
}

export async function getMyDepartmentResultsController(
  req: Request<unknown, unknown, unknown, { roundId?: string }>,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const roundId =
      typeof req.query.roundId === 'string' && req.query.roundId.trim().length > 0
        ? req.query.roundId.trim()
        : undefined;
    const results = await getMyDepartmentAllocationResults(req.user.userId, roundId);
    res.status(200).json(results);
  } catch (error) {
    next(error);
  }
}

export async function getMyAllocationResultsController(
  req: Request<unknown, unknown, unknown, { roundId?: string }>,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const roundId =
      typeof req.query.roundId === 'string' && req.query.roundId.trim().length > 0
        ? req.query.roundId.trim()
        : undefined;
    const results = await getMyAllocationResults(req.user.userId, roundId);
    res.status(200).json(results);
  } catch (error) {
    next(error);
  }
}

export async function getMyApplicationDetailsController(
  req: Request<{ id: string }>,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    if (!req.user) {
      throw new AppError('Authentication required', 401, 'UNAUTHORIZED');
    }

    const details = await getMyApplicationDetails(req.user.userId, req.params.id);
    res.status(200).json(details);
  } catch (error) {
    next(error);
  }
}
