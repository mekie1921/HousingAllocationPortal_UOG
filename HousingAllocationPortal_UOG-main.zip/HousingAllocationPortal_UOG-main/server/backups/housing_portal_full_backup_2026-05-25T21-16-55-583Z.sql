--
-- PostgreSQL database dump
--

\restrict AWt2wpujzEbutsnIMMzyWlocR8pdGkQFSwRjDSmvdg4ELsYMI70ozOxlkdPPTWM

-- Dumped from database version 17.9
-- Dumped by pg_dump version 17.9

-- Started on 2026-05-26 00:16:56

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 6 (class 2615 OID 17411)
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA drizzle;


--
-- TOC entry 930 (class 1247 OID 17723)
-- Name: allocation_result_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.allocation_result_status AS ENUM (
    'PRELIMINARY',
    'PUBLISHED'
);


--
-- TOC entry 903 (class 1247 OID 17554)
-- Name: application_round_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.application_round_status AS ENUM (
    'DRAFT',
    'OPEN',
    'CLOSED',
    'ARCHIVED'
);


--
-- TOC entry 906 (class 1247 OID 17564)
-- Name: application_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.application_status AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'UNDER_REVIEW',
    'RANKED',
    'ALLOCATED',
    'REJECTED',
    'WITHDRAWN'
);


--
-- TOC entry 924 (class 1247 OID 17691)
-- Name: committee_ranking_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.committee_ranking_status AS ENUM (
    'DRAFT',
    'PRELIMINARY_SUBMITTED',
    'FINAL_SUBMITTED'
);


--
-- TOC entry 936 (class 1247 OID 17760)
-- Name: complaint_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.complaint_status AS ENUM (
    'OPEN',
    'RESOLVED',
    'CLOSED'
);


--
-- TOC entry 915 (class 1247 OID 17633)
-- Name: document_purpose; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.document_purpose AS ENUM (
    'EDUCATIONAL_TITLE',
    'EDUCATIONAL_LEVEL',
    'SERVICE_YEARS',
    'RESPONSIBILITY',
    'FAMILY_STATUS',
    'DISABILITY_CERTIFICATION',
    'HIV_ILLNESS_CERTIFICATION',
    'SPOUSE_PROOF',
    'OTHER'
);


--
-- TOC entry 918 (class 1247 OID 17652)
-- Name: document_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.document_status AS ENUM (
    'UPLOADED',
    'VERIFIED',
    'REJECTED'
);


--
-- TOC entry 882 (class 1247 OID 17460)
-- Name: housing_condition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.housing_condition AS ENUM (
    'New',
    'Good',
    'Needs Repair',
    'Under Maintenance'
);


--
-- TOC entry 885 (class 1247 OID 17470)
-- Name: housing_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.housing_status AS ENUM (
    'Available',
    'Occupied',
    'Reserved'
);


--
-- TOC entry 888 (class 1247 OID 17478)
-- Name: room_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.room_type AS ENUM (
    'Studio',
    '1-Bedroom',
    '2-Bedroom',
    '3-Bedroom'
);


--
-- TOC entry 873 (class 1247 OID 17422)
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'ADMIN',
    'LECTURER',
    'OFFICER',
    'COMMITTEE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 17413)
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: -
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


--
-- TOC entry 218 (class 1259 OID 17412)
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: -
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 5253 (class 0 OID 0)
-- Dependencies: 218
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: -
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- TOC entry 239 (class 1259 OID 17930)
-- Name: allocation_overrides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allocation_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    application_id uuid NOT NULL,
    original_room_id uuid,
    new_room_id uuid NOT NULL,
    reason text NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 17976)
-- Name: allocation_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allocation_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    round_name character varying(255) NOT NULL,
    round_status character varying(50) NOT NULL,
    committee_ranking_status character varying(50) NOT NULL,
    allocation_count text NOT NULL,
    report_data jsonb NOT NULL,
    sent_by_user_id uuid NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    admin_notes text,
    reviewed_at timestamp without time zone,
    reviewed_by_user_id uuid,
    deleted_at timestamp without time zone
);


--
-- TOC entry 230 (class 1259 OID 17727)
-- Name: allocation_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allocation_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    application_id uuid NOT NULL,
    housing_unit_id uuid NOT NULL,
    allocated_by_user_id uuid NOT NULL,
    status public.allocation_result_status DEFAULT 'PRELIMINARY'::public.allocation_result_status NOT NULL,
    allocated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 17892)
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    type character varying(50) DEFAULT 'INFO'::character varying NOT NULL,
    target_roles text,
    is_active boolean DEFAULT true NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 17579)
-- Name: application_rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.application_rounds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    status public.application_round_status DEFAULT 'DRAFT'::public.application_round_status NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    committee_ranking_status public.committee_ranking_status DEFAULT 'DRAFT'::public.committee_ranking_status NOT NULL,
    committee_preliminary_submitted_at timestamp with time zone,
    committee_final_submitted_at timestamp with time zone
);


--
-- TOC entry 227 (class 1259 OID 17590)
-- Name: applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.applications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    round_id uuid NOT NULL,
    preferred_housing_unit_id uuid,
    score_snapshot_id uuid,
    status public.application_status DEFAULT 'DRAFT'::public.application_status NOT NULL,
    submitted_at timestamp with time zone,
    reviewed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewed_by_user_id uuid,
    compliance_issue boolean DEFAULT false NOT NULL,
    compliance_notes text,
    final_score double precision
);


--
-- TOC entry 235 (class 1259 OID 17856)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    action character varying(50) NOT NULL,
    affected_record uuid,
    details text,
    ip_address character varying(45),
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 17839)
-- Name: backup_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL,
    description text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


--
-- TOC entry 240 (class 1259 OID 17959)
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    backup_id uuid,
    level character varying(20) NOT NULL,
    message text NOT NULL,
    details text,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 17820)
-- Name: backup_schedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_schedule (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    frequency character varying(50) NOT NULL,
    tables text[],
    enabled boolean DEFAULT true NOT NULL,
    retention_days integer DEFAULT 30 NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    created_by uuid NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 17697)
-- Name: committee_rank_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.committee_rank_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    round_id uuid NOT NULL,
    application_id uuid NOT NULL,
    rank_position integer NOT NULL,
    updated_by_user_id uuid NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 17767)
-- Name: complaint_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.complaint_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    sender_user_id uuid NOT NULL,
    message text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 17776)
-- Name: complaint_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.complaint_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    lecturer_user_id uuid NOT NULL,
    target_department character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    status public.complaint_status DEFAULT 'OPEN'::public.complaint_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 17487)
-- Name: housing_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.housing_units (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    building_name character varying(255) NOT NULL,
    block_number character varying(100) NOT NULL,
    room_number character varying(100) NOT NULL,
    room_type public.room_type NOT NULL,
    condition public.housing_condition NOT NULL,
    status public.housing_status DEFAULT 'Available'::public.housing_status NOT NULL,
    location character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 17659)
-- Name: lecturer_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lecturer_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    application_id uuid,
    purpose public.document_purpose NOT NULL,
    original_file_name character varying(255) NOT NULL,
    mime_type character varying(120) NOT NULL,
    size_bytes integer NOT NULL,
    storage_path text NOT NULL,
    notes text,
    status public.document_status DEFAULT 'UPLOADED'::public.document_status NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 17499)
-- Name: lecturer_scoring_criteria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lecturer_scoring_criteria (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    educational_title character varying(255) NOT NULL,
    educational_level character varying(128) NOT NULL,
    service_years integer DEFAULT 0 NOT NULL,
    responsibility character varying(255) NOT NULL,
    family_status character varying(255) NOT NULL,
    female_bonus_eligible boolean DEFAULT false NOT NULL,
    disability_bonus_eligible boolean DEFAULT false NOT NULL,
    hiv_illness_bonus_eligible boolean DEFAULT false NOT NULL,
    spouse_bonus_eligible boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 17431)
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    code character varying(12) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    resend_count integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 17514)
-- Name: score_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.score_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    scoring_policy_id uuid,
    breakdown jsonb NOT NULL,
    base_total double precision NOT NULL,
    bonus_total double precision NOT NULL,
    final_score double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 17523)
-- Name: scoring_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scoring_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    version integer DEFAULT 1 NOT NULL,
    effective_from timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 17912)
-- Name: system_backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    filename character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    size integer NOT NULL,
    status character varying(50) DEFAULT 'creating'::character varying NOT NULL,
    description text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    tables text[],
    file_path character varying(500),
    checksum character varying(64),
    restored_at timestamp with time zone,
    restored_by uuid
);


--
-- TOC entry 236 (class 1259 OID 17874)
-- Name: system_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL,
    description text,
    is_public boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


--
-- TOC entry 221 (class 1259 OID 17438)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(320) NOT NULL,
    password character varying(255),
    role public.user_role NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    department character varying(255),
    is_active boolean DEFAULT true NOT NULL
);


--
-- TOC entry 4864 (class 2604 OID 17416)
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- TOC entry 5225 (class 0 OID 17413)
-- Dependencies: 219
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: -
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	13355394e838851a7788000be6ce3f1afa84166b4dd399b2616474f5ff8d3b59	1774984956940
2	e7e816ead89046472b1db502a45cab721b784ae551d8df0d7173ac88c203bd30	1774992676927
3	a681fd279fe53a182c503338723ed1a816f4667d529f7bfd8f903761154611d1	1775395409859
4	0a7af184706cf04e2ff3629b261ec1c307e9d3f0839ef0fd573e2b34c2191e45	1775606400000
5	70a513e47f97eeb4fbf011401b1269e0c8443bb8bd376a40a75aa5037aad23ff	1775979129454
6	b6491286c4b23558bb2a9673f35bf02cd1d9ad927049ade8f27270b88e4d267b	1776165593465
7	daeb174ba57bb1e926cf48d54753b012a4886c6a6d0f668c75bf14ba6e195f77	1776167734066
8	6953abcebf165e3d4513f79ec8d02a5d8b67a353b2509945877ba00842cf491d	1776168857035
9	3cba3620e8f3768a886a9ed919b831fe230e13517814ec847f3e228a5cdb091b	1776170618203
10	4be377cfa15f9ad738d0f412b3f8f637652569971aefdadc0c728a51cac5d006	1776171305266
11	637ba44d81b9e2c7038bc4ea79498f3d83996fc9200906b39cf892a2760b3ce8	1776173036242
12	dcba7ba62356487f1e273cc5a0d0b0b16fcec06692754218135021f0babcdeba	1776174110483
\.


--
-- TOC entry 5245 (class 0 OID 17930)
-- Dependencies: 239
-- Data for Name: allocation_overrides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allocation_overrides (id, application_id, original_room_id, new_room_id, reason, status, approved_by, approved_at, created_by, created_at) FROM stdin;
\.


--
-- TOC entry 5247 (class 0 OID 17976)
-- Dependencies: 241
-- Data for Name: allocation_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allocation_reports (id, round_id, round_name, round_status, committee_ranking_status, allocation_count, report_data, sent_by_user_id, sent_at, status, admin_notes, reviewed_at, reviewed_by_user_id, deleted_at) FROM stdin;
cc49186e-c84f-47bf-8c1b-fb62e2d7baea	ce1a4719-414d-4cc3-97df-58894232349e	ashnafi test  system	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "ce1a4719-414d-4cc3-97df-58894232349e", "name": "ashnafi test  system", "endsAt": "2026-08-06T06:10:00.000Z", "status": "OPEN", "startsAt": "2025-11-13T06:11:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "allocations": [{"id": "de35bbba-1dbd-407c-be85-5197cedaabc3", "status": "PRELIMINARY", "roundId": "ce1a4719-414d-4cc3-97df-58894232349e", "allocatedAt": "2026-05-20T06:20:57.962Z", "lecturerName": "ashu", "applicationId": "3129766c-6700-4057-b222-7ce809bcde08", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-20T06:21:26.768Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 09:21:26.981264	PENDING	\N	\N	\N	2026-05-21 05:57:52.591
40b5c69e-4d0f-426a-bd4d-1ae50c731d9c	ce1a4719-414d-4cc3-97df-58894232349e	ashnafi test  system	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "ce1a4719-414d-4cc3-97df-58894232349e", "name": "ashnafi test  system", "endsAt": "2026-08-06T06:10:00.000Z", "status": "OPEN", "startsAt": "2025-11-13T06:11:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "allocations": [{"id": "f349aa10-d293-44c6-805e-fad177d6af2e", "status": "PRELIMINARY", "roundId": "ce1a4719-414d-4cc3-97df-58894232349e", "allocatedAt": "2026-05-20T06:30:21.438Z", "lecturerName": "ashu", "applicationId": "3129766c-6700-4057-b222-7ce809bcde08", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-20T06:39:50.232Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 09:39:50.25096	PENDING	\N	\N	\N	2026-05-21 05:57:54.578
5938d865-5b67-49d9-ae3a-9105bbd1b22f	ce1a4719-414d-4cc3-97df-58894232349e	ashnafi test  system	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "ce1a4719-414d-4cc3-97df-58894232349e", "name": "ashnafi test  system", "endsAt": "2026-08-06T06:10:00.000Z", "status": "OPEN", "startsAt": "2025-11-13T06:11:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "allocations": [{"id": "f349aa10-d293-44c6-805e-fad177d6af2e", "status": "PRELIMINARY", "roundId": "ce1a4719-414d-4cc3-97df-58894232349e", "allocatedAt": "2026-05-20T06:30:21.438Z", "lecturerName": "ashu", "applicationId": "3129766c-6700-4057-b222-7ce809bcde08", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-20T06:43:18.750Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 09:43:19.381777	PENDING	\N	\N	\N	2026-05-21 05:57:55.377
8a85407e-703f-40e4-984a-5afd55521d17	ce1a4719-414d-4cc3-97df-58894232349e	ashnafi test  system	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "ce1a4719-414d-4cc3-97df-58894232349e", "name": "ashnafi test  system", "endsAt": "2026-08-06T06:10:00.000Z", "status": "OPEN", "startsAt": "2025-11-13T06:11:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "allocations": [{"id": "f349aa10-d293-44c6-805e-fad177d6af2e", "status": "PRELIMINARY", "roundId": "ce1a4719-414d-4cc3-97df-58894232349e", "allocatedAt": "2026-05-20T06:30:21.438Z", "lecturerName": "ashu", "applicationId": "3129766c-6700-4057-b222-7ce809bcde08", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-20T06:43:20.959Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 09:43:20.973233	PENDING	\N	\N	\N	2026-05-21 05:57:55.965
5a358a33-74fa-46a8-b405-edff28bf6964	23d76ba3-6402-4ac6-91b7-c10a22d7e274	ashu first	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "name": "ashu first", "endsAt": "2026-05-01T10:07:00.000Z", "status": "OPEN", "startsAt": "2025-10-23T10:10:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "allocations": [{"id": "172ce4d6-d416-47b2-afc8-22793623c660", "status": "PRELIMINARY", "roundId": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "allocatedAt": "2026-05-20T09:53:22.300Z", "lecturerName": "ashu", "applicationId": "fbc197c8-4a7d-4964-8622-a10eda0dbcd0", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-20T09:54:45.975Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 12:54:46.867945	RESOLVED	\N	2026-05-21 05:58:12.972	4ea19621-4295-4a3f-b522-4aef718ea07d	2026-05-21 05:59:07.105
aa2bce22-d437-40f9-9385-49dc36fb7649	23d76ba3-6402-4ac6-91b7-c10a22d7e274	ashu first	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "name": "ashu first", "endsAt": "2026-05-01T10:07:00.000Z", "status": "OPEN", "startsAt": "2025-10-23T10:10:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "allocations": [{"id": "46cd9a94-cd65-4385-a2f6-892f30f0e69b", "status": "PRELIMINARY", "roundId": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "allocatedAt": "2026-05-20T11:00:53.747Z", "lecturerName": "ashu", "applicationId": "fbc197c8-4a7d-4964-8622-a10eda0dbcd0", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-20T11:01:19.781Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 14:01:20.201613	RESOLVED	\N	2026-05-21 05:58:41.985	4ea19621-4295-4a3f-b522-4aef718ea07d	2026-05-21 06:10:35.494
f94d7e90-2945-4917-8713-e638970da04f	23d76ba3-6402-4ac6-91b7-c10a22d7e274	ashu first	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "name": "ashu first", "endsAt": "2026-05-01T10:07:00.000Z", "status": "OPEN", "startsAt": "2025-10-23T10:10:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "summary": {"published": 0, "preliminary": 1, "totalAllocations": 1}, "allocations": [{"id": "bd518c52-7542-4f64-aa21-129456f64efa", "status": "PRELIMINARY", "roundId": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "allocatedAt": "2026-05-21T17:37:51.686Z", "lecturerName": "ashu", "applicationId": "41acc7ac-28f7-4d3b-a56b-4aba61ac8a98", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-21T17:38:46.184Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-21 20:38:46.650893	PENDING	\N	\N	\N	\N
ea64c54f-4743-43ba-8de4-f117f1655d5c	23d76ba3-6402-4ac6-91b7-c10a22d7e274	ashu first	OPEN	PRELIMINARY_SUBMITTED	1	{"round": {"id": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "name": "ashu first", "endsAt": "2026-05-01T10:07:00.000Z", "status": "OPEN", "startsAt": "2025-10-23T10:10:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "summary": {"published": 0, "preliminary": 1, "totalAllocations": 1}, "allocations": [{"id": "bd518c52-7542-4f64-aa21-129456f64efa", "status": "PRELIMINARY", "roundId": "23d76ba3-6402-4ac6-91b7-c10a22d7e274", "allocatedAt": "2026-05-21T17:37:51.686Z", "lecturerName": "ashu", "applicationId": "41acc7ac-28f7-4d3b-a56b-4aba61ac8a98", "housingUnitId": "250ed57e-4dc4-4274-b7b6-35bde8ab828e", "housingRoomType": "1-Bedroom", "housingRoomNumber": "1", "housingBlockNumber": "1", "housingBuildingName": "maraki"}], "generatedAt": "2026-05-21T17:38:50.559Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-21 20:38:50.567913	PENDING	\N	\N	\N	\N
9e65cb72-d593-4fca-a234-767da2971683	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	7th test	OPEN	PRELIMINARY_SUBMITTED	2	{"round": {"id": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "name": "7th test", "endsAt": "2026-08-24T10:38:00.000Z", "status": "OPEN", "startsAt": "2026-05-16T11:35:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "summary": {"published": 0, "preliminary": 2, "totalAllocations": 2}, "allocations": [{"id": "2b003cbb-4ecf-434a-926c-95e40ff3cbc4", "score": 75.72999999999999, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-24T21:26:42.669Z", "lecturerName": "ashuvictor", "rankPosition": 1, "applicationId": "6725be3b-e6ea-4103-b402-fb2dc11a8081", "housingUnitId": "8039570d-5595-4060-98c6-1a5a71b6bbe9", "housingRoomType": "2-Bedroom", "applicationNotes": "{\\"fullName\\":\\"ashuvictor\\",\\"staffId\\":\\"WERTYU456\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0986543248\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"PROFESSOR\\",\\"educationalLevel\\":\\"MSC\\",\\"startDateAtUog\\":\\"2025-11-06\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"MARRIED_WITH_CHILDREN\\",\\"spouseName\\":\\"may\\",\\"spouseStaffId\\":\\"no\\",\\"numberOfDependents\\":\\"2\\",\\"hasSpouseAtUog\\":true,\\"isFemale\\":true,\\"isDisabled\\":true,\\"hasChronicIllness\\":true,\\"score\\":{\\"educationalTitle\\":40,\\"educationalLevel\\":3,\\"serviceYears\\":1.17,\\"responsibility\\":10,\\"familyStatus\\":10,\\"baseTotal\\":64.17,\\"femaleBonus\\":3.21,\\"disabilityBonus\\":3.21,\\"chronicIllnessBonus\\":1.93,\\"spouseBonus\\":3.21,\\"final\\":75.72999999999999},\\"submittedAt\\":\\"2026-05-24T20:58:26.266Z\\"}", "housingRoomNumber": "3", "housingBlockNumber": "3", "lecturerDepartment": "College of Informatics", "housingBuildingName": "errr"}, {"id": "99af2e44-3e15-400f-be57-1dfeddb55ece", "score": 63.35, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-24T21:26:42.669Z", "lecturerName": "aaa", "rankPosition": 2, "applicationId": "0efeb00a-3070-48df-8428-249163206615", "housingUnitId": "5910907d-1e40-4382-9cd6-80ecd64e0170", "housingRoomType": "1-Bedroom", "applicationNotes": "{\\"fullName\\":\\"mr ashe\\",\\"staffId\\":\\"HERO\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0997278931\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"PROFESSOR\\",\\"educationalLevel\\":\\"PHD\\",\\"startDateAtUog\\":\\"2022-10-07\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"SINGLE_WITHOUT_CHILDREN\\",\\"spouseName\\":\\"\\",\\"spouseStaffId\\":\\"\\",\\"numberOfDependents\\":\\"1\\",\\"hasSpouseAtUog\\":false,\\"isFemale\\":false,\\"isDisabled\\":false,\\"hasChronicIllness\\":false,\\"score\\":{\\"educationalTitle\\":40,\\"educationalLevel\\":5,\\"serviceYears\\":8.35,\\"responsibility\\":10,\\"familyStatus\\":0,\\"baseTotal\\":63.35,\\"femaleBonus\\":0,\\"disabilityBonus\\":0,\\"chronicIllnessBonus\\":0,\\"spouseBonus\\":0,\\"final\\":63.35},\\"submittedAt\\":\\"2026-05-24T21:13:57.052Z\\"}", "housingRoomNumber": "4", "housingBlockNumber": "1", "lecturerDepartment": "College of Informatics", "housingBuildingName": "mar"}], "generatedAt": "2026-05-24T21:28:31.458Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 00:28:32.222124	PENDING	\N	\N	\N	\N
c9843713-ced4-47fa-968a-119479719140	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	7th test	OPEN	PRELIMINARY_SUBMITTED	2	{"round": {"id": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "name": "7th test", "endsAt": "2026-08-24T10:38:00.000Z", "status": "OPEN", "startsAt": "2026-05-16T11:35:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "summary": {"published": 0, "preliminary": 2, "totalAllocations": 2}, "allocations": [{"id": "70734345-f128-4968-8a5c-95e78c82dc8a", "score": 75.72999999999999, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-24T21:54:01.755Z", "lecturerName": "ashuvictor", "rankPosition": 1, "applicationId": "6725be3b-e6ea-4103-b402-fb2dc11a8081", "housingUnitId": "8039570d-5595-4060-98c6-1a5a71b6bbe9", "housingRoomType": "2-Bedroom", "applicationNotes": "{\\"fullName\\":\\"ashuvictor\\",\\"staffId\\":\\"WERTYU456\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0986543248\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"PROFESSOR\\",\\"educationalLevel\\":\\"MSC\\",\\"startDateAtUog\\":\\"2025-11-06\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"MARRIED_WITH_CHILDREN\\",\\"spouseName\\":\\"may\\",\\"spouseStaffId\\":\\"no\\",\\"numberOfDependents\\":\\"2\\",\\"hasSpouseAtUog\\":true,\\"isFemale\\":true,\\"isDisabled\\":true,\\"hasChronicIllness\\":true,\\"score\\":{\\"educationalTitle\\":40,\\"educationalLevel\\":3,\\"serviceYears\\":1.17,\\"responsibility\\":10,\\"familyStatus\\":10,\\"baseTotal\\":64.17,\\"femaleBonus\\":3.21,\\"disabilityBonus\\":3.21,\\"chronicIllnessBonus\\":1.93,\\"spouseBonus\\":3.21,\\"final\\":75.72999999999999},\\"submittedAt\\":\\"2026-05-24T20:58:26.266Z\\"}", "housingRoomNumber": "3", "housingBlockNumber": "3", "lecturerDepartment": "College of Informatics", "housingBuildingName": "errr"}, {"id": "445356d0-dbf1-450f-acab-0fcfa3ba2d05", "score": 63.35, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-24T21:54:01.755Z", "lecturerName": "aaa", "rankPosition": 2, "applicationId": "0efeb00a-3070-48df-8428-249163206615", "housingUnitId": "5910907d-1e40-4382-9cd6-80ecd64e0170", "housingRoomType": "1-Bedroom", "applicationNotes": "{\\"fullName\\":\\"mr ashe\\",\\"staffId\\":\\"HERO\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0997278931\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"PROFESSOR\\",\\"educationalLevel\\":\\"PHD\\",\\"startDateAtUog\\":\\"2022-10-07\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"SINGLE_WITHOUT_CHILDREN\\",\\"spouseName\\":\\"\\",\\"spouseStaffId\\":\\"\\",\\"numberOfDependents\\":\\"1\\",\\"hasSpouseAtUog\\":false,\\"isFemale\\":false,\\"isDisabled\\":false,\\"hasChronicIllness\\":false,\\"score\\":{\\"educationalTitle\\":40,\\"educationalLevel\\":5,\\"serviceYears\\":8.35,\\"responsibility\\":10,\\"familyStatus\\":0,\\"baseTotal\\":63.35,\\"femaleBonus\\":0,\\"disabilityBonus\\":0,\\"chronicIllnessBonus\\":0,\\"spouseBonus\\":0,\\"final\\":63.35},\\"submittedAt\\":\\"2026-05-24T21:13:57.052Z\\"}", "housingRoomNumber": "4", "housingBlockNumber": "1", "lecturerDepartment": "College of Informatics", "housingBuildingName": "mar"}], "generatedAt": "2026-05-24T21:55:49.190Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 00:55:49.6705	PENDING	\N	\N	\N	\N
ce77f068-da88-4eb6-a7d4-de4ebf20569a	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	7th test	OPEN	PRELIMINARY_SUBMITTED	2	{"round": {"id": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "name": "7th test", "endsAt": "2026-08-24T10:38:00.000Z", "status": "OPEN", "startsAt": "2026-05-16T11:35:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "summary": {"published": 0, "preliminary": 2, "totalAllocations": 2}, "allocations": [{"id": "574720f6-1032-429a-b6a8-c30587d5096d", "score": 72.19000000000001, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-25T08:50:03.646Z", "lecturerName": "ashuvictor", "rankPosition": 1, "applicationId": "6725be3b-e6ea-4103-b402-fb2dc11a8081", "housingUnitId": "8039570d-5595-4060-98c6-1a5a71b6bbe9", "housingRoomType": "2-Bedroom", "applicationNotes": "{\\"fullName\\":\\"ashuvictor\\",\\"staffId\\":\\"WERTYU456\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0986543248\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"ASSOCIATE_PROFESSOR\\",\\"educationalLevel\\":\\"MSC\\",\\"startDateAtUog\\":\\"2025-11-06\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"MARRIED_WITH_CHILDREN\\",\\"spouseName\\":\\"may\\",\\"spouseStaffId\\":\\"no\\",\\"numberOfDependents\\":\\"2\\",\\"hasSpouseAtUog\\":true,\\"isFemale\\":true,\\"isDisabled\\":true,\\"hasChronicIllness\\":true,\\"score\\":{\\"educationalTitle\\":37,\\"educationalLevel\\":3,\\"serviceYears\\":1.17,\\"responsibility\\":10,\\"familyStatus\\":10,\\"baseTotal\\":61.17,\\"femaleBonus\\":3.06,\\"disabilityBonus\\":3.06,\\"chronicIllnessBonus\\":1.84,\\"spouseBonus\\":3.06,\\"final\\":72.19000000000001},\\"submittedAt\\":\\"2026-05-25T08:34:28.319Z\\"}", "housingRoomNumber": "3", "housingBlockNumber": "3", "lecturerDepartment": "College of Informatics", "housingBuildingName": "errr"}, {"id": "cb823144-92b5-4fc2-b5db-cf6b9bc15d17", "score": 63.35, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-25T08:50:03.646Z", "lecturerName": "aaa", "rankPosition": 2, "applicationId": "0efeb00a-3070-48df-8428-249163206615", "housingUnitId": "5910907d-1e40-4382-9cd6-80ecd64e0170", "housingRoomType": "1-Bedroom", "applicationNotes": "{\\"fullName\\":\\"mr ashe\\",\\"staffId\\":\\"HERO\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0997278931\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"PROFESSOR\\",\\"educationalLevel\\":\\"PHD\\",\\"startDateAtUog\\":\\"2022-10-07\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"SINGLE_WITHOUT_CHILDREN\\",\\"spouseName\\":\\"\\",\\"spouseStaffId\\":\\"\\",\\"numberOfDependents\\":\\"1\\",\\"hasSpouseAtUog\\":false,\\"isFemale\\":false,\\"isDisabled\\":false,\\"hasChronicIllness\\":false,\\"score\\":{\\"educationalTitle\\":40,\\"educationalLevel\\":5,\\"serviceYears\\":8.35,\\"responsibility\\":10,\\"familyStatus\\":0,\\"baseTotal\\":63.35,\\"femaleBonus\\":0,\\"disabilityBonus\\":0,\\"chronicIllnessBonus\\":0,\\"spouseBonus\\":0,\\"final\\":63.35},\\"submittedAt\\":\\"2026-05-24T21:13:57.052Z\\"}", "housingRoomNumber": "4", "housingBlockNumber": "1", "lecturerDepartment": "College of Informatics", "housingBuildingName": "mar"}], "generatedAt": "2026-05-25T08:50:33.782Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 11:50:34.005394	PENDING	\N	\N	\N	\N
9677cbf0-8ae5-4326-b1dd-050a06c67f7a	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	7th test	OPEN	PRELIMINARY_SUBMITTED	2	{"round": {"id": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "name": "7th test", "endsAt": "2026-08-24T10:38:00.000Z", "status": "OPEN", "startsAt": "2026-05-16T11:35:00.000Z", "committeeRankingStatus": "PRELIMINARY_SUBMITTED"}, "summary": {"published": 0, "preliminary": 2, "totalAllocations": 2}, "allocations": [{"id": "449f2f30-ac07-4708-a282-3c3ff2cc4b3b", "score": 72.19000000000001, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-25T10:55:30.777Z", "lecturerName": "ashuvictor", "rankPosition": 1, "applicationId": "6725be3b-e6ea-4103-b402-fb2dc11a8081", "housingUnitId": "8039570d-5595-4060-98c6-1a5a71b6bbe9", "housingRoomType": "2-Bedroom", "applicationNotes": "{\\"fullName\\":\\"ashuvictor\\",\\"staffId\\":\\"WERTYU456\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0986543248\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"ASSOCIATE_PROFESSOR\\",\\"educationalLevel\\":\\"MSC\\",\\"startDateAtUog\\":\\"2025-11-06\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"MARRIED_WITH_CHILDREN\\",\\"spouseName\\":\\"may\\",\\"spouseStaffId\\":\\"no\\",\\"numberOfDependents\\":\\"2\\",\\"hasSpouseAtUog\\":true,\\"isFemale\\":true,\\"isDisabled\\":true,\\"hasChronicIllness\\":true,\\"score\\":{\\"educationalTitle\\":37,\\"educationalLevel\\":3,\\"serviceYears\\":1.17,\\"responsibility\\":10,\\"familyStatus\\":10,\\"baseTotal\\":61.17,\\"femaleBonus\\":3.06,\\"disabilityBonus\\":3.06,\\"chronicIllnessBonus\\":1.84,\\"spouseBonus\\":3.06,\\"final\\":72.19000000000001},\\"submittedAt\\":\\"2026-05-25T10:41:30.572Z\\"}", "housingRoomNumber": "3", "housingBlockNumber": "3", "lecturerDepartment": "College of Informatics", "housingBuildingName": "errr"}, {"id": "c2da9894-9d84-45c1-b0d4-3edc4d72636d", "score": 63.35, "status": "PRELIMINARY", "roundId": "28f7bd58-1eb3-474d-8dc9-99c5b7c89666", "allocatedAt": "2026-05-25T10:55:30.777Z", "lecturerName": "aaa", "rankPosition": 2, "applicationId": "0efeb00a-3070-48df-8428-249163206615", "housingUnitId": "5910907d-1e40-4382-9cd6-80ecd64e0170", "housingRoomType": "1-Bedroom", "applicationNotes": "{\\"fullName\\":\\"mr ashe\\",\\"staffId\\":\\"HERO\\",\\"email\\":\\"ashenafih212121@gmail.com\\",\\"phoneNumber\\":\\"0997278931\\",\\"college\\":\\"College of Informatics\\",\\"department\\":\\"cs\\",\\"educationalTitle\\":\\"PROFESSOR\\",\\"educationalLevel\\":\\"PHD\\",\\"startDateAtUog\\":\\"2022-10-07\\",\\"otherServiceInstitution\\":\\"\\",\\"otherServiceDuration\\":\\"\\",\\"researchInstitution\\":\\"\\",\\"researchDuration\\":\\"\\",\\"teachingInstitution\\":\\"\\",\\"teachingDuration\\":\\"\\",\\"responsibility\\":\\"DEAN\\",\\"familyStatus\\":\\"SINGLE_WITHOUT_CHILDREN\\",\\"spouseName\\":\\"\\",\\"spouseStaffId\\":\\"\\",\\"numberOfDependents\\":\\"1\\",\\"hasSpouseAtUog\\":false,\\"isFemale\\":false,\\"isDisabled\\":false,\\"hasChronicIllness\\":false,\\"score\\":{\\"educationalTitle\\":40,\\"educationalLevel\\":5,\\"serviceYears\\":8.35,\\"responsibility\\":10,\\"familyStatus\\":0,\\"baseTotal\\":63.35,\\"femaleBonus\\":0,\\"disabilityBonus\\":0,\\"chronicIllnessBonus\\":0,\\"spouseBonus\\":0,\\"final\\":63.35},\\"submittedAt\\":\\"2026-05-24T21:13:57.052Z\\"}", "housingRoomNumber": "4", "housingBlockNumber": "1", "lecturerDepartment": "College of Informatics", "housingBuildingName": "mar"}], "generatedAt": "2026-05-25T11:01:38.264Z"}	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 14:01:39.206892	PENDING	\N	\N	\N	\N
\.


--
-- TOC entry 5236 (class 0 OID 17727)
-- Dependencies: 230
-- Data for Name: allocation_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allocation_results (id, round_id, application_id, housing_unit_id, allocated_by_user_id, status, allocated_at) FROM stdin;
449f2f30-ac07-4708-a282-3c3ff2cc4b3b	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	6725be3b-e6ea-4103-b402-fb2dc11a8081	8039570d-5595-4060-98c6-1a5a71b6bbe9	afd12936-078a-47fc-b575-4dc80503e10e	PRELIMINARY	2026-05-25 13:55:30.777935+03
c2da9894-9d84-45c1-b0d4-3edc4d72636d	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	0efeb00a-3070-48df-8428-249163206615	5910907d-1e40-4382-9cd6-80ecd64e0170	afd12936-078a-47fc-b575-4dc80503e10e	PRELIMINARY	2026-05-25 13:55:30.777935+03
\.


--
-- TOC entry 5243 (class 0 OID 17892)
-- Dependencies: 237
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, title, content, type, target_roles, is_active, starts_at, ends_at, created_by, created_at, updated_at) FROM stdin;
b5098fb8-42e1-4c8a-90b9-13bd4c447b65	dcfvghxd	ctrfytu	LECTURERS	{"LECTURER"}	t	2025-12-22 03:00:00+03	2026-05-07 03:00:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 23:29:22.07974+03	2026-05-25 23:29:22.07974+03
284a0a8c-a69f-4c80-9f2d-87a796c9c031	dfghjk	dfghjkl	LECTURERS	{"LECTURER"}	t	2026-02-04 03:00:00+03	2026-07-25 03:00:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 23:35:17.056589+03	2026-05-25 23:35:17.056589+03
\.


--
-- TOC entry 5232 (class 0 OID 17579)
-- Dependencies: 226
-- Data for Name: application_rounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.application_rounds (id, name, description, status, starts_at, ends_at, created_by_user_id, created_at, updated_at, committee_ranking_status, committee_preliminary_submitted_at, committee_final_submitted_at) FROM stdin;
d8ec5453-7973-476c-95b6-eb36af52bab7	mwku	ashu	OPEN	2025-10-09 01:52:00+03	2025-11-25 11:51:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-25 11:48:29.567569+03	2026-05-25 11:49:17.587+03	DRAFT	\N	\N
28f7bd58-1eb3-474d-8dc9-99c5b7c89666	7th test	pleas  see detail this is the 7th test round	OPEN	2026-05-16 14:35:00+03	2026-08-24 13:38:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-24 23:36:31.446559+03	2026-05-25 13:49:13.161+03	PRELIMINARY_SUBMITTED	2026-05-25 13:49:13.161+03	\N
9896cc12-16c9-4ef8-afe2-eac0cea68055	ashu	hjk	OPEN	2025-10-15 17:08:00+03	2026-05-15 13:10:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-15 13:08:11.607343+03	2026-05-15 13:08:11.607343+03	DRAFT	\N	\N
23d76ba3-6402-4ac6-91b7-c10a22d7e274	ashu first	hjkl	OPEN	2025-10-23 13:10:00+03	2026-05-01 13:07:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-15 13:07:44.541843+03	2026-05-24 20:38:35.038+03	PRELIMINARY_SUBMITTED	2026-05-24 20:38:35.038+03	\N
4846ea9c-dad1-4407-8bbf-24e00c12836c	ashu for defense day	the last tets	OPEN	2025-06-20 01:19:00+03	2026-02-26 11:20:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-20 09:20:26.041008+03	2026-05-20 09:20:26.041008+03	DRAFT	\N	\N
ce8dac37-e727-4e6b-929e-403cabf62189	no one	this is just test round	OPEN	2026-03-18 21:09:00+03	2026-08-18 09:11:00+03	afd12936-078a-47fc-b575-4dc80503e10e	2026-05-18 09:08:27.211713+03	2026-05-22 22:39:42.283+03	PRELIMINARY_SUBMITTED	2026-05-22 22:39:42.283+03	\N
\.


--
-- TOC entry 5233 (class 0 OID 17590)
-- Dependencies: 227
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.applications (id, user_id, round_id, preferred_housing_unit_id, score_snapshot_id, status, submitted_at, reviewed_at, notes, created_at, updated_at, reviewed_by_user_id, compliance_issue, compliance_notes, final_score) FROM stdin;
6725be3b-e6ea-4103-b402-fb2dc11a8081	980d3af8-eb07-4b30-8a33-3cca1a933d19	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	\N	dc67e28d-ad4c-405b-bce2-07e4480c1156	UNDER_REVIEW	2026-05-25 13:41:30.835+03	2026-05-25 13:49:00.793+03	{"fullName":"ashuvictor","staffId":"WERTYU456","email":"ashenafih212121@gmail.com","phoneNumber":"0986543248","college":"College of Informatics","department":"cs","educationalTitle":"ASSOCIATE_PROFESSOR","educationalLevel":"MSC","startDateAtUog":"2025-11-06","otherServiceInstitution":"","otherServiceDuration":"","researchInstitution":"","researchDuration":"","teachingInstitution":"","teachingDuration":"","responsibility":"DEAN","familyStatus":"MARRIED_WITH_CHILDREN","spouseName":"may","spouseStaffId":"no","numberOfDependents":"2","hasSpouseAtUog":true,"isFemale":true,"isDisabled":true,"hasChronicIllness":true,"score":{"educationalTitle":37,"educationalLevel":3,"serviceYears":1.17,"responsibility":10,"familyStatus":10,"baseTotal":61.17,"femaleBonus":3.06,"disabilityBonus":3.06,"chronicIllnessBonus":1.84,"spouseBonus":3.06,"final":72.19000000000001},"submittedAt":"2026-05-25T10:41:30.572Z"}	2026-05-24 23:57:49.141229+03	2026-05-25 13:49:00.793+03	0bdfda9b-4b29-4d8a-a879-635b9a5974db	f	\N	\N
0efeb00a-3070-48df-8428-249163206615	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	\N	ff61ae7b-f8cb-4614-9df3-5d95e2510131	UNDER_REVIEW	2026-05-25 00:13:57.089+03	2026-05-25 00:21:27.624+03	{"fullName":"mr ashe","staffId":"HERO","email":"ashenafih212121@gmail.com","phoneNumber":"0997278931","college":"College of Informatics","department":"cs","educationalTitle":"PROFESSOR","educationalLevel":"PHD","startDateAtUog":"2022-10-07","otherServiceInstitution":"","otherServiceDuration":"","researchInstitution":"","researchDuration":"","teachingInstitution":"","teachingDuration":"","responsibility":"DEAN","familyStatus":"SINGLE_WITHOUT_CHILDREN","spouseName":"","spouseStaffId":"","numberOfDependents":"1","hasSpouseAtUog":false,"isFemale":false,"isDisabled":false,"hasChronicIllness":false,"score":{"educationalTitle":40,"educationalLevel":5,"serviceYears":8.35,"responsibility":10,"familyStatus":0,"baseTotal":63.35,"femaleBonus":0,"disabilityBonus":0,"chronicIllnessBonus":0,"spouseBonus":0,"final":63.35},"submittedAt":"2026-05-24T21:13:57.052Z"}	2026-05-25 00:13:48.195447+03	2026-05-25 00:21:27.624+03	0bdfda9b-4b29-4d8a-a879-635b9a5974db	f	\N	\N
\.


--
-- TOC entry 5241 (class 0 OID 17856)
-- Dependencies: 235
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, action, affected_record, details, ip_address, user_agent, "timestamp") FROM stdin;
\.


--
-- TOC entry 5240 (class 0 OID 17839)
-- Dependencies: 234
-- Data for Name: backup_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_config (id, key, value, description, updated_at, updated_by) FROM stdin;
63a5a2d8-279a-4365-9815-b61bdf71d2b9	backup_directory	./backups	Directory to store backup files	2026-04-28 10:19:25.212499+03	\N
24ccc59a-d686-4fce-af6f-d9464dfcea36	max_backup_size	1073741824	Maximum backup file size in bytes (1GB)	2026-04-28 10:19:25.212499+03	\N
5f60e89b-1ec5-4197-bd84-527f1a414e4e	compression_enabled	true	Enable backup compression	2026-04-28 10:19:25.212499+03	\N
080a6264-036d-4b77-bad2-7d01719f4b66	auto_cleanup_days	90	Days to keep old backups before cleanup	2026-04-28 10:19:25.212499+03	\N
\.


--
-- TOC entry 5246 (class 0 OID 17959)
-- Dependencies: 240
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_logs (id, backup_id, level, message, details, "timestamp") FROM stdin;
04c35341-16e0-47db-9f9f-e2a6e7e459c3	a3c609a3-15bf-4a68-8886-5f72c780aaa1	INFO	Backup started	{"type":"full"}	2026-05-26 00:16:55.649045+03
130eb7e9-c4a0-4337-9813-1a0405eee8f2	a3c609a3-15bf-4a68-8886-5f72c780aaa1	INFO	Executing pg_dump	{"command":"pg_dump --host=localhost --port=5432 --username=postgres --dbname=HAS --format=plain --no-owner --no-privileges --verbose > \\"C:\\\\Users\\\\j\\\\Desktop\\\\HousingAllocationSystem\\\\server\\\\backups\\\\housing_portal_full_backup_2026-05-25T21-16-55-583Z.sql\\""}	2026-05-26 00:16:55.665123+03
\.


--
-- TOC entry 5239 (class 0 OID 17820)
-- Dependencies: 233
-- Data for Name: backup_schedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_schedule (id, name, type, frequency, tables, enabled, retention_days, last_run_at, next_run_at, created_at, updated_at, created_by) FROM stdin;
\.


--
-- TOC entry 5235 (class 0 OID 17697)
-- Dependencies: 229
-- Data for Name: committee_rank_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.committee_rank_entries (id, round_id, application_id, rank_position, updated_by_user_id) FROM stdin;
d7735b57-cf50-43c2-b502-a204a8dcbb98	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	6725be3b-e6ea-4103-b402-fb2dc11a8081	1	0bdfda9b-4b29-4d8a-a879-635b9a5974db
6c21ee7b-84dc-44d2-a666-164bd0a5d094	28f7bd58-1eb3-474d-8dc9-99c5b7c89666	0efeb00a-3070-48df-8428-249163206615	2	0bdfda9b-4b29-4d8a-a879-635b9a5974db
\.


--
-- TOC entry 5237 (class 0 OID 17767)
-- Dependencies: 231
-- Data for Name: complaint_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.complaint_messages (id, thread_id, sender_user_id, message, created_at) FROM stdin;
3e800100-56f9-4048-bd43-0bb5812be98b	3bfd3e2e-025f-4366-8d14-56a7f9883acc	980d3af8-eb07-4b30-8a33-3cca1a933d19	wesrtfyguhnjhvcxzsexdrcftvghbjn	2026-05-25 00:03:02.686615+03
8b2ef092-dd0c-46e3-b467-cce904e38b7b	3bfd3e2e-025f-4366-8d14-56a7f9883acc	980d3af8-eb07-4b30-8a33-3cca1a933d19	see this detail	2026-05-25 00:03:11.097685+03
86ef3ccb-ca09-4dea-aaaf-02ffd1979c2e	3bfd3e2e-025f-4366-8d14-56a7f9883acc	0bdfda9b-4b29-4d8a-a879-635b9a5974db	ook	2026-05-25 01:00:24.647391+03
270e635e-8b20-4ed9-8512-8b7a0b55173c	69d3bc47-9d4f-417d-943a-6b853c9aef98	980d3af8-eb07-4b30-8a33-3cca1a933d19	vgv	2026-05-25 11:39:10.181889+03
73b49c3a-c046-4c67-b223-3f25404fef6b	69d3bc47-9d4f-417d-943a-6b853c9aef98	980d3af8-eb07-4b30-8a33-3cca1a933d19	fguhj	2026-05-25 11:39:30.516011+03
a03fad0e-a85c-48bd-92fb-04356753de56	69d3bc47-9d4f-417d-943a-6b853c9aef98	0bdfda9b-4b29-4d8a-a879-635b9a5974db	srdtyuiopofdzdxcfgvhb	2026-05-25 11:46:17.916838+03
e8c11ef6-8b70-4e5e-b3b5-e373694af51f	246cc791-12c1-453b-adee-c1c9deb81c2e	980d3af8-eb07-4b30-8a33-3cca1a933d19	adf	2026-05-25 13:44:39.591726+03
d0d8e63f-ae23-4450-8312-3f8cbe0830ce	246cc791-12c1-453b-adee-c1c9deb81c2e	0bdfda9b-4b29-4d8a-a879-635b9a5974db	rtyui	2026-05-25 13:51:04.847236+03
\.


--
-- TOC entry 5238 (class 0 OID 17776)
-- Dependencies: 232
-- Data for Name: complaint_threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.complaint_threads (id, lecturer_user_id, target_department, subject, status, created_at, updated_at) FROM stdin;
3bfd3e2e-025f-4366-8d14-56a7f9883acc	980d3af8-eb07-4b30-8a33-3cca1a933d19	College of Informatics	hii my brother	OPEN	2026-05-25 00:03:02.686615+03	2026-05-25 01:00:24.68+03
69d3bc47-9d4f-417d-943a-6b853c9aef98	980d3af8-eb07-4b30-8a33-3cca1a933d19	College of Informatics	ertyuio	OPEN	2026-05-25 11:39:10.181889+03	2026-05-25 11:46:17.92+03
246cc791-12c1-453b-adee-c1c9deb81c2e	980d3af8-eb07-4b30-8a33-3cca1a933d19	College of Informatics	erty	OPEN	2026-05-25 13:44:39.591726+03	2026-05-25 13:51:04.852+03
\.


--
-- TOC entry 5228 (class 0 OID 17487)
-- Dependencies: 222
-- Data for Name: housing_units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.housing_units (id, building_name, block_number, room_number, room_type, condition, status, location, created_at, updated_at) FROM stdin;
8978209f-1726-47e9-a57d-1d73ec61e41c	maraki	5	5	1-Bedroom	New	Available	nono	2026-05-22 21:47:58.011005+03	2026-05-25 13:55:30.745+03
5910907d-1e40-4382-9cd6-80ecd64e0170	mar	1	4	1-Bedroom	Good	Occupied	gonder	2026-05-25 00:25:53.725119+03	2026-05-25 13:55:30.796+03
8039570d-5595-4060-98c6-1a5a71b6bbe9	errr	3	3	2-Bedroom	New	Occupied	gonder	2026-05-25 00:26:21.414428+03	2026-05-25 13:55:30.796+03
\.


--
-- TOC entry 5234 (class 0 OID 17659)
-- Dependencies: 228
-- Data for Name: lecturer_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lecturer_documents (id, user_id, application_id, purpose, original_file_name, mime_type, size_bytes, storage_path, notes, status, uploaded_at) FROM stdin;
b55efc36-a431-4ad7-a669-dfd9b4108ca2	980d3af8-eb07-4b30-8a33-3cca1a933d19	6725be3b-e6ea-4103-b402-fb2dc11a8081	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779656269178-ic1ll4z0.png	Supporting document for housing application	UPLOADED	2026-05-24 23:57:49.199726+03
f5889aa0-b911-486b-ae3e-df10d6d21aba	980d3af8-eb07-4b30-8a33-3cca1a933d19	6725be3b-e6ea-4103-b402-fb2dc11a8081	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779656272020-vx1mt04a.png	Supporting document for housing application	UPLOADED	2026-05-24 23:57:52.039234+03
80b9cc71-6778-4ad9-bcff-585d57f6eed8	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	\N	OTHER	111download111.jpg	image/jpeg	7767	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1778333030100-3c4t2sl7.jpg	Supporting document for housing application	UPLOADED	2026-05-09 16:23:50.222131+03
7d712fcd-300b-47b3-b63d-df658433f6da	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	\N	OTHER	111download111.jpg	image/jpeg	7767	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1778333040820-mkv5obx6.jpg	Supporting document for housing application	UPLOADED	2026-05-09 16:24:00.849878+03
4b4ea563-7cd5-46a6-a517-b4b1e00f3a61	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779085298694-ciw49922.png	Supporting document for housing application	UPLOADED	2026-05-18 09:21:38.706098+03
3ab2cb8b-c1d9-4780-bbed-fc0bd6ece182	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779085033548-yjjw4am1.png	Supporting document for housing application	UPLOADED	2026-05-18 09:17:13.575332+03
6431fd7e-6157-491e-ba16-4b98f2e46810	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779085050940-8i86csec.png	Supporting document for housing application	UPLOADED	2026-05-18 09:17:30.95221+03
1d8f54c4-8605-4b1f-b725-44e13d4a7934	e8602b77-c5a1-4859-8f9e-8b486262c9b3	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779092981718-boa6d361.png	Supporting document for housing application	UPLOADED	2026-05-18 11:29:41.7487+03
b824f18c-b860-4225-8ce0-96a853773a64	e8602b77-c5a1-4859-8f9e-8b486262c9b3	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779092985599-tfulx6q6.png	Supporting document for housing application	UPLOADED	2026-05-18 11:29:45.615259+03
ebe02537-263a-49bd-9702-83959c4faabe	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779085085090-kxivbj66.png	Supporting document for housing application	UPLOADED	2026-05-18 09:18:05.109167+03
09910c85-4ce7-4bae-95cb-b377032c770e	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	\N	OTHER	ashu.png	image/png	539401	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779085091412-6g2yy1ub.png	Supporting document for housing application	UPLOADED	2026-05-18 09:18:11.424829+03
45c65c61-e955-4df1-b169-7d17edace36c	e8602b77-c5a1-4859-8f9e-8b486262c9b3	\N	OTHER	5798477111604481805.jpg	image/jpeg	21995	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779474414643-1le618pg.jpg	Supporting document for housing application	UPLOADED	2026-05-22 21:26:54.661275+03
c74e77d8-c36e-4240-ac35-8c110f370eb0	e8602b77-c5a1-4859-8f9e-8b486262c9b3	\N	OTHER	5798477111604481805.jpg	image/jpeg	21995	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779474418881-uey53h55.jpg	Supporting document for housing application	UPLOADED	2026-05-22 21:26:58.897341+03
ffd40e84-a63b-4de9-9368-913fa49bc2e5	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	\N	OTHER	5798477111604481805.jpg	image/jpeg	21995	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779474321837-jejx881p.jpg	Supporting document for housing application	UPLOADED	2026-05-22 21:25:21.854649+03
dd0af12a-d043-4c05-bf66-ab0449ae4d5c	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	\N	OTHER	5798477111604481805.jpg	image/jpeg	21995	C:\\Users\\j\\Desktop\\HousingAllocationSystem\\server\\uploads\\lecturer-documents\\1779474327315-7oyw4402.jpg	Supporting document for housing application	UPLOADED	2026-05-22 21:25:27.32708+03
\.


--
-- TOC entry 5229 (class 0 OID 17499)
-- Dependencies: 223
-- Data for Name: lecturer_scoring_criteria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lecturer_scoring_criteria (id, user_id, educational_title, educational_level, service_years, responsibility, family_status, female_bonus_eligible, disability_bonus_eligible, hiv_illness_bonus_eligible, spouse_bonus_eligible, created_at, updated_at) FROM stdin;
222d67a7-0356-4784-a653-b372a4cd7dcb	64328bc6-b586-4705-92fb-838719d8217a	ASSISTANT_PROFESSOR	MSC	7	DEAN	MARRIED_WITH_CHILDREN	f	f	f	f	2026-05-07 00:46:08.467154+03	2026-05-07 00:46:08.465+03
d98286cc-97a4-4a73-8db2-d436c9942d6a	0075fbb5-f75a-4913-8ae8-9da29c25195a	LECTURER	PHD	9	DEPARTMENT_HEAD	MARRIED_WITHOUT_CHILDREN	f	t	f	f	2026-05-07 00:54:38.396482+03	2026-05-07 00:54:38.393+03
a07f4686-05ec-4765-88b2-074a3310e350	4c3f1078-304c-463d-8556-93c57d032aea	ASSISTANT_LECTURER	MSC	5	DEPARTMENT_HEAD	MARRIED_WITH_CHILDREN	f	t	f	t	2026-05-07 00:58:32.358757+03	2026-05-07 00:58:32.357+03
c7752be7-3ed4-43fa-a02a-1095252696a1	45ee7a33-615b-4a72-998e-5a28202bea50	LECTURER	BSC	5	UNIT_HEAD	MARRIED_WITH_CHILDREN	f	f	t	t	2026-05-07 01:01:52.35718+03	2026-05-07 01:01:52.355+03
a18e214e-1810-4bcc-b46f-da32e5e3f273	553d3e0f-3be4-44de-bcc6-b045ada0d595	ASSOCIATE_PROFESSOR	PHD	5	DEPARTMENT_HEAD	MARRIED_WITHOUT_CHILDREN	f	t	f	f	2026-05-07 01:05:04.361783+03	2026-05-07 01:05:04.359+03
51f8a67d-6f97-476f-bce6-d0e4174a9e0f	ecef26d0-b631-489a-aaa7-2ea96623a388	ASSISTANT_LECTURER	MSC	7	DEPARTMENT_HEAD	MARRIED_WITHOUT_CHILDREN	f	f	t	f	2026-05-07 01:08:12.498789+03	2026-05-07 01:08:12.495+03
36636872-a9b6-4e5e-8beb-b4a8b8df9c0a	22a5fd30-426f-48bd-945c-0e9199cea345	ASSISTANT_PROFESSOR	MSC	8	PROGRAM_COORDINATOR	MARRIED_WITH_CHILDREN	f	f	t	t	2026-05-07 01:11:20.559865+03	2026-05-07 01:11:20.557+03
9b9dc249-9b91-47bb-b2c1-00e7d301b622	443bbe6a-0a3c-460a-9842-22ac6d67a191	ASSOCIATE_PROFESSOR	PHD	9	VICE_DEAN	MARRIED_WITH_CHILDREN	f	t	f	t	2026-05-07 01:15:11.944527+03	2026-05-07 01:15:11.943+03
ae09a5d6-e4c2-43a2-88e8-81f948e5b43c	5b3dc64d-8c42-4fd4-bdc2-e6a344c6326e	ASSISTANT_PROFESSOR	MSC	8	UNIT_HEAD	MARRIED_WITHOUT_CHILDREN	f	t	f	f	2026-05-07 01:18:23.338727+03	2026-05-07 01:18:23.337+03
8eea05c5-6d17-4829-8036-b6e5007f6f8f	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	ASSOCIATE_PROFESSOR	MSC	0	VICE_DEAN	MARRIED_WITH_CHILDREN	f	f	t	t	2026-05-07 01:20:59.717934+03	2026-05-22 21:25:23.731+03
02e4c27f-281e-4fde-95c3-5cf223cf27ab	e8602b77-c5a1-4859-8f9e-8b486262c9b3	GRADUATE_ASSISTANT_I	PHD	0	DEAN	SINGLE_WITHOUT_CHILDREN	t	t	t	f	2026-05-18 11:29:43.239842+03	2026-05-22 21:26:55.894+03
0a1fa172-3975-47d3-98bf-956a5f6235b8	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	PROFESSOR	PHD	3	DEAN	SINGLE_WITHOUT_CHILDREN	f	f	f	f	2026-05-09 16:23:52.822705+03	2026-05-25 00:13:49.839+03
accf5002-7204-4377-a08c-d3eb3ec84c9e	efd4d8ac-9333-4804-ba2a-b580bd323d33	ASSISTANT_PROFESSOR	PHD	0	DEPARTMENT_HEAD	MARRIED_WITH_CHILDREN	t	f	f	f	2026-04-30 23:49:07.031718+03	2026-04-30 23:49:07.025+03
86c6fcfd-e708-4f25-ad31-6655092626de	080d618e-e9e6-431e-aeaf-2d6f033c25f5	PROFESSOR	MSC	0	DEAN	SINGLE_WITHOUT_CHILDREN	t	t	t	f	2026-05-04 21:53:15.468385+03	2026-05-04 21:53:22.804+03
46ddcd95-4a65-4743-b1bf-9603fdebec55	980d3af8-eb07-4b30-8a33-3cca1a933d19	ASSOCIATE_PROFESSOR	MSC	0	DEAN	MARRIED_WITH_CHILDREN	t	t	t	t	2026-05-24 23:57:48.013434+03	2026-05-25 13:40:43.068+03
cc8cf5bb-2579-4ffc-b895-ce1f1832339c	58778945-045e-4b62-bf71-eeef2eed0cfa	LECTURER	MSC	25	DEPARTMENT_HEAD	SINGLE_WITHOUT_CHILDREN	f	f	f	f	2026-05-03 15:20:54.27257+03	2026-05-03 15:42:04.606+03
\.


--
-- TOC entry 5226 (class 0 OID 17431)
-- Dependencies: 220
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (id, user_id, code, expires_at, attempts, resend_count) FROM stdin;
5f47309e-1986-4b6f-b0f7-7a0d425230bf	c3b60fe9-85cf-45e3-a01a-97c4f2e39da2	Q741F6	2026-05-07 01:26:14.542+03	0	0
3acf2d82-2be4-4914-ad7f-4bac47262505	38957b99-b634-4143-bf7f-4928a35fd06f	L89O62	2026-05-25 23:31:55.544+03	0	0
5e398c3f-6e75-4065-8b0e-62d069c3a068	afd12936-078a-47fc-b575-4dc80503e10e	Y563Y0	2026-04-23 16:32:50.856+03	0	0
5ccbe174-3c54-462e-a701-b6032dfdc3be	320ec13d-1e77-4520-b981-2e009671e1f1	S8V853	2026-04-30 21:16:01+03	0	0
8c0140b4-c873-4559-871f-2c9a78a1b75f	0b39b8e3-4c68-453e-b5c3-768bf5d35df6	IP0436	2026-04-30 22:51:57.501+03	0	0
933f885d-f0a2-45a3-9dc5-1a154635ddcb	72c6ca56-286a-48ae-b986-e845919f0bd8	36FR09	2026-05-18 09:33:42.572+03	0	0
904d15f1-cb0b-4175-95d3-8dd1323a3beb	447dad85-7f56-488f-b3e2-02efe96d4893	WM6517	2026-05-18 09:34:53.143+03	0	0
55ff04a3-959d-4659-995f-e300b2933f8d	4ea19621-4295-4a3f-b522-4aef718ea07d	A0A129	2026-05-20 14:04:40.435+03	0	0
980f4de4-87c4-45ec-9498-41e5a0dcf560	080d618e-e9e6-431e-aeaf-2d6f033c25f5	TP8044	2026-04-30 08:58:35.008+03	0	0
955d7889-a5cc-4d05-b3da-2c8855563050	e8602b77-c5a1-4859-8f9e-8b486262c9b3	F3H234	2026-05-24 23:58:14.897+03	0	0
75cbc70f-f8a2-4b65-a1aa-96999a79175b	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	90BM41	2026-05-25 00:16:34.51+03	0	0
a5d3ae86-0d59-4d04-9bf8-76205eb3a1e4	0bdfda9b-4b29-4d8a-a879-635b9a5974db	9223OB	2026-05-25 09:20:38.62+03	0	0
\.


--
-- TOC entry 5230 (class 0 OID 17514)
-- Dependencies: 224
-- Data for Name: score_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.score_snapshots (id, user_id, scoring_policy_id, breakdown, base_total, bonus_total, final_score, created_at) FROM stdin;
f457af27-d4d5-486d-80cb-f202fc476509	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 34, "criteria": "Educational Title", "yourPoints": 85, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 48.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 56.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	48.9	8	56.9	2026-05-22 21:25:23.806449+03
0788cd4d-b2e1-4aed-8ed5-b1585440628d	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 37, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 60.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.81, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.01, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 64.99000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	60.17	4.82	64.99000000000001	2026-05-22 21:25:27.305045+03
aaa4436a-1858-480b-a79a-e4985945fb55	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 37, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 60.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.81, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.01, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 64.99000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	60.17	4.82	64.99000000000001	2026-05-22 21:25:28.388183+03
90968f49-4a56-4d30-a3a2-3f1fc9c88db6	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	18	72.9	2026-05-24 23:57:48.022487+03
aa72a7b0-fa8b-41b3-bfd6-be43b53331f0	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 63.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.16, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.16, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.9, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.16, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 74.55, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	63.17	11.38	74.55	2026-05-24 23:57:49.140016+03
13b1f504-7f6d-482a-9188-cebdac015726	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 44.8, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 57.8, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	44.8	13	57.8	2026-05-22 21:26:55.981877+03
77cd78a5-9d03-4f9d-ba70-f0b9f951d37b	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 15, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.94, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 31.94, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 1.6, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.6, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0.96, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 36.1, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	31.94	4.16	36.1	2026-05-22 21:26:58.86687+03
38d2e381-1102-4013-b52c-db337a3e5379	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 15, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.94, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 31.94, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 1.6, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.6, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0.96, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 36.1, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	31.94	4.16	36.1	2026-05-22 21:27:00.713948+03
f7fc2fa4-7b4e-48c9-8e79-713a68bf48df	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	18	72.9	2026-05-24 23:57:50.687306+03
0eb1904a-38b4-44d7-8a77-a33ff54e1079	efd4d8ac-9333-4804-ba2a-b580bd323d33	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 44.8, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 49.8, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	44.8	5	49.8	2026-04-30 23:49:07.055149+03
ea73eab0-e000-4975-9e88-1e0672a3fc1e	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 63.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.16, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.16, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.9, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.16, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 74.55, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	63.17	11.38	74.55	2026-05-24 23:57:52.006528+03
856613e7-32dd-45ba-a913-6ec62b213acf	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 63.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.16, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.16, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.9, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.16, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 74.55, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	63.17	11.38	74.55	2026-05-24 23:57:53.806633+03
eaa17cb1-0be6-49f1-b4f7-7f77d044c247	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	18	72.9	2026-05-24 23:58:08.087366+03
76fa53d7-02fc-4fed-b9db-fd41020191ee	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	18	72.9	2026-05-24 23:58:23.781245+03
f3e9eb16-6935-43a3-9137-e1b743082839	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 64.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.21, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.21, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.93, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.21, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 75.72999999999999, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	64.17	11.559999999999999	75.72999999999999	2026-05-24 23:58:26.274697+03
3101cfe5-18aa-4ba1-9be4-e18ab35ad9e4	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 2.63, "criteria": "Service Years", "yourPoints": 7.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 58.63, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 58.63, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	58.63	0	58.63	2026-05-25 00:13:50.076795+03
bf1b5da9-f84d-4fdf-bd97-8cab163c6af7	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 8.35, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 63.35, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Chronic Illness Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 63.35, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	63.35	0	63.35	2026-05-25 00:13:54.710831+03
ff61ae7b-f8cb-4614-9df3-5d95e2510131	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 8.35, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 63.35, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Chronic Illness Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 63.35, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	63.35	0	63.35	2026-05-25 00:13:57.070074+03
cb5a76da-aa72-41d3-abdf-ec4f640d0371	58778945-045e-4b62-bf71-eeef2eed0cfa	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 24.8, "criteria": "Educational Title", "yourPoints": 62, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 21.88, "criteria": "Service Years", "yourPoints": 62.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 61.58, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 61.58, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	61.58	0	61.58	2026-05-03 15:20:54.305192+03
1288168d-1d43-4fdb-a04f-8ac57a89a343	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	18	72.9	2026-05-25 11:33:26.475604+03
46b07094-4c51-41dc-aee3-445bea7fa4a7	58778945-045e-4b62-bf71-eeef2eed0cfa	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 24.8, "criteria": "Educational Title", "yourPoints": 62, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 21.88, "criteria": "Service Years", "yourPoints": 62.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 61.58, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 61.58, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	61.58	0	61.58	2026-05-03 15:42:04.763724+03
7afe2807-9285-42eb-9018-4aa2251e944d	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 64.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.21, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.21, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.93, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.21, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 75.72999999999999, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	64.17	11.559999999999999	75.72999999999999	2026-05-25 11:33:29.227818+03
d7991960-99e8-417e-b05f-93236970c852	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 64.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.21, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.21, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.93, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.21, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 75.72999999999999, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	64.17	11.559999999999999	75.72999999999999	2026-05-25 11:33:43.339099+03
47d5b8c4-6b37-4b50-bb49-ad2a53669237	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 34, "criteria": "Educational Title", "yourPoints": 85, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 48.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 66.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	48.9	18	66.9	2026-05-25 11:33:44.072361+03
704575b3-88cf-48a7-abe2-88e817381b9f	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 34, "criteria": "Educational Title", "yourPoints": 85, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 48.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 66.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	48.9	18	66.9	2026-05-25 11:34:25.236139+03
380cdc4e-c0c0-4410-870c-c76fa928e7da	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 37, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 61.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.06, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.06, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.84, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.06, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.19000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	61.17	11.02	72.19000000000001	2026-05-25 11:34:27.138755+03
e3b5971c-26a0-4569-a955-512a15c97198	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 37, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 61.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.06, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.06, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.84, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.06, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.19000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	61.17	11.02	72.19000000000001	2026-05-25 11:34:28.334349+03
e2f3d28f-33cf-4d55-82d5-07ea7f94c395	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 34, "criteria": "Educational Title", "yourPoints": 85, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 48.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 66.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	48.9	18	66.9	2026-05-25 13:40:43.203703+03
dc67e28d-ad4c-405b-bce2-07e4480c1156	980d3af8-eb07-4b30-8a33-3cca1a933d19	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 37, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.17, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 61.17, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.06, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.06, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.84, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.06, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.19000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	61.17	11.02	72.19000000000001	2026-05-25 13:41:30.783181+03
9dd90daa-3d48-4ca3-b53b-23847474bb58	080d618e-e9e6-431e-aeaf-2d6f033c25f5	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 67.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	13	67.9	2026-05-04 21:53:15.485889+03
717ae37b-d7c6-4389-b36f-d59f651c926d	080d618e-e9e6-431e-aeaf-2d6f033c25f5	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.9, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 67.9, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.9	13	67.9	2026-05-04 21:53:22.808083+03
14a6facb-6fdf-420e-992c-551f286b83a3	64328bc6-b586-4705-92fb-838719d8217a	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 6.13, "criteria": "Service Years", "yourPoints": 17.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 49.83, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 49.83, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	49.83	0	49.83	2026-05-07 00:46:08.48452+03
c55857ea-3f56-4ea7-a184-203311007ddc	0075fbb5-f75a-4913-8ae8-9da29c25195a	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 24.8, "criteria": "Educational Title", "yourPoints": 62, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 7.88, "criteria": "Service Years", "yourPoints": 22.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 48.68, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 53.68, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	48.68	5	53.68	2026-05-07 00:54:38.412546+03
3fabca82-1661-4ca1-809e-b090c957f1ff	4c3f1078-304c-463d-8556-93c57d032aea	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 4.38, "criteria": "Service Years", "yourPoints": 12.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 48.08, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 58.08, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	48.08	10	58.08	2026-05-07 00:58:32.477809+03
ecfc2df4-ad19-499c-b106-bd062374cea7	45ee7a33-615b-4a72-998e-5a28202bea50	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 24.8, "criteria": "Educational Title", "yourPoints": 62, "weightLabel": "40%"}, {"kind": "base", "score": 2.75, "criteria": "Educational Level", "yourPoints": 55, "weightLabel": "5%"}, {"kind": "base", "score": 4.38, "criteria": "Service Years", "yourPoints": 12.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 42.93, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 50.93, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	42.93	8	50.93	2026-05-07 01:01:52.363041+03
f850b2e1-a9af-4084-979a-d0ec8ca23747	553d3e0f-3be4-44de-bcc6-b045ada0d595	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 34, "criteria": "Educational Title", "yourPoints": 85, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 4.38, "criteria": "Service Years", "yourPoints": 12.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 54.38, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 59.38, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	54.38	5	59.38	2026-05-07 01:05:04.366897+03
128e2c4f-66d1-40a2-9232-1fd46288b4f4	ecef26d0-b631-489a-aaa7-2ea96623a388	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 6.13, "criteria": "Service Years", "yourPoints": 17.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 49.83, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 52.83, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	49.83	3	52.83	2026-05-07 01:08:12.504956+03
a6e44c31-fa01-4843-b1a6-83988bd29425	22a5fd30-426f-48bd-945c-0e9199cea345	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 7, "criteria": "Service Years", "yourPoints": 20, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 50.7, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Disability (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 58.7, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	50.7	8	58.7	2026-05-07 01:11:20.660635+03
430ea2cf-fb5f-4c0b-8c26-a6aa06ce4d1e	443bbe6a-0a3c-460a-9842-22ac6d67a191	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 34, "criteria": "Educational Title", "yourPoints": 85, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 7.88, "criteria": "Service Years", "yourPoints": 22.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 57.88, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 67.88, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	57.88	10	67.88	2026-05-07 01:15:11.950766+03
d7dd9fb6-c682-45d6-9935-254841984a6f	5b3dc64d-8c42-4fd4-bdc2-e6a344c6326e	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 28.8, "criteria": "Educational Title", "yourPoints": 72, "weightLabel": "40%"}, {"kind": "base", "score": 3.9, "criteria": "Educational Level", "yourPoints": 78, "weightLabel": "5%"}, {"kind": "base", "score": 7, "criteria": "Service Years", "yourPoints": 20, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 50.7, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 55.7, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	50.7	5	55.7	2026-05-07 01:18:23.490604+03
6086e586-52a4-40f5-972f-99be83bd48cd	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 7, "criteria": "Service Years", "yourPoints": 20, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 63, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 0, "criteria": "Female (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "HIV/Illness (+3%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 68, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	63	5	68	2026-05-07 01:20:59.721849+03
2cc7da6f-94ab-4424-9768-2f8d7dde647f	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 56, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 74, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56	18	74	2026-05-09 16:23:52.952038+03
43a88b24-4650-44be-91da-093e177f5fcc	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0.97, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 55.97, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 2.8, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 2.8, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.68, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 2.8, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 66.05, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	55.97	10.079999999999998	66.05	2026-05-09 16:24:00.792917+03
2760b283-092b-4869-944a-ac5e0b9615a8	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0.88, "criteria": "Service Years", "yourPoints": 2.5, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 56.88, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Spouse Bonus (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 74.88, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56.88	18	74.88	2026-05-18 09:18:06.664656+03
34acedd8-a72f-486e-aa53-4ccabcf7c1f4	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 3.69, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 68.69, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.43, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.43, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 2.06, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.43, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 81.04000000000002, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	68.69	12.35	81.04000000000002	2026-05-18 09:18:11.39637+03
2d3dff0c-197d-4d2c-8c20-470dbb969a2e	3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 3.69, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 68.69, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.43, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.43, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 2.06, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.43, "criteria": "Spouse Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "total", "score": 81.04000000000002, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	68.69	12.35	81.04000000000002	2026-05-18 09:18:13.001527+03
58b1372e-89f1-4e90-ab52-9beb6943ae36	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 56, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 69, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56	13	69	2026-05-18 09:21:40.17898+03
240d431a-19c2-49db-82cf-23c96f818fd4	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.36, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 56.36, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 2.82, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 2.82, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.69, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 63.69, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56.36	7.33	63.69	2026-05-18 09:21:51.243849+03
d5a72d40-a9db-46b8-b79c-db7370b4e398	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 56, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 69, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56	13	69	2026-05-18 09:21:52.262195+03
5be21aba-31c0-465f-aa77-41c3fcd710a3	0a2962b7-63f8-4e39-b354-c5dd9601a5a6	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 1.36, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 10, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 0, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 56.36, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 2.82, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 2.82, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.69, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 63.69, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56.36	7.33	63.69	2026-05-18 09:21:53.524835+03
43f53901-317e-42aa-a812-aeb02da9a339	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 56, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 69, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56	13	69	2026-05-18 11:29:43.403994+03
06efbbe9-0290-4089-8993-ef058839dc47	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 64, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.2, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.2, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.92, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.32000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	64	8.32	72.32000000000001	2026-05-18 11:29:45.574322+03
68b65404-d4f4-4283-8acd-a6b5d3fa5a61	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 0, "weightLabel": "35%"}, {"kind": "base", "score": 5.5, "criteria": "Responsibility", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "base", "score": 5.5, "criteria": "Family Status", "yourPoints": 55, "weightLabel": "10%"}, {"kind": "total", "score": 56, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 5, "criteria": "Female (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 5, "criteria": "Disability (+5%)", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3, "criteria": "HIV/Illness (+3%)", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus (+5%)", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 69, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	56	13	69	2026-05-18 11:30:30.577631+03
7557fcdc-9113-4e8d-aaf9-671c66daebb0	e8602b77-c5a1-4859-8f9e-8b486262c9b3	73644ae9-0d62-40a7-98bd-6f6177fee72b	[{"kind": "base", "score": 40, "criteria": "Educational Title", "yourPoints": 100, "weightLabel": "40%"}, {"kind": "base", "score": 5, "criteria": "Educational Level", "yourPoints": 100, "weightLabel": "5%"}, {"kind": "base", "score": 0, "criteria": "Service Years", "yourPoints": 100, "weightLabel": "35%"}, {"kind": "base", "score": 9, "criteria": "Responsibility", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "base", "score": 10, "criteria": "Family Status", "yourPoints": 100, "weightLabel": "10%"}, {"kind": "total", "score": 64, "criteria": "Base Total", "yourPoints": null, "weightLabel": "100%"}, {"kind": "bonus", "score": 3.2, "criteria": "Female Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 3.2, "criteria": "Disability Bonus", "yourPoints": 5, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 1.92, "criteria": "Chronic Illness Bonus", "yourPoints": 3, "weightLabel": "Bonus"}, {"kind": "bonus", "score": 0, "criteria": "Spouse Bonus", "yourPoints": null, "weightLabel": "Bonus"}, {"kind": "total", "score": 72.32000000000001, "criteria": "FINAL SCORE", "yourPoints": null, "weightLabel": ""}]	64	8.32	72.32000000000001	2026-05-18 11:30:32.596109+03
\.


--
-- TOC entry 5231 (class 0 OID 17523)
-- Dependencies: 225
-- Data for Name: scoring_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scoring_policies (id, name, description, version, effective_from, created_at) FROM stdin;
73644ae9-0d62-40a7-98bd-6f6177fee72b	Default Housing Scoring Policy	Standard policy for housing allocation scoring	1	2026-04-23 00:14:13.788728+03	2026-04-23 00:14:13.788728+03
\.


--
-- TOC entry 5244 (class 0 OID 17912)
-- Dependencies: 238
-- Data for Name: system_backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_backups (id, filename, type, size, status, description, created_by, created_at, completed_at, tables, file_path, checksum, restored_at, restored_by) FROM stdin;
a3c609a3-15bf-4a68-8886-5f72c780aaa1	housing_portal_full_backup_2026-05-25T21-16-55-583Z.sql	full	0	creating	Manual full backup	4ea19621-4295-4a3f-b522-4aef718ea07d	2026-05-26 00:16:55.599+03	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 5242 (class 0 OID 17874)
-- Dependencies: 236
-- Data for Name: system_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_config (id, key, value, description, is_public, updated_at, updated_by) FROM stdin;
5c752ab4-580a-4c47-b3ee-729f945b14f3	maintenance_mode	false	System maintenance mode status	f	2026-04-28 10:19:36.03827+03	\N
\.


--
-- TOC entry 5227 (class 0 OID 17438)
-- Dependencies: 221
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password, role, is_verified, created_at, department, is_active) FROM stdin;
0b39b8e3-4c68-453e-b5c3-768bf5d35df6	Tadie	tademan121@gmail.com	$2b$12$b9R8.zTWGprDcGhdwgX0q.GRmePjunNh7M0qPzJZ21tiiXSihRtmu	COMMITTEE	t	2026-04-30 22:26:08.553146+03	College of Agriculture and Environmental Sciences	t
cc8f3ba4-4ae5-4efe-96ea-9ff1a32f5db3	Meku	mequanintaye16@gmail.com	$2b$12$KCMhiXEzUGlOsu.q0HXw1.x/LyHlu0Rb8FwfL1b614WHi9QeqfyoK	COMMITTEE	t	2026-04-30 19:45:14.347471+03	College of Business and Economics	t
2954ef00-444f-4cdd-83ac-de04dfc2f968	ashu	liboyog908@gmail.com	\N	LECTURER	f	2026-05-01 00:23:41.922769+03	College of Informatics	t
2e4152fb-ea75-4d26-bb31-67bc995e82d8	hanan	hanny22162@gmail.com	$2b$12$qfJH.OZkSz/KtmApGagUEuerlhZj22Y2p7l1PJ4QyUl0flirbJ2EO	LECTURER	t	2026-05-01 00:24:41.628514+03	College of Informatics	t
afd12936-078a-47fc-b575-4dc80503e10e	ashe	ashenafih774@gmail.com	$2b$12$BtqKosH5QOMj2clt1hTKSuYA6m.m1gU7tsqtVQqDTIpAS//eBcSdi	OFFICER	t	2026-04-21 20:59:59.072286+03	\N	t
52e25e40-9758-4d9c-9d24-aeb6387e47cb	Mequanint	mekuayenew2018@gmail.com	$2b$12$Y2V6XZRW08IBpFu/Zt0X7eVQUpY1hx0q5jpVh.8mTKjxq1DHzomGO	COMMITTEE	t	2026-04-30 19:47:35.125842+03	College of Natural and Computational Sciences	t
5c261679-5f8e-471d-8d2e-ab65bc78f8df	Tadesse	tadesseb121@gmail.com	$2b$12$/wdiQgyiNTeCyPxlcUUcb.1i07twwOn5laxfI0BKHsScie3UfgfQ2	COMMITTEE	t	2026-04-30 22:28:13.030786+03	College of Social Sciences and Humanities	t
123cd261-41c7-416f-a5f1-9d2246fe560c	Maru A	maruabebe349@gmail.com	$2b$12$wjAtjuAeZwmVdFJUW2olTe91xgf6fI218O9S8JLY/V7kP9Kh7N2/G	COMMITTEE	t	2026-04-30 22:37:22.100982+03	College of Education	t
6383f011-751a-4fc6-87dc-166af2e03c41	Misganew	misganewayenew12@gmail.com	$2b$12$1dGZgsG65I/OkJuacRP1lu7NpaYldHjpceIB4zClR7Jr0YSNxmHW.	COMMITTEE	t	2026-04-30 20:10:32.17132+03	College of Veterinary Medicine and Animal Sciences	t
c3b60fe9-85cf-45e3-a01a-97c4f2e39da2	Habtu Alemu	habtuazanaw@gmail.com	$2b$12$wCyFzFi7XbSqkyj1BxT.5.I.KC5C7gXc8SCOcGI7VphdyDPfyzQJG	LECTURER	t	2026-05-06 22:21:03.80273+03	College of Informatics	t
080d618e-e9e6-431e-aeaf-2d6f033c25f5	anu	anwarayalew946@gmail.com	$2b$12$Ebh4K.N0BWEEgUh8GyVrQuxnkmkHoCH67CqKbJd1nMTyi2g1HTlP2	LECTURER	t	2026-04-23 22:04:41.518851+03	College of Informatics	t
15c27ad0-f169-43d9-bf04-29dc6fe2d924	Adane	adanedessie19@gmail.com	$2b$12$4voEWARFvxBe4I8qfJnMF.wOPvP8e4Rt/ddKD4LllU0vPbrUziDY.	COMMITTEE	t	2026-04-30 22:10:21.048741+03	Institute of Technology	t
320ec13d-1e77-4520-b981-2e009671e1f1	Getabalew Kemaw	getabalewkemaw@gmail.com	$2b$12$P60hv7J/Rdt70A3aZxDx1eKA5YlSIahV3PjQ3pqjSl3ktNmFxOyfS	ADMIN	t	2026-04-21 20:55:59.758468+03	\N	t
f6d65a52-0ce6-43b8-a306-a1ee4dc74a84	ashu	muzecasug430@gmail.com	$2b$12$AH0UH7skZVu4rcyNJ33XhO4cIeU7ExZTz8oEZzO0Tx7la0DQMfFl6	LECTURER	t	2026-05-01 00:21:09.276406+03	College of Informatics	t
61e58469-0d28-469f-8cfa-8a93d80e2faf	anu	anumuhammad225@gmail.com	$2b$12$8Ykxl6kqPUPIQnAvDa1GTOZZj0C0aA3H7PoIwInkxhPTCzhx5J6zG	LECTURER	t	2026-04-28 09:26:41.915857+03	College of Informatics	t
efd4d8ac-9333-4804-ba2a-b580bd323d33	hanna	hannabelete41@gmail.com	$2b$12$QXYGCl59P7u4P.9lLae5hOv.HK91htMAyNPCRgPO0Lx6g3F.xLOze	LECTURER	t	2026-04-30 23:13:02.569643+03	College of Informatics	t
0bdfda9b-4b29-4d8a-a879-635b9a5974db	ashu 	hashenafi577@gmail.com	$2b$12$LEjoIe4QntIR9eILU0cepOxUyyw05sEj9bYCkPNG68C.zKEpG.wJS	COMMITTEE	t	2026-04-21 21:01:28.931413+03	College of Informatics	t
72c6ca56-286a-48ae-b986-e845919f0bd8	yordanos	yordidagne349@gmail.com	\N	LECTURER	f	2026-05-01 00:21:33.308417+03	College of Informatics	t
a7431da8-b79b-4f2e-827e-c033d6425665	anwar	anwar.toyba1@gmail.com	$2b$12$yIka8KIF0GEKAInnvXrLYuHlbB5Ik9jGJiB1/i7h0bjNdZcLbuAkO	LECTURER	t	2026-04-30 08:49:15.614247+03	College of Informatics	t
a260f3b5-1761-406a-a7a3-8fa61ab86d7e	Misgie	misganewa12@gmail.com	$2b$12$V2X9KWEollldUG1kxfaSneRLYSEBqr8.nerrB6qXxaJNJq/LJklG6	COMMITTEE	t	2026-04-30 20:15:30.81897+03	School of Law	t
0a2962b7-63f8-4e39-b354-c5dd9601a5a6	Amanual aza	amanualazanaw21@gmail.com	$2b$12$BcRBTVTwBw4m5BPj/xrRiuVdtQSGREZcnCFmfHt688.iK3hvtpSqq	LECTURER	t	2026-05-06 21:23:13.628596+03	College of Informatics	t
4d1662a2-fa29-4c66-90a2-bfdf56efca0e	kalab	kaleabayenew519@gmail.com	$2b$12$h2bxvTsB.D.l3byM3NWK2eaBh02wQB5HSquh8nZhKQSWbCh7fKVlC	COMMITTEE	t	2026-04-30 20:21:10.008035+03	College of Education	t
50ccc357-5c7b-491c-aea3-61b7c0422bf0	Mequanint Ayenew	mekuayenew12@gmail.com	$2b$12$/GfW9eFlHeZKke2e0NmGGOPyJaCHl1fpJ2frKWxabfANZQ1qdYkUO	COMMITTEE	t	2026-04-30 19:38:56.476527+03	College of Medicine and Health Sciences	t
02260037-6f2e-4f58-a095-d087eaa005e7	Maru	maruab03@gmail.com	$2b$12$TfDgMG1pVSyaBupnc4F98.5n0y/3sDFIKT4LNtkr3cNVX.VXyfx6O	COMMITTEE	t	2026-04-30 22:17:25.75835+03	Institute of Biotechnology	t
e8602b77-c5a1-4859-8f9e-8b486262c9b3	Melat	mmelat772@gmail.com	$2b$12$hK.T9xah5RQLa0vQslEjp./qjOdRtnEB3cqL69TYC4mgMkT2j3EtO	LECTURER	t	2026-05-01 00:22:37.259513+03	College of Informatics	t
4ea19621-4295-4a3f-b522-4aef718ea07d	asffff dfg	ashenafiyfat@gmail.com	$2b$12$nTukWCure/aZLoOifgZAD..WN1bRwT9fZVvoEuIQcvVwMdw/xFeh6	ADMIN	t	2026-04-30 10:35:42.079248+03	ddd	t
c00847fa-4f09-478f-831d-e6a2f34682e7	beki	drhconxj@telegmail.com	$2b$12$.rBKVf81w6Du4amM9EEeyu.q8v8InaONNOy2fnF8oyecfgWUndRFa	LECTURER	t	2026-05-06 19:26:39.293117+03	College of Informatics	t
443bbe6a-0a3c-460a-9842-22ac6d67a191	Mikiyas Alebel	amanualazanaw14@gmail.com	$2b$12$eZ0N.SKiSGjoKLVp/F2ia.aHdpJPQxrdJnm0hg5mF6OdT81ggbwee	LECTURER	t	2026-05-06 22:38:48.879455+03	College of Informatics	t
447dad85-7f56-488f-b3e2-02efe96d4893	hermela	hermaab1221@gmail.com	\N	LECTURER	f	2026-05-01 00:27:36.523593+03	College of Informatics	t
4d7b891d-a85f-442b-be51-e2f0b6193cc2	mekdes	mekdesfekede0@gmail.com	\N	LECTURER	f	2026-05-01 00:28:31.536315+03	College of Informatics	t
9f1d1cbf-1700-474b-b0fe-0b78fd1ca4b8	hiwot	hiwottulu515@gmail.com	\N	LECTURER	f	2026-05-02 19:55:20.838167+03	College of Informatics	t
666be2e3-63c8-449f-a661-f617522a4ec8	haymanot	haymanotbelete012@gmail.com	\N	LECTURER	f	2026-05-02 19:56:00.120098+03	College of Informatics	t
ac6a1140-8dbc-4c41-af56-311fdc91e0ff	Abush	muluadd3181@gmail.com	\N	LECTURER	f	2026-05-03 14:41:32.636089+03	College of Informatics	t
5b45a741-d5c2-46dd-ba7a-63d55ae52c96	Meku	mulugeta5518@gmail.com	\N	LECTURER	f	2026-05-03 14:42:19.278806+03	College of Informatics	t
67b0fcfc-89e3-454b-82a9-52256506b34c	hanny	hann101626@gmail.com	$2b$12$0s7YYEqiA6GJv7aVrqjRFOs80x19lyVX5XohNXJ4UA7AIWLWU9GqK	LECTURER	t	2026-05-01 00:23:20.806085+03	College of Informatics	t
8448e580-6ee2-4cdd-ab61-95438a85ee9f	Mekie	yene3181@gmail.com	\N	LECTURER	f	2026-05-03 14:42:55.011858+03	College of Informatics	t
58778945-045e-4b62-bf71-eeef2eed0cfa	Gebre	gebereaschale@gmail.com	$2b$12$KiMvYpzXwFD6pYOLIvpLMOuYhvXBCCdvSdYe9/PvVxxeNQfgC7xyC	LECTURER	t	2026-05-03 14:55:29.941122+03	College of Informatics	t
0075fbb5-f75a-4913-8ae8-9da29c25195a	ALEX ALEBEL	amanualazanaw12@gmail.com	$2b$12$dJRIxkslHit3KIjptk/bOehYz7Kd36Dw2DFeMV2hkLHE7PTFHgEmS	LECTURER	t	2026-05-06 21:34:57.952407+03	College of Informatics	t
39a4d501-ac3f-4e96-8c9b-d26714076368	Belay Alebel	amanualaza955@gmail.com	\N	LECTURER	f	2026-05-06 23:05:26.03021+03	College of Informatics	t
5b3dc64d-8c42-4fd4-bdc2-e6a344c6326e	Biruk Kebede	amanaza955@gmail.com	$2b$12$JhUJTU5BNC1eyhQvm5X3e.pkV.wkUprNH8fRVW9wVV1TI8sTpNuLC	LECTURER	t	2026-05-06 23:07:39.559778+03	College of Informatics	t
553d3e0f-3be4-44de-bcc6-b045ada0d595	Amanual Tesfaye	amanuel3461@gmail.com	$2b$12$Py4n/rHSQ4mEpAY2fa.47uNEa.rUPEI4Rl8elFHIqbUXrBGgHK7dO	LECTURER	t	2026-05-06 23:11:30.435453+03	College of Informatics	t
45ee7a33-615b-4a72-998e-5a28202bea50	Getahun Nigusie	getahunnig21@gmail.com	$2b$12$mJ75m7S0eHUYg3bv1jROHOtL2bFNTybrpcNcdJGUgDhgjM3y3Rtbm	LECTURER	t	2026-05-06 23:28:19.69911+03	College of Informatics	t
22a5fd30-426f-48bd-945c-0e9199cea345	Fasil Abebe	amanualazanaw3434@gmail.com	$2b$12$3OnYkrzjeUGNZRi8Q598OOv7NMdqFLka6k502THFihIO8WfruJWaK	LECTURER	t	2026-05-06 23:31:52.338787+03	College of Informatics	t
ecef26d0-b631-489a-aaa7-2ea96623a388	Gebre Hailu	amanualazanaw11@gmail.com	$2b$12$JRKhZPqR.ZIT/W3mT0dLBe0H0PVN8xLSCcjTKpbz8kCFT9MRgFP8G	LECTURER	t	2026-05-06 23:45:39.677496+03	College of Informatics	t
4c3f1078-304c-463d-8556-93c57d032aea	Amare Hailu	amanualaza21@gmail.com	$2b$12$VGYXG6oXb4WZ6yGNbScHIOYDrsbOTZc1NO0jNgDtjHXR2cwfLuchG	LECTURER	t	2026-05-06 23:50:54.754688+03	College of Informatics	t
64328bc6-b586-4705-92fb-838719d8217a	Henok Mesfin	amanual2589@gmail.com	$2b$12$d4PW1RRF34/c1dDHR/Xmj.QFEz3F4Wfn9kAaVKdsJ39ZdpXuT0CJi	LECTURER	t	2026-05-06 23:54:03.670336+03	College of Informatics	t
33d4d0ac-c6c3-4976-bb06-576534112bcc	ashe	zablonbit2007@gmail.com	\N	LECTURER	f	2026-05-09 16:15:22.623883+03	College of Informatics	t
3a83ba96-acb4-4b94-a40a-e5d6f7cdb931	aaa	zablonb2007bit@gmail.com	$2b$12$DVIQMrkeDXZSciO.C.xPL.4VmRY8g9oKFyO8fmq753pAK.597uhOa	LECTURER	t	2026-05-09 16:16:52.17905+03	College of Informatics	t
ab3b8619-72f3-455a-a450-e7c44eb10a8e	kiki	ashenafi0habte@gmail.com	\N	LECTURER	f	2026-05-24 23:19:38.599503+03	College of Informatics	t
38957b99-b634-4143-bf7f-4928a35fd06f	mats	matsmekuriaw@gmail.com	\N	LECTURER	f	2026-05-25 11:25:42.549129+03	College of Informatics	t
980d3af8-eb07-4b30-8a33-3cca1a933d19	ashuvictor	ashenafih212121@gmail.com	$2b$12$/y./OtQrs9pWAeK./Q00Ouc5WKS/REanMPi8BNvcOOCyxtSmQhxEy	LECTURER	t	2026-05-24 23:21:25.657138+03	College of Informatics	t
\.


--
-- TOC entry 5254 (class 0 OID 0)
-- Dependencies: 218
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: -
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 12, true);


--
-- TOC entry 4940 (class 2606 OID 17420)
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: -
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 5035 (class 2606 OID 17939)
-- Name: allocation_overrides allocation_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_overrides
    ADD CONSTRAINT allocation_overrides_pkey PRIMARY KEY (id);


--
-- TOC entry 5043 (class 2606 OID 17985)
-- Name: allocation_reports allocation_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_reports
    ADD CONSTRAINT allocation_reports_pkey PRIMARY KEY (id);


--
-- TOC entry 4988 (class 2606 OID 17734)
-- Name: allocation_results allocation_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_results
    ADD CONSTRAINT allocation_results_pkey PRIMARY KEY (id);


--
-- TOC entry 5025 (class 2606 OID 17903)
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- TOC entry 4964 (class 2606 OID 17589)
-- Name: application_rounds application_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_rounds
    ADD CONSTRAINT application_rounds_pkey PRIMARY KEY (id);


--
-- TOC entry 4969 (class 2606 OID 17600)
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- TOC entry 5014 (class 2606 OID 17864)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5008 (class 2606 OID 17849)
-- Name: backup_config backup_config_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_key_key UNIQUE (key);


--
-- TOC entry 5010 (class 2606 OID 17847)
-- Name: backup_config backup_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_pkey PRIMARY KEY (id);


--
-- TOC entry 5040 (class 2606 OID 17967)
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 5005 (class 2606 OID 17830)
-- Name: backup_schedule backup_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_schedule
    ADD CONSTRAINT backup_schedule_pkey PRIMARY KEY (id);


--
-- TOC entry 4983 (class 2606 OID 17702)
-- Name: committee_rank_entries committee_rank_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.committee_rank_entries
    ADD CONSTRAINT committee_rank_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 4993 (class 2606 OID 17775)
-- Name: complaint_messages complaint_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.complaint_messages
    ADD CONSTRAINT complaint_messages_pkey PRIMARY KEY (id);


--
-- TOC entry 4998 (class 2606 OID 17786)
-- Name: complaint_threads complaint_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.complaint_threads
    ADD CONSTRAINT complaint_threads_pkey PRIMARY KEY (id);


--
-- TOC entry 4951 (class 2606 OID 17497)
-- Name: housing_units housing_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.housing_units
    ADD CONSTRAINT housing_units_pkey PRIMARY KEY (id);


--
-- TOC entry 4977 (class 2606 OID 17668)
-- Name: lecturer_documents lecturer_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lecturer_documents
    ADD CONSTRAINT lecturer_documents_pkey PRIMARY KEY (id);


--
-- TOC entry 4953 (class 2606 OID 17513)
-- Name: lecturer_scoring_criteria lecturer_scoring_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lecturer_scoring_criteria
    ADD CONSTRAINT lecturer_scoring_criteria_pkey PRIMARY KEY (id);


--
-- TOC entry 4943 (class 2606 OID 17437)
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (id);


--
-- TOC entry 4958 (class 2606 OID 17522)
-- Name: score_snapshots score_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.score_snapshots
    ADD CONSTRAINT score_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 4962 (class 2606 OID 17532)
-- Name: scoring_policies scoring_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scoring_policies
    ADD CONSTRAINT scoring_policies_pkey PRIMARY KEY (id);


--
-- TOC entry 5029 (class 2606 OID 17921)
-- Name: system_backups system_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_backups
    ADD CONSTRAINT system_backups_pkey PRIMARY KEY (id);


--
-- TOC entry 5019 (class 2606 OID 17885)
-- Name: system_config system_config_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_key_key UNIQUE (key);


--
-- TOC entry 5021 (class 2606 OID 17883)
-- Name: system_config system_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_pkey PRIMARY KEY (id);


--
-- TOC entry 4947 (class 2606 OID 17447)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 5032 (class 1259 OID 17950)
-- Name: allocation_overrides_application_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_overrides_application_id_idx ON public.allocation_overrides USING btree (application_id);


--
-- TOC entry 5033 (class 1259 OID 17952)
-- Name: allocation_overrides_created_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_overrides_created_by_idx ON public.allocation_overrides USING btree (created_by);


--
-- TOC entry 5036 (class 1259 OID 17951)
-- Name: allocation_overrides_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_overrides_status_idx ON public.allocation_overrides USING btree (status);


--
-- TOC entry 5044 (class 1259 OID 17986)
-- Name: allocation_reports_round_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_reports_round_id_idx ON public.allocation_reports USING btree (round_id);


--
-- TOC entry 5045 (class 1259 OID 17987)
-- Name: allocation_reports_sent_by_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_reports_sent_by_user_id_idx ON public.allocation_reports USING btree (sent_by_user_id);


--
-- TOC entry 5046 (class 1259 OID 17988)
-- Name: allocation_reports_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_reports_status_idx ON public.allocation_reports USING btree (status);


--
-- TOC entry 4986 (class 1259 OID 17758)
-- Name: allocation_results_housing_unit_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_results_housing_unit_idx ON public.allocation_results USING btree (housing_unit_id);


--
-- TOC entry 4989 (class 1259 OID 17755)
-- Name: allocation_results_round_application_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX allocation_results_round_application_unique ON public.allocation_results USING btree (round_id, application_id);


--
-- TOC entry 4990 (class 1259 OID 17756)
-- Name: allocation_results_round_housing_unit_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX allocation_results_round_housing_unit_unique ON public.allocation_results USING btree (round_id, housing_unit_id);


--
-- TOC entry 4991 (class 1259 OID 17757)
-- Name: allocation_results_round_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allocation_results_round_idx ON public.allocation_results USING btree (round_id);


--
-- TOC entry 5022 (class 1259 OID 17911)
-- Name: announcements_created_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX announcements_created_by_idx ON public.announcements USING btree (created_by);


--
-- TOC entry 5023 (class 1259 OID 17909)
-- Name: announcements_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX announcements_is_active_idx ON public.announcements USING btree (is_active);


--
-- TOC entry 5026 (class 1259 OID 17910)
-- Name: announcements_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX announcements_type_idx ON public.announcements USING btree (type);


--
-- TOC entry 4965 (class 1259 OID 17626)
-- Name: application_rounds_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_rounds_status_idx ON public.application_rounds USING btree (status);


--
-- TOC entry 4966 (class 1259 OID 17627)
-- Name: application_rounds_window_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX application_rounds_window_idx ON public.application_rounds USING btree (starts_at, ends_at);


--
-- TOC entry 4967 (class 1259 OID 17689)
-- Name: applications_compliance_issue_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX applications_compliance_issue_idx ON public.applications USING btree (compliance_issue);


--
-- TOC entry 4970 (class 1259 OID 17629)
-- Name: applications_round_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX applications_round_id_idx ON public.applications USING btree (round_id);


--
-- TOC entry 4971 (class 1259 OID 17631)
-- Name: applications_round_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX applications_round_status_idx ON public.applications USING btree (round_id, status);


--
-- TOC entry 4972 (class 1259 OID 17630)
-- Name: applications_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX applications_status_idx ON public.applications USING btree (status);


--
-- TOC entry 4973 (class 1259 OID 17628)
-- Name: applications_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX applications_user_id_idx ON public.applications USING btree (user_id);


--
-- TOC entry 5011 (class 1259 OID 17871)
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- TOC entry 5012 (class 1259 OID 17873)
-- Name: audit_logs_affected_record_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_affected_record_idx ON public.audit_logs USING btree (affected_record);


--
-- TOC entry 5015 (class 1259 OID 17872)
-- Name: audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_timestamp_idx ON public.audit_logs USING btree ("timestamp");


--
-- TOC entry 5016 (class 1259 OID 17870)
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- TOC entry 5006 (class 1259 OID 17855)
-- Name: backup_config_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_config_key_idx ON public.backup_config USING btree (key);


--
-- TOC entry 5037 (class 1259 OID 17973)
-- Name: backup_logs_backup_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_logs_backup_id_idx ON public.backup_logs USING btree (backup_id);


--
-- TOC entry 5038 (class 1259 OID 17974)
-- Name: backup_logs_level_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_logs_level_idx ON public.backup_logs USING btree (level);


--
-- TOC entry 5041 (class 1259 OID 17975)
-- Name: backup_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_logs_timestamp_idx ON public.backup_logs USING btree ("timestamp");


--
-- TOC entry 5001 (class 1259 OID 17836)
-- Name: backup_schedule_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_schedule_enabled_idx ON public.backup_schedule USING btree (enabled);


--
-- TOC entry 5002 (class 1259 OID 17837)
-- Name: backup_schedule_frequency_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_schedule_frequency_idx ON public.backup_schedule USING btree (frequency);


--
-- TOC entry 5003 (class 1259 OID 17838)
-- Name: backup_schedule_next_run_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_schedule_next_run_at_idx ON public.backup_schedule USING btree (next_run_at);


--
-- TOC entry 4981 (class 1259 OID 17719)
-- Name: committee_rank_entries_application_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX committee_rank_entries_application_id_unique ON public.committee_rank_entries USING btree (application_id);


--
-- TOC entry 4984 (class 1259 OID 17721)
-- Name: committee_rank_entries_round_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX committee_rank_entries_round_id_idx ON public.committee_rank_entries USING btree (round_id);


--
-- TOC entry 4985 (class 1259 OID 17720)
-- Name: committee_rank_entries_round_rank_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX committee_rank_entries_round_rank_unique ON public.committee_rank_entries USING btree (round_id, rank_position);


--
-- TOC entry 4994 (class 1259 OID 17803)
-- Name: complaint_messages_sender_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX complaint_messages_sender_user_id_idx ON public.complaint_messages USING btree (sender_user_id);


--
-- TOC entry 4995 (class 1259 OID 17802)
-- Name: complaint_messages_thread_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX complaint_messages_thread_id_idx ON public.complaint_messages USING btree (thread_id);


--
-- TOC entry 4996 (class 1259 OID 17804)
-- Name: complaint_threads_lecturer_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX complaint_threads_lecturer_user_id_idx ON public.complaint_threads USING btree (lecturer_user_id);


--
-- TOC entry 4999 (class 1259 OID 17806)
-- Name: complaint_threads_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX complaint_threads_status_idx ON public.complaint_threads USING btree (status);


--
-- TOC entry 5000 (class 1259 OID 17805)
-- Name: complaint_threads_target_department_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX complaint_threads_target_department_idx ON public.complaint_threads USING btree (target_department);


--
-- TOC entry 4949 (class 1259 OID 17498)
-- Name: housing_units_block_room_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX housing_units_block_room_unique ON public.housing_units USING btree (block_number, room_number);


--
-- TOC entry 4974 (class 1259 OID 17990)
-- Name: idx_applications_final_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_applications_final_score ON public.applications USING btree (final_score);


--
-- TOC entry 4975 (class 1259 OID 17680)
-- Name: lecturer_documents_application_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lecturer_documents_application_id_idx ON public.lecturer_documents USING btree (application_id);


--
-- TOC entry 4978 (class 1259 OID 17681)
-- Name: lecturer_documents_purpose_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lecturer_documents_purpose_idx ON public.lecturer_documents USING btree (purpose);


--
-- TOC entry 4979 (class 1259 OID 17682)
-- Name: lecturer_documents_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lecturer_documents_status_idx ON public.lecturer_documents USING btree (status);


--
-- TOC entry 4980 (class 1259 OID 17679)
-- Name: lecturer_documents_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lecturer_documents_user_id_idx ON public.lecturer_documents USING btree (user_id);


--
-- TOC entry 4954 (class 1259 OID 17549)
-- Name: lecturer_scoring_criteria_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lecturer_scoring_criteria_user_id_idx ON public.lecturer_scoring_criteria USING btree (user_id);


--
-- TOC entry 4955 (class 1259 OID 17548)
-- Name: lecturer_scoring_criteria_user_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lecturer_scoring_criteria_user_id_unique ON public.lecturer_scoring_criteria USING btree (user_id);


--
-- TOC entry 4941 (class 1259 OID 17454)
-- Name: otp_codes_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX otp_codes_expires_at_idx ON public.otp_codes USING btree (expires_at);


--
-- TOC entry 4944 (class 1259 OID 17458)
-- Name: otp_codes_user_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX otp_codes_user_id_unique ON public.otp_codes USING btree (user_id);


--
-- TOC entry 4956 (class 1259 OID 17551)
-- Name: score_snapshots_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX score_snapshots_created_at_idx ON public.score_snapshots USING btree (created_at);


--
-- TOC entry 4959 (class 1259 OID 17550)
-- Name: score_snapshots_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX score_snapshots_user_id_idx ON public.score_snapshots USING btree (user_id);


--
-- TOC entry 4960 (class 1259 OID 17552)
-- Name: scoring_policies_effective_from_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scoring_policies_effective_from_idx ON public.scoring_policies USING btree (effective_from);


--
-- TOC entry 5027 (class 1259 OID 17929)
-- Name: system_backups_created_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_backups_created_by_idx ON public.system_backups USING btree (created_by);


--
-- TOC entry 5030 (class 1259 OID 17927)
-- Name: system_backups_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_backups_status_idx ON public.system_backups USING btree (status);


--
-- TOC entry 5031 (class 1259 OID 17928)
-- Name: system_backups_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_backups_type_idx ON public.system_backups USING btree (type);


--
-- TOC entry 5017 (class 1259 OID 17891)
-- Name: system_config_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_config_key_idx ON public.system_config USING btree (key);


--
-- TOC entry 4945 (class 1259 OID 17455)
-- Name: users_email_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_unique ON public.users USING btree (email);


--
-- TOC entry 4948 (class 1259 OID 17456)
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- TOC entry 5076 (class 2606 OID 17940)
-- Name: allocation_overrides allocation_overrides_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_overrides
    ADD CONSTRAINT allocation_overrides_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5077 (class 2606 OID 17945)
-- Name: allocation_overrides allocation_overrides_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_overrides
    ADD CONSTRAINT allocation_overrides_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5062 (class 2606 OID 17750)
-- Name: allocation_results allocation_results_allocated_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_results
    ADD CONSTRAINT allocation_results_allocated_by_user_id_users_id_fk FOREIGN KEY (allocated_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- TOC entry 5063 (class 2606 OID 17740)
-- Name: allocation_results allocation_results_application_id_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_results
    ADD CONSTRAINT allocation_results_application_id_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- TOC entry 5064 (class 2606 OID 17745)
-- Name: allocation_results allocation_results_housing_unit_id_housing_units_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_results
    ADD CONSTRAINT allocation_results_housing_unit_id_housing_units_id_fk FOREIGN KEY (housing_unit_id) REFERENCES public.housing_units(id) ON DELETE RESTRICT;


--
-- TOC entry 5065 (class 2606 OID 17735)
-- Name: allocation_results allocation_results_round_id_application_rounds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allocation_results
    ADD CONSTRAINT allocation_results_round_id_application_rounds_id_fk FOREIGN KEY (round_id) REFERENCES public.application_rounds(id) ON DELETE CASCADE;


--
-- TOC entry 5073 (class 2606 OID 17904)
-- Name: announcements announcements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5051 (class 2606 OID 17601)
-- Name: application_rounds application_rounds_created_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.application_rounds
    ADD CONSTRAINT application_rounds_created_by_user_id_users_id_fk FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- TOC entry 5052 (class 2606 OID 17616)
-- Name: applications applications_preferred_housing_unit_id_housing_units_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_preferred_housing_unit_id_housing_units_id_fk FOREIGN KEY (preferred_housing_unit_id) REFERENCES public.housing_units(id) ON DELETE SET NULL;


--
-- TOC entry 5053 (class 2606 OID 17684)
-- Name: applications applications_reviewed_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_reviewed_by_user_id_users_id_fk FOREIGN KEY (reviewed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5054 (class 2606 OID 17611)
-- Name: applications applications_round_id_application_rounds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_round_id_application_rounds_id_fk FOREIGN KEY (round_id) REFERENCES public.application_rounds(id) ON DELETE CASCADE;


--
-- TOC entry 5055 (class 2606 OID 17621)
-- Name: applications applications_score_snapshot_id_score_snapshots_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_score_snapshot_id_score_snapshots_id_fk FOREIGN KEY (score_snapshot_id) REFERENCES public.score_snapshots(id) ON DELETE SET NULL;


--
-- TOC entry 5056 (class 2606 OID 17606)
-- Name: applications applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5071 (class 2606 OID 17865)
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5070 (class 2606 OID 17850)
-- Name: backup_config backup_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_config
    ADD CONSTRAINT backup_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5078 (class 2606 OID 17968)
-- Name: backup_logs backup_logs_backup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_backup_id_fkey FOREIGN KEY (backup_id) REFERENCES public.system_backups(id) ON DELETE CASCADE;


--
-- TOC entry 5069 (class 2606 OID 17831)
-- Name: backup_schedule backup_schedule_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_schedule
    ADD CONSTRAINT backup_schedule_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5059 (class 2606 OID 17709)
-- Name: committee_rank_entries committee_rank_entries_application_id_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.committee_rank_entries
    ADD CONSTRAINT committee_rank_entries_application_id_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- TOC entry 5060 (class 2606 OID 17704)
-- Name: committee_rank_entries committee_rank_entries_round_id_application_rounds_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.committee_rank_entries
    ADD CONSTRAINT committee_rank_entries_round_id_application_rounds_id_fk FOREIGN KEY (round_id) REFERENCES public.application_rounds(id) ON DELETE CASCADE;


--
-- TOC entry 5061 (class 2606 OID 17714)
-- Name: committee_rank_entries committee_rank_entries_updated_by_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.committee_rank_entries
    ADD CONSTRAINT committee_rank_entries_updated_by_user_id_users_id_fk FOREIGN KEY (updated_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- TOC entry 5066 (class 2606 OID 17792)
-- Name: complaint_messages complaint_messages_sender_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.complaint_messages
    ADD CONSTRAINT complaint_messages_sender_user_id_users_id_fk FOREIGN KEY (sender_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5067 (class 2606 OID 17787)
-- Name: complaint_messages complaint_messages_thread_id_complaint_threads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.complaint_messages
    ADD CONSTRAINT complaint_messages_thread_id_complaint_threads_id_fk FOREIGN KEY (thread_id) REFERENCES public.complaint_threads(id) ON DELETE CASCADE;


--
-- TOC entry 5068 (class 2606 OID 17797)
-- Name: complaint_threads complaint_threads_lecturer_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.complaint_threads
    ADD CONSTRAINT complaint_threads_lecturer_user_id_users_id_fk FOREIGN KEY (lecturer_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5057 (class 2606 OID 17674)
-- Name: lecturer_documents lecturer_documents_application_id_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lecturer_documents
    ADD CONSTRAINT lecturer_documents_application_id_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE SET NULL;


--
-- TOC entry 5058 (class 2606 OID 17669)
-- Name: lecturer_documents lecturer_documents_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lecturer_documents
    ADD CONSTRAINT lecturer_documents_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5048 (class 2606 OID 17533)
-- Name: lecturer_scoring_criteria lecturer_scoring_criteria_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lecturer_scoring_criteria
    ADD CONSTRAINT lecturer_scoring_criteria_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5047 (class 2606 OID 17448)
-- Name: otp_codes otp_codes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5049 (class 2606 OID 17543)
-- Name: score_snapshots score_snapshots_scoring_policy_id_scoring_policies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.score_snapshots
    ADD CONSTRAINT score_snapshots_scoring_policy_id_scoring_policies_id_fk FOREIGN KEY (scoring_policy_id) REFERENCES public.scoring_policies(id) ON DELETE SET NULL;


--
-- TOC entry 5050 (class 2606 OID 17538)
-- Name: score_snapshots score_snapshots_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.score_snapshots
    ADD CONSTRAINT score_snapshots_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5074 (class 2606 OID 17922)
-- Name: system_backups system_backups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_backups
    ADD CONSTRAINT system_backups_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 5075 (class 2606 OID 17953)
-- Name: system_backups system_backups_restored_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_backups
    ADD CONSTRAINT system_backups_restored_by_fkey FOREIGN KEY (restored_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 5072 (class 2606 OID 17886)
-- Name: system_config system_config_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_config
    ADD CONSTRAINT system_config_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


-- Completed on 2026-05-26 00:16:57

--
-- PostgreSQL database dump complete
--

\unrestrict AWt2wpujzEbutsnIMMzyWlocR8pdGkQFSwRjDSmvdg4ELsYMI70ozOxlkdPPTWM

